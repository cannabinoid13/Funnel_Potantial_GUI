# FunnelForge

Desmond için **bir boyutlu, iyi-temperlenmiş (well-tempered) funnel-metadinamik**
potansiyellerini 3B olarak tasarlayan, doğrulayan ve çalıştırmaya hazır dosya
seti olarak dışa aktaran masaüstü yazılımı. Web arayüzü değildir; PyQt5 + VTK
ile yazılmış yerel bir uygulamadır.

Referans iş: `funnel_metadaynamics_ayrilma_Z5_run.{pot,msj,cfg,sh,cms}`
(62 870 atom, 85.8 × 86.6 × 89.1 Å SPC su kutusu, Z5 ligandı = zincir B / LIG,
72 ağır atom).

![Denetim ve doğrulama](docs/01-check-and-verification.png)

---

## Özel paket uyumluluğu — 2026-09-05

**File ▸ Import job set…** artık ZIP paketini doğrudan açar. Örneğin:

```bash
conda activate cugraph_env
python -m funnelforge /home/bugra/Downloads/AChE-G6N_WT_funnel_MetaD_package.zip
```

Özel protein referans çerçevesi, farklı değişken adları, özel yarıçap/duvar
ifadeleri ve ek enerji katkıları kaynak metinden okunur. Konum, yana kaydırma,
eğim ve sayısal ayarlar mevcut kontrollerle yapılır; tema ve panel düzeni
aynıdır. Düzenleme kaynakta yalnız ilgili ifadeleri değiştirir; özel kuvvetler,
yorumlar ve izleme ifadeleri kaybolmaz. Düzenlenmemiş `.pot` metni aynen korunur.
Çalıştırılabilir export, Desmond kabul etmediği için varsa UTF-8 BOM işaretini
kaldırır ve bunu raporlar; kaynak kaydı özgün baytları korur.

Export, GUI hesabını 4.000 konumda dosyanın gerçek enerji ifadesiyle karşılaştırır,
başlatma bağımlılıklarını ve dosya referanslarını kontrol eder; bir hata varsa
yarım paket yazmaz. Yardımcı betikler korunur, dosya adları ve checksum manifesti
güncellenir. Eski geometriye sabitlenmiş doğrulama betikleri kaynak kanıtı olarak
saklanır; yeni paket güncel doğrulama kaydı ve mevcut Desmond ön kontrolüyle
başlatılır. Varsayılan çıktı klasörü kaynaklardan ayrı `<işadı>_export` olur.

Gerçek AChE-G6N ve BChE-G4N paketleriyle içe alma/düzenleme doğrulandı.
Güncel kapsam ve motor sınırları: [docs/known-limitations.md](docs/known-limitations.md).

---

## 1. Kurulum ve çalıştırma

Bağımlılıklar `cugraph_env` ortamında hazır (numpy, scipy, vtk 9.3, PyQt5 5.15,
matplotlib). Eksik bir şey varsa:

```bash
./install.sh
```

Çalıştırma:

```bash
cd /home/bugra/Claude/potantial && ./funnelforge.sh /home/bugra/Downloads/funnel_metadaynamics_ayrilma_Z5_run.pot
```

Dosya adı vermezseniz boş açılır, **File ▸ Import job set…** ile beşlinin
herhangi birini seçmeniz yeterlidir: aynı ana ada sahip `.pot / .cms / .msj /
.cfg / .sh` dosyaları **topluca** içe alınır. Masaüstü kısayolu isterseniz
`FunnelForge.desktop` dosyasını `~/.local/share/applications/` altına
kopyalayın.

`conda activate cugraph_env` yapıp doğrudan da çalıştırabilirsiniz:

```bash
cd /home/bugra/Claude/potantial && python -m funnelforge ~/Downloads/funnel_metadaynamics_ayrilma_Z5_run.pot
```

---

## 2. Ekran düzeni

| Bölge | İçerik |
|---|---|
| Orta | 3B sahne: protein, ligand, kofaktör, iyonlar, su, periyodik kutu, huni ve tutamaklar |
| Sağ (Design) | `Funnel`, `Shapes`, `MetaD`, `Groups`, `View`, `Job files`, `Check`, `.pot` sekmeleri |
| Alt (Profiles) | `Funnel profile`, `Potential map`, `Wall cuts`, `Well-tempered` grafikleri |
| Durum çubuğu | Yapı özeti · imleç altındaki atom · doğrulama durumu (● yeşil/sarı/kırmızı) |

Paneller `F9` / `F10` ile gizlenip gösterilir, sürüklenip ayrılabilir.

---

## 3. Huniyi 3B'de ayarlamak

> **Önemli:** İçe alınan dosyalar arasında `.pot` yoksa **hiçbir huni
> oluşturulmaz** ve önceki işin hunisi de taşınmaz. Yeni bir içe alma her
> şeyi sıfırlar: huni kapalı, şekil listesi boş, geometri sıfır. Huniyi
> ya `Funnel` sekmesindeki `Use the built-in funnel` kutusundan, ya
> `Shapes ▸ Add a funnel and fit it to the pocket` düğmesinden, ya da
> `Edit ▸ Add a funnel potential term` menüsünden siz eklersiniz.

Huni varken sahnede sürüklenebilir tutamaklar vardır:

| Tutamak | Rengi | Ne yapar |
|---|---|---|
| `z_min` | mavi | Cepteki alt eksenel duvar |
| `z_max` | kırmızı | Çözücü tarafındaki üst eksenel duvar |
| `z_cc` | sarı | Koni–silindir birleşme noktası |
| `r_cyl` | yeşil | Bulk silindirin yarıçapı |
| `cone` | mor | Koni açısı (taban yarıçapı üzerinden) |
| `origin` | altın | Huni çerçevesini eksen boyunca kaydırır |
| `origin e1` / `origin e2` | açık altın | Huniyi eksene **dik** olarak kaydırır (gövdeye sabit çerçeve gerekir) |

**Hassasiyet.** Fare ışını, tutamağın kısıtlandığı doğruya (eksen ya da radyal
yön) izdüşürülür; sürüklerken:

* `Shift` → 5× hassas
* `Ctrl` → 20× hassas
* `Ctrl+Shift` → 100× hassas

`Funnel ▸ Interaction ▸ drag snap` ile 0.01–1 Å adımına yuvarlatabilirsiniz.
Aynı değerler sağdaki spin kutularında 4–9 ondalıkla düzenlenebilir; iki yön
her zaman senkrondur. `Ctrl+Z` / `Ctrl+Shift+Z` geri alır/yineler.

`origin` tutamağı özel bir durumdur: huninin protein-göreli başlangıcını
kaydırır, yani ligandın `z` değeri de kayar. Referans dosyanın notu bunu
özellikle uyarıyor (`0.533364800` katsayısı korunmalı), bu yüzden hem oran
(`origin frac`, 9 ondalık) hem de Å cinsinden ofset ayrı ayrı görünür.

---

## 4. Potansiyeli görmek: katmanlar ve renkler

Renk ölçeği **maviden kırmızıya** gider ve her katman yarı saydamdır; arkadaki
protein her zaman görünür.

* **Wall surface (V = 0)** – kısıtlamanın başladığı yüzey. Düz taban (V = 0)
  olduğu için ölçeğin soğuk ucunu alır; şekli ve ölçüyü buradan okursunuz.
  İsterseniz `Tint the wall by stiffness` ile sertliğe göre boyanır.
* **Wireframe rings** – 5 Å'da bir halkalar ve meridyenler; şekli net gösterir.
* **Iso-potential shells** – duvarın dışındaki eş-enerji kabukları. Öntanımlı
  mod `fixed distances` (0.75 / 1.5 / 2.25 Å): kabuğun rengi "duvarın 1 Å
  dışında ne kadar iter" sorusunu doğrudan yanıtlar. Sert duvar hemen kırmızı,
  yumuşak duvar mavi kalır. `fixed energies` moduna geçip kcal/mol seviyeleri
  de verebilirsiniz.
* **Cross-section plane** – ekseni içeren düzlem, potansiyelle boyanmış.
  İçeride tamamen şeffaf (V = 0), duvarın dışında renkli bir bant, ölçek
  üstünde yine sönüyor. `turn section towards camera` düğmesi düzlemi kameraya
  çevirir.
* **Volume glow** – duvarı saran hacimsel parıltı (kabuk biçimli opaklık
  fonksiyonu; ne içeriyi ne de arkayı kapatır).
* **Axial end walls**, **axis**, **Å ruler**, **dimension labels**,
  **COM markers** ayrı ayrı açılıp kapanır.

`preset` açılır listesi (araç çubuğunda da var): `Shape only`,
`Shells (default)`, `Cross-section`, `Volume glow`, `Everything`.

`scale max` renk ölçeğinin tepesidir. Sert bir duvarda enerji 1–2 Å'da
patladığı için `scale max = wall energy 2 Å out` düğmesi ölçeği
`0.5·k_rad·(2 Å)²` yapar — gradyan böylece görünür genişlikte olur.

---

## 3b. Konum: otomatik yerleştirme ve hassas manuel ayar

### Otomatik yerleştirme neye göre karar veriyor

`Ctrl+F` (ya da `Add a funnel and fit it to the pocket`) huniyi ölçülmüş bir
niceliğe oturtur: eksen boyunca 0.25 Å adımlarla **serbest yarıçap** profili
r_free(z) hesaplanır — eksendeki her noktanın en yakın çözünen ağır atoma
uzaklığı.

* `z_min` = ligandın z'sinin 3 Å altı (aşağı yuvarlanmış).
* `z_cc` = r_free(z) değerinin 10 Å boyunca kesintisiz olarak
  `r_cyl + 1.5 Å`'yi aştığı **ilk** z; yani kanalın gerçekten bulk çözücüye
  açıldığı yer. Rapor, orada eksenin çözünenden ne kadar uzak olduğunu da
  verir.
* Koni açısı = funnel-metadinamikte alışılmış **30°**, yalnızca ligandın
  başlangıçta serbest kalması için gerekiyorsa genişletilir. Koninin protein
  atomlarını içine alması normaldir ve rapor kaç atom içerde kaldığını söyler:
  duvar yalnızca liganda etki eder, ligand da protein atomlarının bulunduğu
  yere zaten giremez.
* `z_max` = `z_cc + 8 Å`, ardından zarf kutu yüzlerinden bağsız kesme kadar
  açık kalana dek 0.5 Å'lık adımlarla geri çekilir; ne kadar çekildiği
  raporlanır.

Rapor penceresi seçilen her sayıyı ve gerekçesini gösterir; `Ctrl+Z` ile geri
alınır. Hiçbir değer kilitli değildir.

### Kontroller her zaman canlı

Yana kaydırma (`across e1/e2`, `origin e1/e2`) ve eğim (`tilt`,
`tilt towards`, `axis tilt`) alanları **hiçbir zaman kilitli değildir**. Bu
alanlar gövdeye sabit bir referans grubu gerektirir; eskiden referans yoksa
gri kalıyorlardı ve dokunduğunuzda hiçbir şey olmuyordu. Artık ilk
dokunuşunuzda referans grubu **otomatik olarak seçilir** (gömülü, eksenden
uzak bir omurga grubu) ve durum çubuğu hangi kalıntıların kullanıldığını
söyler. Uygun grup bulunamazsa bir uyarı çıkar ve değer geri alınır — sessiz
bir hiçbir şey yapmama durumu kalmadı.

Bu sınıf hatalara karşı kalıcı bir test var: `test_every_shape_control_actually_applies`
her kontrolü kullanıcının yaptığı gibi (iç widget sinyaliyle) sürer ve modelin
gerçekten değiştiğini doğrular; sonunda dışa aktarıp geri okuyarak açının,
kaydırmanın ve funnel eğiminin dosyada da yaşadığını denetler. Ayrıca panel
tazeleme fonksiyonları `try/finally` ile korundu: bir istisna artık `_loading`
bayrağını takılı bırakıp tüm paneli sağır edemez.

### Açı: her şekli ve funnel'ı istediğiniz yöne eğmek

Her şeklin **kendi ekseni** vardır ve bu eksen funnel ekseninden istediğiniz
kadar eğilebilir. İki sayı yeter: `tilt` (funnel ekseninden sapma açısı) ve
`tilt towards` (gövdeye sabit (e1, e2) düzlemindeki azimut). Aynı ikili
yerleşik funnel için de vardır (`axis tilt` / `tilt towards`, hem Funnel hem
Shapes sekmesinde) — bu durumda **yanlanan koordinatın yönü** değişir.

Eğim, çalışma zamanında trigonometri gerektirmeyecek şekilde üç sabit olarak
yazılır ve tamamen gövdeye sabittir, yani proteinle birlikte döner:

```
axis0 = axis_raw/axis_len;                 # eğilmemiş CORE→SITE yönü
p1 = fref_perp/norm(fref_perp);            # gövdeye sabit dik yön
p2 = cross(axis0,p1);
axis = 0.978148*axis0+0.119253*p1+0.170311*p2;      # 12° eğimli funnel ekseni
e1r = p1-dot(p1,axis)*axis;  e1 = e1r/norm(e1r);  e2 = cross(axis,e1);
...
w1_u = 0.906308*axis+0.365998*e1-0.211309*e2;       # şeklin kendi ekseni
w1_z = dot(w1_dv,w1_u);
w1_pp = w1_dv-w1_z*w1_u;
w1_rho = sqrt(norm2(w1_pp)+1.0e-12);
```

**Her uçtan ayarlama.** 3B'de seçili şeklin **iki ucunda da** ikişer "swing"
tutamağı belirir (e1 ve e2 yönlerinde). Bir ucu tutup çekmek şekli kendi
orijini etrafında döndürür; alt uç ters yöne döner. Tutamağın taşıdığı değer
yay uzunluğudur (açı × kol), bu yüzden sürükleme birikmeli değil **birebir ve
tekrarlanabilir**: aynı değeri iki kez uygulamak hiçbir şeyi değiştirmez.
Aynı şey funnel ekseni için de geçerli (`axis_tilt1/2` tutamakları, z_min ve
z_max uçlarında).

**Bölge anahtarı funnel z'sinden okunur**, şeklin kendi eğik koordinatından
değil: bir bölge "koşu funnel'ın şu evresindeyken" demektir ve üretilen dosya
da (`w<n>_s`) tam olarak bunu hesaplar. Bu iki taraf bir ara ayrışmıştı —
eğimsizken aynı sonucu verdikleri için gizli kalan, eğim verildiğinde modelin
terimi susturup dosyanın uygulamaya devam ettiği bir hataydı; doğrulama motoru
yakaladı, `test_region_switch_reads_the_funnel_z_even_when_tilted` ile
kilitlendi.

Eğim de kutuyla sınırlıdır: bir açı şekli dışarı savuruyorsa ikili arama ile
sığan en büyük açıya indirilir ve durum çubuğunda bildirilir. Son bir güvenlik
ağı olarak, her düzenlemeden sonra şeklin **gerçek yüzeyi** ölçülür ve gerekirse
kutu içine geri itilir (`pull_inside`) — bu, eğimli/kaydırılmış/kapaklı her
gövde için çalışır ve daima sonlanır.

> Eğim ve yana kaydırma **frame reference** grubu gerektirir (e1/e2 onsuz
> tanımsız olurdu); arayüz bunu hata olarak bildirir ve `Pick automatically`
> düğmesi uygun bir grup seçer.

### Kutu sınırı: şekiller asla çözücü kutusunun dışına çıkmaz

Her konum/boyut alanı, içe alınan yapının **periyodik kutusuna** göre
sınırlıdır. Bu üç katmanlı olarak uygulanır:

1. **Sayısal alanlar** kutu sınırına göre yeniden aralıklanır — kutunun dışını
   yazmanız mümkün değildir. Sınır, şeklin kendi yarıçapı hesaba katılarak
   bulunur (yalnızca merkezi değil, tüm gövdesi içeride kalır).
2. **Tutamak sürüklemesi** duvara gelince durur ve durum çubuğu
   "…stopped at X Å — the solvent box ends there" der.
3. Her geometri düzenlemesinden sonra `clamp_to_box` çalışır: yarıçaplar önce
   küçültülür, sonra eksenel uzanım şeklin yarıçapıyla sınırlanır, koni eğimi
   kutuya sığacak şekilde azaltılır, referans grubu yoksa yana kaydırmalar
   sıfırlanır. Yeri kalmayan bir şekil sıfıra küçültülmek yerine hücrenin
   ortasına doğru çekilir. Ne yapıldığı durum çubuğunda listelenir.

Torna profili bir ifade olduğu için kutudan geniş olabilir; bu durumda yarıçap
**potansiyelin kendi içinde** kapatılır:

```
w1_r0 = <profil>;
w1_r1 = if w1_r0 then w1_r0 else 0.0;              # >= 0
w1_r  = if 39.977-w1_r1 then w1_r1 else 39.977;    # <= kutu sınırı
```

Böylece dosya, kutunun dışında bir duvar tanımlayamaz.

**İçe alınan dosya asla sessizce değiştirilmez.** Elle yazılmış bir `.pot`
kutunun dışına taşıyorsa kırpma çalışmaz; denetim bunu **hata** olarak
bildirir ("…sticks out by X Å") ve düzeltme kararı sizde kalır. Kırpma
yalnızca sizin yaptığınız düzenlemelerden sonra devreye girer.

### Hassas manuel konumlandırma

Her şekil için üç bağımsız konum ekseni vardır ve hepsi **hem sayısal hem 3B**
olarak ayarlanır:

| Alan | Ne yapar | Hassasiyet |
|---|---|---|
| `along axis` | Şekli ekseni boyunca kaydırır, **boyutunu koruyarak** | 4 ondalık, 0.1 Å adım |
| `across e1` | Eksene dik, birinci yönde kaydırır | 4 ondalık, 0.05 Å adım |
| `across e2` | Eksene dik, ikinci yönde kaydırır | 4 ondalık, 0.05 Å adım |
| `z from` / `z to` | Torna ve pencere terimlerinin uçlarını ayrı ayrı | 3 ondalık |
| `centre z` / `radius` | Kürenin merkezi ve yarıçapı | 3 ondalık |

3B görünümde seçili şeklin tutamakları çıkar: eksende konum, iki yana kaydırma,
uçlar (torna/pencere) ve yarıçap (küre). Tutamaklar **yalnızca seçili şekil**
için gösterilir, böylece sahne okunur kalır. Tutamaklar derinliği temizlenmiş
ayrı bir katmanda çizilir ve fare ışınına göre **ekran uzaklığıyla** (18 piksel)
seçilir; bu yüzden saydam bir şeklin içinde kalsalar bile hem görünür hem
tıklanabilir kalırlar, ve boyutları kamera uzaklığına göre ölçeklenir. Sürüklerken `Shift` 5×, `Ctrl`
20×, `Ctrl+Shift` 100× daha hassastır; `drag snap` ile 0.01 Å'ya yuvarlanır.
Sayısal alanlar ve tutamaklar her zaman senkrondur, sürükleme sırasında
kutulardaki değerler canlı güncellenir.

### Yana kaydırma neden bir referans grup istiyor

Eksen (`axis`) SITE ve CORE kütle merkezlerinden gelir, yani proteinle birlikte
döner. Ama "eksene dik" iki yön bundan tek başına belirlenemez; laboratuvar
kutusundan alınırsa protein döndükçe şekliniz kayar. Bu yüzden yana kaydırma,
**üçüncü bir atom grubuyla** tanımlanan gövdeye sabit bir çerçeve ister:

```
fref = atomsel("atom. ...");
fref_com = center_of_mass(fref);
fref_v = min_image(fref_com-core_com);
fref_par = dot(fref_v,axis);
fref_perp = fref_v-fref_par*axis;
e1 = fref_perp/norm(fref_perp);
e2 = cross(axis,e1);
```

`Shapes ▸ Body-fixed frame ▸ Pick automatically` bunu sizin için seçer: gömülü
(dalgalanmayan), eksenden yeterince uzak (yön iyi koşullanmış) omurga atomları.
Panel seçilen grubu, kalıntı adlarını ve **dik erişimi** (eksenden uzaklık)
gösterir; 5 Å'nın altındaysa uyarır, 2 Å'nın altındaysa hata verir. Referans
yokken yana kaydırma alanları kapalıdır ve sıfırdan farklı bir kaydırma varken
referansı silmeye çalışırsanız engellenirsiniz — aksi halde potansiyel
tanımlanmamış `e1`/`e2`'ye atıf yapardı.

Yana kaydırma `z`'yi **değiştirmez** (e1 ve e2 eksene diktir), yalnızca `rho`'yu
değiştirir; yani metadinamik CV'si etkilenmeden şekli eksenin yanına
taşıyabilirsiniz. Huninin kendi orijini de aynı şekilde yana kaydırılabilir
(`origin e1` / `origin e2`).

---

## 4b. Şekil terimleri: potansiyele istediğiniz formu vermek

`Shapes` sekmesi potansiyeli **terimlerin toplamı** olarak kurar. Yerleşik huni
tamamen kapatılabilir (`Use the built-in funnel` kutusu); o zaman kısıtlamanın
tamamı sizin tanımladığınız terimlerden oluşur. Metadinamik CV'si her durumda
eksenel koordinat `z` olarak kalır.

Dört terim tipi var:

### Torna (`lathe`) — profil girip döndürmek

`r(z)` profilini bir ifade olarak yazarsınız, program bunu huni ekseni
etrafında döndürerek katı bir hacim üretir. **Hacmin çözeltiye bakan tarafı
otomatik olarak kapatılır** (`close the ends = solvent side only`), çünkü
ayrılan ligandın kaçacağı uç orasıdır; istersek cep tarafı, iki uç ya da
hiçbiri de seçilebilir.

Panelde profilin altında bir **torna önizlemesi** vardır: profil ve onun
eksene göre aynalanmış silueti, kapatılan uç kırmızı çizgiyle, etkin bölge
sarı bantla, ligandın anlık konumu turuncu noktayla gösterilir. Hazır
profiller (silindir, koni, kum saati boynu, trompet, Gauss şişkinliği,
sigmoid basamak, fıçı) listeden seçilip düzenlenebilir.

Üretilen kod tam olarak şu şekildedir (örnek: Gauss şişkinliği):

```
w1_r0 = 5.0+7.0*exp(0.0-((z-8.0)^2)/40.0);
w1_r  = if w1_r0 then w1_r0 else 0.0;         # yarıçap negatife düşemez
w1_e  = if rho-w1_r then rho-w1_r else 0.0;   # tek yanlı, düz tabanlı duvar
w1_wall = 0.5*30.0*w1_e^2;
w1_hi = if z-22.0 then z-22.0 else 0.0;       # çözelti tarafındaki kapak
w1_cap = 0.5*60.0*(w1_hi^2);
v_w1 = w1_wall+w1_cap;
```

### Denklem (`expression`) — enerjiyi doğrudan yazmak

Bu alan **aynen** dosyaya yazılır: potansiyel tam olarak yazdığınız şeydir,
hiçbir şey eklenmez. `variables and functions…` düğmesi değişken listesini
(`z`, `rho`, `r_allowed`, `axis_len`, `lig_com`, `site_com`, `core_com`,
`origin`, `axis`, `z_cc`, `r_cyl`, `k_rad`, `ktemp` …), Desmond'un **gerçek**
fonksiyon tablosunu ve bulunmayan fonksiyonların yerine ne yazılacağını
gösterir. `examples…` düğmesinde hazır örnekler var (silindirik duvar, huni
duvarının 2 Å dışında duvar, elipsoit, kuartik yumuşak duvar, doğrusal itme,
türevlenebilir yumuşak duvar, kesirli kuvvetli koni, bir kalıntıdan uzaklık
kısıtı).

Yazdığınız her ifade siz yazarken denetlenir; panelde ✓ ya da ✕ ile sonucu ve
hatayı görürsünüz. Denetlenen kurallar Desmond kılavuzundan (bölüm 11) alındı:

* `^` **yalnızca tam sayı** kuvvet alır; kesirli kuvvet için `pow(taban, üs)`
  ve `pow`'un tabanı **pozitif** olmalı.
* `abs`, `min`, `max`, `tan` **yoktur**: sırasıyla `x*sign(x)`,
  `gibbs_min(T,array(a,b))`, `gibbs_max(T,array(a,b))`, `sin(x)/cos(x)`.
* `if c then a else b` → `c > 0` iken ilk dal. Tek yanlı duvar bu yüzden
  `if rho-R then rho-R else 0.0` biçiminde yazılır.
* Her değer bir dizidir: skaler = 1 uzunluklu, vektör = 3 uzunluklu dizi.
  `*` eleman elemandır, iç çarpım `dot(a,b)`.
* Çıkarma minimum-imaj uygulamaz; uzak gruplar arası fark `min_image(...)`
  içinden geçmelidir.
* Bir isim yalnızca **bir kez** atanabilir (tek atama dili).
* `-x^2` yerine `0.0-(x^2)` yazmanız önerilir (arayüz bunu uyarır).
* İfade tek bir sayı, yani kcal/mol cinsinden enerji vermelidir ve kuvvet
  istemediğiniz yerde sıfır olmalıdır.

### Küre (`sphere`) ve eksenel pencere (`slab`)

Küre, huni eksenindeki bir noktaya **veya bir atom grubunun kütle merkezine**
oturtulabilir (ikincisi öteleme/dönmeden bağımsızdır: "ligand şu kalıntıdan
20 Å uzaklaşmasın"). Pencere ise `z_lo` ve `z_hi`'de iki tek yanlı duvardır.

### Potansiyelin değişim seviyeleri

Her terim için duvarın ne kadar hızlı yükseldiği hem ayarlanır hem gösterilir:

* `force k` ve `exponent` (2 = harmonik, 4 = başta yumuşak sonda sert; Desmond'un
  `^` işleci tam sayı ister), `slack` = duvarın devreye girmeden önceki boşluk.
* `Potential gradation` okuması duvarın **0.5 / 1 / 2 / 3 Å** dışında kaç
  kcal/mol ettiğini canlı gösterir.
* `Use my own contour levels` ile o terimin eş-enerji kabukları için kendi
  seviyelerini verebilirsiniz — mesafe (Å) ya da enerji (kcal/mol) olarak.
  Bu, `k = 2` ile `k = 120` gibi çok farklı sertlikte terimler aynı sahnede
  olduğunda tek bir küresel seviye listesinin işe yaramamasını çözer.

### Farklı yerlere farklı potansiyeller

Her terimin isteğe bağlı bir **etkin bölgesi** vardır (`Region`): `from z`,
`to z` ve `taper`. Anahtarlama kübik bir smoothstep'tir, yani enerji **ve**
birinci türevi süreklidir:

```
w2_sa  = (z-24.0)/2.5;
w2_sac = if w2_sa then (if 1.0-w2_sa then w2_sa else 1.0) else 0.0;
w2_sb  = (34.0-z)/2.5;
w2_sbc = if w2_sb then (if 1.0-w2_sb then w2_sb else 1.0) else 0.0;
w2_s   = w2_sac^2*(3.0-2.0*w2_sac)*w2_sbc^2*(3.0-2.0*w2_sbc);
v_w2   = w2_s*(...);
```

Bölge, terimin **etki ettiği grubun** z'si üzerinden okunur; liganda etki eden
bir terim için bu koşunun kendi CV'sidir ve yana kaydırma z'yi değiştirmediği
için anahtarı etkilemez.

`taper = 0` sert kapı demektir; enerji sıçrar ve integratörü tekmeler, arayüz
bunu uyarı olarak söyler. Bir kapak (`cap`) anahtarlanmış bir bölgenin içinde
kalırsa, anahtar kapağı tam kapatması gereken yerde söndüreceği için bu da
uyarılır.

**Sizin örneğiniz** — huninin silindirik bölgesinde çözücü etkileşimini
azaltmak: silindir bölgesine (`z` 24–34) `r(z) = 2.2` profilli, `k = 120`
sertliğinde bir torna terimi ekleyip bölgeyi 2.5 Å taper ile sınırlamak
yeterlidir. Ligand cepte ve konide serbest kalır, bulk kanalda ise dar ve sert
bir tüpe sıkışır; böylece çözücü hacminin taranması ölçülü biçimde azalır.
Doğrulama örneği (arayüzün kendi hesabı ile dosyanın bağımsız yorumlanması):

| z | ρ | V (kcal/mol) | anahtar |
|---|---|---|---|
| 10.0 | 3.0 | 0.000 | 0.000 |
| 24.0 | 3.0 | 0.000 | 0.000 |
| 26.5 | 3.0 | 38.400 | 1.000 |
| 30.0 | 2.0 | 0.000 | 1.000 |
| 30.0 | 3.0 | 38.400 | 1.000 |
| 35.0 | 3.0 | 25.000 | 0.000 (huninin z duvarı) |

### Ligandı siz seçersiniz

`Ctrl+G` (CV gruplarını öner) **artık sizin seçiminizi asla ezmez**: ligand
grubunda bir şey varsa aynen korunur ve yalnızca SITE/CORE onun çevresinden
türetilir. Ligand boşsa, sessizce en büyük hetero kalıntıyı almak yerine
adayları listeleyen bir pencere açılır (referans sistemde `B:LIG1` 72 ağır
atom, `C:LIG1` 53, `A:NDP480` 27) ve hangisinin ligand olduğunu siz
seçersiniz. Rapor penceresi ne yaptığını satır satır söyler.

### Terimin hedefi

Her terim öntanımlı olarak ligandın kütle merkezine etki eder, ama başka bir
atom grubuna da bağlanabilir. O zaman üretilen dosyada o grubun kendi
`atomsel`, `center_of_mass` ve `z`/`rho` bloğu açılır; metadinamik CV'si
etkilenmez. Örneğin bir ilmeği yerinde tutmak ya da kofaktörü sabitlemek için
kullanılabilir.

### Görselleştirme

* Her terim kendi renginde, yarı saydam sınır yüzeyi olarak çizilir; torna
  terimlerinde profil halkaları, kapaklar ve eş-enerji kabukları da vardır.
* Denklemle tanımlanan terimler **marching cubes** ile çizilir: alan ızgarada
  örneklenir, böylece herhangi bir şekil doğru görünür. Terim sınırı, bölge
  anahtarı **uygulanmadan** çizilir (anahtarlanmış bir duvar taper kenarında
  çok büyük olduğu için mutlak bir eş-enerji seviyesi orada kâğıt kalınlığında
  plakalara dönüşürdü); bölgenin nerede başlayıp bittiğini iki kesikli halka
  gösterir.
* `View ▸ Funnel layers ▸ Combined field iso-surfaces` seçeneği huni ve tüm
  terimlerin **toplamının** eş-enerji yüzeylerini çizer — ligandın gerçekten
  hissettiği şekil budur. Seviyeler ve ızgara çözünürlüğü ayarlanabilir.
* Alttaki `Funnel profile` grafiği artık gerçek izinli bölgeyi (toplam alanın
  `V = 0` konturunu) doldurur; `Potential map` toplam kısıtlamayı gösterir.

### Dosyaya yazılış ve geri okunuş

Her terim bloğunun başına `# @ff-term {…}` biçiminde makine-okunur bir yorum
yazılır. Desmond yorumları yok sayar; arayüz terimleri bu satırdan geri okur,
bloğu yeniden üretip dosyadakiyle karşılaştırır, böylece ikisi sessizce
ayrışamaz. `v_total` içinde arayüzün modelleyemediği bir katkı varsa
(elle eklenmiş bir `v_...`), içe alma bunu **hata** olarak bildirir ve dışa
aktarma dosyayı yazmaz — sessizce düşürmek yerine.

Devre dışı bırakılan terimler `v_total`'e girmez ama işaretleyicileri dosyada
kalır, yani bir sonraki içe almada yerinde bulunur.

---

## 5. Moleküler görüntüleme

Beş grup (protein, ligand, kofaktör/hetero, iyonlar, su) için bağımsız olarak:

* **Gösterim**: Cartoon (tube), Ribbon, Backbone trace, Licorice, Ball & stick,
  Spheres (VdW), Molecular surface, Points, Hidden
* **Renklendirme**: Chain, Element, Secondary structure, Residue type,
  B-factor, Funnel z, Uniform
* **Opaklık** kaydırıcısı

Su öntanımlı olarak gizlidir; `Water only inside the funnel` seçili iken
gösterildiğinde yalnızca huni hacmindeki moleküller çizilir (referans işte
~219 molekül). Moleküler yüzey, atom sayısından bağımsız olarak ızgara
çözünürlüğüne bağlı bir en-yakın-atom mesafe alanından üretilir; `surface grid`
ve `surface probe` ile ayarlanır.

Kamera: `1` eksen boyunca, `2` eksene dik, `3` huniye sığdır, `4` her şeye
sığdır, `5` ligandı ortala. `Ctrl+P` PNG anlık görüntü kaydeder.

---

## 6. Gruplar (CV tanımı)

`Groups` sekmesinde üç grup vardır ve hepsi `.pot` içindeki `atomsel` ifadesine
birebir karşılık gelir:

* **lig** – yanlanan parçacığın kütle merkezi (referans: 7298–7369, 72 ağır atom)
* **site** – cep çerçevesi (Leu110, Tyr114, Glu442, Gln445 omurga N/CA/C/O)
* **core** – gövde çerçevesi (Gly158, Gly196, Tyr197, Ala387 omurga)

Üç yolla düzenlenir:

0. **Tıklayarak** — `Set from clicked residue` düğmesini basılı hale getirip
   3B'de ligandın herhangi bir atomuna tıklamak, o kalıntının **tüm ağır
   atomlarını** gruba yazar (tek seferlik, sonra kendini kapatır). Ligand
   grubunda `whole residue` öntanımlı açıktır; SITE/CORE için kapalıdır, çünkü
   orada tek tek omurga atomu seçmek istersiniz.
1. **Seçim dili** — `chain B and resname LIG and heavy` gibi. Desteklenen
   sözcükler: `chain`, `resname`, `resnum`/`res`, `name`, `element`, `index`,
   `ct`, `heavy`, `hydrogen`, `backbone`, `sidechain`, `protein`, `nucleic`,
   `water`, `ion`, `hetero`, `ligand`, `ca`, `all`, `none`,
   `within <Å> of <seçim>`, `same residue as <seçim>`; `and` / `or` / `not` ve
   parantez.
2. **Atom indeks listesi** — doğrudan `7298,7299,…` yazıp `Set from list`.
   Aralık (`7298-7369`) de kabul edilir.
3. **3B'den seçme** — `Pick in 3-D` düğmesi açıkken sahnede bir atoma
   tıklamak onu gruba ekler/çıkarır.

Her grubun altında canlı olarak atom sayısı, hangi zincir/kalıntılar, element
bileşimi ve kütle merkezi görünür. `Backbone of these residues` düğmesi grubu
dokunduğu kalıntıların N/CA/C/O atomlarına indirger.

### Ctrl+G ile grup önerisi neyi seçer

`Ctrl+G` (**Suggest CV groups**) ligandı bulur ve funnel eksenini tanımlayacak
iki omurga çerçevesini önerir. Ekranda LIG'in yanında **SITE** için
Leu337/Leu338/Thr339/Val370, **CORE** için Val254/Leu261/Glu262/Val263 gibi
amino asitlerin görünmesi **normaldir ve gereklidir**: bunlar yanlanan
parçacığın parçası değildir, yalnızca `z` ekseninin nereden nereye baktığını
sabitler. Yanlanan tek şey `lig` grubudur; SITE ve CORE `.pot` içinde sadece
`center_of_mass` alınıp eksen kurmak için kullanılır (bkz. §7). Cep ağzına
yakın 4 omurga kalıntısı SITE, gövdenin derininde ve cebin karşı tarafında
kalan 4 kalıntı CORE seçilir; ikisinin kütle merkezi arasındaki doğru eksendir.
Omurga (N/CA/C/O) atomları kullanılır çünkü yan zincirler simülasyon sırasında
döner ve ekseni titretir.

Öneri **hiçbir zaman elle kurduğunuz grubun üzerine yazmaz**: LIG'i kendiniz
seçtiyseniz `Ctrl+G` yalnızca boş kalan SITE/CORE'u doldurur, tersi de geçerli.

### Diagnostics: hangi mesafeler kaydedilsin

**Diagnostics** tablosu, yanlanmayan ama `print()` ile her adımda kaydedilen
mesafelerdir (referans: `Tyr114_OH_to_ligCOM_A`, `Tyr197_OH_to_ligCOM_A`).
Giriş alanına **doğrudan kalıntı numarası yazabilirsiniz**; şunların hepsi
kabul edilir:

| Yazdığınız | Ne olur |
|---|---|
| `114` | 114 numaralı kalıntının **tüm ağır atomları** (kütle merkezi alınır) |
| `Tyr114` | aynısı, kalıntı adı doğrulanarak |
| `A:114` | yalnızca A zincirindeki 114 |
| `114:OH` | 114'ün sadece `OH` atomu |
| `A:114:CZ` | zincir + kalıntı + atom |
| `114, 197, 442` | üçü için **ayrı ayrı** birer diagnostik eklenir |
| `chain B and resname LIG and heavy` | tam seçim dili de çalışır |

Atom düzeyinde seçim yapmazsanız kalıntının tümü kullanılır. `Pick in 3-D`
düğmesi açıkken sahnede bir atoma tıklamak da diagnostik ekler; yanındaki
**`just the clicked atom`** kutusu işaretliyse yalnız o atom, değilse
kalıntının tamamı alınır. Tablodaki `atoms` hücresi elle de düzenlenebilir.

Eklenen her diagnostik için `.pot` içine `*_sel = atomsel(...)`,
`center_of_mass`, `norm(min_image(...))` ve `print()` satırları doğru sırada
yazılır. Değişken adları **çakışmayacak biçimde** üretilir: içe alınan dosyada
zaten `d_tyr114` varsa yenisi `tyr114_2` olur, ve bir diagnostik hiçbir zaman
bir şeklin (`w1`, `v_w1`) veya dilin ayrılmış adlarından birini almaz — tek
atama kuralı (§14) böylece hiç bozulmaz. Aynı ad iki kez geçerse Check sekmesi
bunu hata olarak bildirir.

---

## 7. MetaD sekmesi ve Desmond karşılıkları

| Arayüz | `.pot` karşılığı | Not |
|---|---|---|
| CV space 1-D / 2-D | `declare_meta dimension`, `meta(...)` dizileri | 2-D'de `array(hill,sigma_z,sigma_rho)` ve `array(z,rho)` yazılır |
| hill height `h0` | `h0` | temperleme öncesi Gauss yüksekliği |
| `σ z`, `σ ρ` | `sigma_z`, `sigma_rho` | çekirdek genişliği |
| bias factor `γ`, `temperature` | `ktemp` yorum satırı | `kTemp = (γ−1)·k_B·T` |
| `kTemp` | `ktemp` | `Keep kTemp literal exactly as imported` işaretliyken içe alınan basamaklar korunur |
| first hill, hill interval | `declare_meta first`, `interval` | ps |
| kernel cutoff | `declare_meta cutoff` | **σ birimindedir**: Desmond `|Δcv|/σ > cutoff` olan Gauss'ları atlar (öntanımlı 9). Panelde Å karşılığı da gösterilir |
| kernel file / restart hills | `declare_meta name`, `initial` | `$JOBNAME.kerseq` |
| CV file / first / interval | `declare_output` | `$JOBNAME.cvseq` |
| print tablosu | `print("etiket",değişken);` | sıra korunur, ekleyip çıkarabilirsiniz |

`Run summary` kutusu koşudaki toplam tepe sayısını, tepe/ns hızını, enerji
biriktirme hızını, `ΔT = (γ−1)T`'yi, `kTemp`'ten geri hesaplanan γ'yı ve
çekirdek kesme mesafesini gösterir. Referans iş: 249 951 tepe, 500 tepe/ns,
50 kcal/mol/ns, γ = 15.000000, kTemp = 8.624466483.

İyi-temperleme dosyanın kendi içinde yapılır (Desmond'un FILE tabanlı
metadinamiği için standart yaklaşım): biriken yanlanma sıfır yükseklikli bir
`meta()` çağrısıyla okunur, sonraki tepe `exp(−V/kTemp)` ile ölçeklenir, ikinci
`meta()` çağrısı bu yüksekliği biriktirir.

---

## 8. İş dosyaları ve tutarlılık

`Job files` sekmesi `.cfg`, `.msj` ve `.sh` dosyalarını **metin üzerinde
cerrahi olarak** düzenler: yalnızca değiştirdiğiniz değerin yer aldığı aralık
değişir, yorumlar ve biçim korunur.

* **`.cfg`**: üretim süresi (ns), sıcaklık, kesme yarıçapı, iç zaman adımı,
  ensemble sınıfı/integratörü, termostat/barostat τ, trajectory / eneseq /
  checkpoint / yapı çıktısı aralıkları, hız tohumu.
* **`.msj`**: sekiz aşamalı zincir tablo halinde; üretim aşaması mavi
  işaretlidir ve `meta = FILE`, `meta_file`, `cfg_file` alanları gösterilir.
  Aşama sürelerini tablodan değiştirebilirsiniz.
* **`.sh`**: `-HOST`, `-cpu`, `-maxjob`, `-mode`, `-lic`, `-description`.

**İş adını değiştirdiğiniz anda** `meta_file`, `cfg_file` ve `JOBNAME`
birlikte güncellenir; beş dosya hiçbir zaman tutarsız bir ara durumda kalmaz.
`.cfg` içindeki `meta_file = ?` bilinçli olarak `?` bırakılır, çünkü onu
Multisim aşamadan doldurur.

Sıcaklığı `.cfg`'de değiştirdiğinizde potansiyelin `T` değeri de takip eder;
`kTemp` kilidi açıksa `kTemp` yeniden hesaplanır.

---

## 9. Check sekmesi: ne doğrulanıyor

Her düzenlemeden sonra otomatik çalışır. Kontrol edilenler:

* **Seçimler** – boş grup, aralık dışı indeks, hidrojen içeren CV grubu,
  çerçevede su/iyon, yinelenen indeks, ligandın kaç kalıntıya yayıldığı.
* **Çerçeve** – SITE–CORE eksen uzunluğu, grupların dönme yarıçapı, eksenin
  kutu yarı-kenarını aşması (`min_image` işaret değişimi riski).
* **Geometri** – `z_max > z_min`, `z_cc` aralık içinde, `r_cyl > 0`,
  `cone_slope ≥ 0`, `k_rad`, `k_z > 0`.
* **Başlangıç durumu** – ligandın `z₀`, `ρ₀`, `r_allowed(z₀)` ve başlangıç
  kısıt enerjisi. Referans işte `z₀ = −1.026 Å`, `ρ₀ = 1.342 Å`,
  `r_allowed = 20.57 Å`, `V = 0` (yani t = 0'da hiçbir itme yok).
* **Kutu** – kısıtın periyodik kutu yüzlerine en küçük uzaklığı; bağsız
  kesmeden (9 Å) küçükse uyarı, kutu dışına çıkıyorsa hata. Ölçüm **gerçek
  geometri** üzerinden yapılır: huni zarfı ekseni etrafında döndürülür, her
  şekil ise **kendi çerçevesinde** örneklenir. Bu yüzden eksenden uzağa
  konmuş bir küre, "eksen etrafında döndürülseydi taşardı" diye yanlışlıkla
  taşıyor sayılmaz — kutu denetimi ile §3b'deki sıkıştırma aynı noktaları
  okur, dolayısıyla ikisi asla birbiriyle çelişemez. Referans işte
  açıklık 11.78 Å.
* **Adlar** – her şeklin ve her diagnostiğin değişken adının benzersizliği
  (Desmond'da bir ada yalnız bir kez atama yapılabilir).
* **Çıkış kanalı** – `z > z_cc` bölgesindeki silindirde çözünen ağır atom
  bulunmaması (referansta 0 atom, yani kanal saf çözücü) ve huni hacmindeki
  toplam atom sayısı.
* **İyi-temperleme** – `kTemp` ↔ γ tutarlılığı, potansiyeldeki T ile `.cfg`
  sıcaklığının eşitliği, `σ_z`'nin CV aralığına oranı, çekirdek kesmesi,
  ilk tepenin koşu içinde kalması.
* **`.cfg`** – kutu ≥ 2 × kesme, `meta_file = ?`, üretimde hız yeniden
  rastgeleleştirmenin `inf` olması, zaman adımı, kare sayısı, son checkpoint.
* **`.msj`** – `meta = FILE`, `meta_file`/`cfg_file` adlarının dışa aktarılacak
  adlarla birebir uyuşması, üretim öncesi denge süresi, son aşamada kalan
  konum kısıtları, son checkpoint.
* **`.sh`** – `JOBNAME` ile dosya adlarının eşleşmesi, multisim çağrısı,
  `$SCHRODINGER` kontrolü, lisans belirteci.

---

## 10. Dışa aktarma

`Job files ▸ Export` bölümünde klasörü, iş adını, `.cms`'in nasıl
yerleştirileceğini (kopya / sabit bağ / sembolik bağ / dokunma) ve hangi
dosyaların yazılacağını seçin, sonra **Export ready-to-run job set**.

Yazma öncesinde şu olur: üretilen `.pot` metni bellekte **bağımsız bir
M-expression yorumlayıcısıyla** yeniden okunur ve elde edilen `z`, `ρ`,
`r_allowed`, `V_rad`, `V_z`, `axis_len`, `hill`, `v_total` değerleri arayüzün
kendi modeliyle karşılaştırılır; ayrıca huni çevresinde 4000 rastgele konumda
tüm alan karşılaştırılır. Uyuşmazlık varsa **hiçbir dosya yazılmaz** (isterseniz
açık onayla zorlayabilirsiniz). Referans işte sapma 0.0, alan sapması ~5 × 10⁻¹².

Karşılaştırma **bağıl** yapılır (eşik 10⁻⁹). Dik bir duvar birkaç ångström
dışarıda 10⁹ kcal/mol'e ulaşır; orada bir `double`'ın son basamağı zaten
10⁻⁷'dir, dolayısıyla iki farklı toplama sırası mutlak anlamda hiçbir zaman
10⁻⁶'nın altında uyuşamaz. Mutlak eşik bu saf yuvarlamayı hata sayardı; bağıl
eşik ise gerçek bir anlam hatasını (bağıl 10⁻³ ve üzeri) yine yakalar.

**Eksik iş dosyası varsa üretilir.** Yalnız bir `.cms` içe alıp sıfırdan huni
kurduysanız ortada `.msj`/`.cfg` yoktur ve tek başına bir potansiyel
çalıştırılamaz; bu durumda dışa aktarma standart Desmond protokolünü yazar:
Brownie NVT → NVT 10 K → NPT 10 K → NPT T → serbest NPT → dengeleme → `meta =
FILE` ile üretim (7 `simulate` aşaması), ve buna eşlik eden `.cfg`
(`meta_file = ?`, `randomize_velocity.interval = inf`, MTK NPT). Rapor bunu
açıkça bildirir; dosyalar `Job files` sekmesinde düzenlenebilir.

Sonuç kutusu yazılan dosyaları ve çalıştırma komutunu verir:

```bash
cd <klasör> && ./<işadı>.sh
```

`.sh` çalıştırılabilir olarak yazılır ve `$SCHRODINGER` değişkenini bekler.

İçe alınan potansiyeli hiç değiştirmeden dışa aktarırsanız dosya **bayt bayt
aynı** çıkar; bu bir testle güvenceye alınmıştır. `.pot` sekmesi üretilen metni
sözdizimi renklendirmesiyle ve içe alınan dosyaya göre farkını (diff) gösterir.

---

## 11. "Suggest funnel from pocket"

`Funnel` sekmesindeki düğme (veya `Ctrl+F`) mevcut ligand konumundan yola
çıkarak bir başlangıç geometrisi önerir:

1. `z_min` = ligandın `z`'sinin 3 Å altı (aşağı yuvarlanmış).
2. Eksen üzerinde 0.5 Å adımlarla ilerleyip, en yakın çözünen ağır atoma
   uzaklığın 10 Å boyunca `r_cyl + 1.5 Å`'yi aştığı ilk noktayı `z_cc` yapar.
3. `z_max = z_cc + 8 Å`, ardından huni zarfı kutu yüzlerinden bağsız kesme
   kadar açık kalana dek 1 Å'lık adımlarla geri çeker.
4. Koni eğimini 30°'den ve `r_allowed(z_min) ≥ ρ₀ + 4 Å` koşulundan büyük
   olanı seçer.

Seçtiği değerleri ve gerekçesini bir pencerede özetler; `Ctrl+Z` ile geri
alınır.

---

## 11b. Kaynak tezgâhı: her Desmond `.pot` dosyası için

`Tools ▸ Open the source workbench…` (Ctrl+Shift+S) ayrı bir pencere açar.
Tasarımcı sekmeleri **bir potansiyel biçimini** modeller; tezgâh ise **dilin
kendisini** modeller. Bu yüzden herhangi bir Desmond potansiyelini açar —
funnel olmayanları, protein–protein, nükleik asit veya membran sistemlerini,
sizin elle yazdıklarınızı, hatta bu arayüzün çizemediklerini de.

**Sabit isim yok.** `lig`, `site`, `core`, `v_total`, `cv`, `v_meta` gibi
adların hiçbiri gerekli değildir. Ligandın hangi grup olduğu, hangi çağrının
yanlama uyguladığı, hangi terimin duvar olduğu **veri akışından** çıkarılır,
isimden değil. `tests/fixtures/arbitrary_names.pot` tam olarak bunu sınar:
içinde bu adların hiçbiri geçmez ve yine de tepe yüksekliği, iyi-temperleme
çarpanı ve üç enerji katkısı eksiksiz bulunur.

### Kaynak metin tek doğruluk kaynağıdır

Dosya asla yeniden üretilmez. Yapısal bir düzenleme, kaynağın yalnızca ilgili
**aralığına** yama uygular; geri kalan her bayt — girinti, yorum, sayıların
yazılış biçimi, ifade sırası, satır sonları — kopyalanır. Anlamadığı bir yapı
silinmez: tam aralığıyla birlikte `opaque` düğüm olarak korunur ve "modellenmedi"
diye işaretlenir. Gelecekteki bir Desmond sürümünün eklediği bir fonksiyon
tanınmaz ama **geçersiz de sayılmaz**; olduğu gibi saklanır ve kararı resmi
doğrulayıcıya bırakılır.

### Yedi bağımsız doğrulama katmanı

Tek bir "Geçerli/Geçersiz" lambası yoktur. Her katmanın kendi durumu vardır
(`PASS` / `WARN` / `FAIL` / `not run` / `STALE`):

| # | Katman | Neyi söyler |
|---|---|---|
| 1 | Source syntax | Bu arayüzün lexer/CST'si dosyayı kayıpsız okudu mu |
| 2 | Model coverage | Yapısal görünüm dosyanın ne kadarını anlıyor |
| 3 | Symbols and data flow | Semboller, kapsamlar, tipler, bağımlılık grafiği |
| 4 | Atom selections | Seçimler gerçek bir `.cms`'e karşı çözüldü mü |
| 5 | **Desmond engine** | Kurulu Schrödinger ayrıştırıcısının kararı — **tek yetkili** |
| 6 | Physical checks | Fiziksel/sayısal akıl kontrolleri |
| 7 | Job files | `.pot`/`.cms`/`.msj`/`.cfg` çapraz tutarlılığı |

**Beşinci katman çalışmadan hiçbir şey "Desmond-geçerli" denemez.** Çalışmadıysa
başlık şunu yazar: *"Desmond validation not performed."* Metni tek karakter
değiştirdiğinizde o katman anında `STALE` olur ve çalıştırmaya hazır export
yeniden engellenir (`OFF008`). Doğrulama, `.pot` ve `.cms`'in **sha256
özetleriyle** birlikte kaydedilir; bir manifest'ten koşu birebir yeniden
üretilebilir (sürüm, build, argv, çıkış kodu, zaman damgası, süre).

### İki ayrı çıkış yolu

* **Save source** — metni olduğu gibi, bayt bayt yazar. Atomik: geçici dosyaya
  yazar, `fsync` eder, sonra `os.replace` ile yerine koyar; dosya siz açtıktan
  sonra diskte değiştiyse üzerine yazmadan önce sorar. **Her zaman kullanılabilir.**
* **Export run-ready** — katmanlar izin vermezse **hiçbir şey yazmaz** ve hangi
  fiziksel katkının kaybolabileceğini söyler. Modellenemeyen bir yapı potansiyele
  katkı veriyorsa (`MOD004`) veya resmi doğrulama bu metin için geçerli değilse
  (`OFF001`/`OFF008`) reddedilir.

### MetaD ve iyi-temperleme: desen değil, veri akışı

`meta()` çağrıları **her derinlikte** bulunur: bir fonksiyon argümanının içinde,
`if/then/else` dalında, `series` gövdesinde, `{}` bloğunda, `print()`
argümanında. Yorum veya dizge içindeki `meta(` metni sayılmaz.

Her çağrı sınıflandırılır: **bias** (enerjiye ulaşan), **probe** (birikmiş
yanlamayı geri okuyan sıfır yükseklikli çağrı), **intermediate**, **diagnostic**,
veya **undetermined**. İyi-temperleme ilişkisi `h(t) = h₀·exp(−V/kΔT)`
ispatlanırken hiçbir metin deseni aranmaz: tepe yüksekliğinin veri akışında bir
`exp()` bulunur, argümanının akışında **aynı biriktiricinin** sıfır yükseklikli
probu bulunur, ve o probun katsayısının işareti sembolik olarak hesaplanır.
Eksi işareti nerede olursa olsun bulunur — tekli eksi, negatif sabit,
`0.0 - dT`, ya da sekiz ara atamaya dağılmış bir çarpan.

`tests/fixtures/metad_2d_wt.pot` bunu kasten zorlaştırır: hiçbir satırda
`h0*exp(-V/kT)` deyimi görünmez, eksi işareti kendi atamasında yaşar. Arayüz
yine de **kΔT = 8.624466** ve **h₀ = 0.1** değerlerini kurtarır. İspatlanamazsa
"MetaD detected; well-tempered construction not confirmed" der — "MetaD yok"
demez.

### Başsız kullanım

```bash
python -m funnelforge.potcheck run.pot --cms run.cms --official
```

Aynı çekirdek kütüphaneyi kullanır, yani CI'daki sonuçla ekrandaki sonuç
ayrışamaz. `--json` makine okunur çıktı verir; çıkış kodları: 0 temiz,
1 hata var, 2 dosya okunamadı, 3 resmi doğrulayıcı çalıştırılamadı.
`--list-installations` bulunan Schrödinger kurulumlarını listeler.

![Kaynak tezgâhı](docs/12-workbench-ache.png)

*Yukarıdaki ekran görüntüsü, bu arayüzün hiç görmediği bir sistemi gösteriyor:
farklı bir araç zinciriyle üretilmiş bir asetilkolinesteraz/G2N paketi. Grup
adları `frame_o`/`frame_u`/`frame_v` — yani bu programın beklediği adların
hiçbiri. 18 seçim çözülmüş, prob ile bias ayırt edilmiş, iyi-temperleme
kΔT = 8.62447 ve h₀ = 0.25 olarak veri akışından kurtarılmış, ve resmi
Desmond ayrıştırıcısı metni kabul etmiş.*

Ayrıntılar: [docs/architecture.md](docs/architecture.md),
[docs/diagnostic-codes.md](docs/diagnostic-codes.md),
[docs/official-validation.md](docs/official-validation.md),
[docs/known-limitations.md](docs/known-limitations.md).

---

## 12. Testler

```bash
conda activate cugraph_env
cd /home/bugra/Claude/potantial
python tests/test_funnelforge.py            # 50 çekirdek testi
python tests/test_lang.py                   # 39 dil/belge testi
xvfb-run -a python tests/test_gui.py        # 31 tasarımcı arayüz testi
xvfb-run -a python tests/test_source_gui.py # 14 kaynak tezgâhı testi
# ya da:  python -m pytest tests -q
```

Çekirdek testleri: `.cms` çözümlemesi ve kuvvet alanı kütleleri, kalıntı
imzaları, `.pot` bayt-bayt gidiş-dönüşü, literal korunması, elle hesapla
karşılaştırılan CV'ler, duvar enerjileri, iyi-temperleme aritmetiği, kutu
açıklığı, çıkış kanalı, yorumlayıcının model ile uyuşması (skaler ve
vektörleştirilmiş), **M-expression dil kuralları** (tek atama, dizi eşlemesi,
`^` tam sayı kuvveti, blok/`series`/indeks, `sign`/`pow`/`mod`/`gibbs_*`,
Desmond'da olmayan fonksiyonların reddi, tekli eksi ile `^` önceliği), statik
ifade denetleyicisi, 2-D potansiyel, seçim değişiminin yorumlara yansıması,
eklenen diagnostiğin gidiş-dönüşü, **torna terimi, serbest denklem terimi,
sürekli bölge anahtarı, küre/pencere ve grup hedefleri, terimlerin
gidiş-dönüşü, devre dışı terimlerin korunması, modellenemeyen katkının
reddi, huninin kapatılması, terim denetimleri, toplam alan**, kasıtlı
bozulmaların yakalanması, `.msj`/`.cfg`/`.sh` düzenlemeleri, tutarlı dışa
aktarma ve oturum kaydı.

Bu turda eklenenler:

* `test_exported_set_matches_the_desmond_rules` — ağır biçimde düzenlenmiş bir
  işi dışa aktarıp beş dosyanın tamamını **Desmond kurallarına göre** denetler:
  `.pot` içinde tek atama (declare blokları ve yorumlar hariç), yasak fonksiyon
  yokluğu, tam sayı üsler, `print()` hedeflerinin tanımlı olması, `v_total`'ın
  bütün katkıları içermesi; `.msj`'de `meta = FILE` ve `meta_file`/`cfg_file`
  adlarının dışa aktarılan adlarla eşleşmesi; `.cfg`'de `meta_file = ?`,
  sıcaklığın potansiyeldeki `T` ile aynı olması, kutunun ≥ 2 × kesme olması;
  `.sh`'de `JOBNAME` eşleşmesi ve çalıştırma izni; sonra yeniden içe alıp
  **bayt bayt aynı** dosyayı üretmesi.
* `test_a_bare_structure_still_exports_a_runnable_set` — yalnız `.cms` ile
  kurulan iş de tam beş dosya verir ve o dosyalar temiz biçimde geri okunur.
* `test_random_editing_never_produces_a_broken_file` — 40 turluk rastgele
  düzenleme (şekilleri kutunun çok dışına atma, eğme, pencere boyunu değiştirme,
  ekleme/silme, diagnostik ekleme). Her turda hiçbir şey kutu dışında kalmamalı,
  iki farklı kutu ölçümü çelişmemeli, hiçbir eksenel pencere ters dönmemeli,
  Check hata vermemeli; her 20 turda bir dışa aktarma doğrulanmalı ve
  gidiş-dönüşü bayt bayt aynı olmalı.
* `test_verification_tolerance_is_relative_not_absolute` — bağıl eşiğin saf
  yuvarlamayı geçirdiğini ama emitlenen kuvvet sabitindeki 10⁻⁶'lık gerçek bir
  değişikliği yakaladığını gösterir.
* `test_diagnostics_accept_a_residue_number` ve
  `test_suggest_groups_never_overwrites_what_you_have` (arayüz tarafında).

Arayüz testleri: tüm gösterim/renk kombinasyonlarının çizilmesi, huni
önayarları ve kameralar, panelden yapılan düzenlemenin `.pot` metnine akması,
tutamak sürüklemesi ve geri alma, origin tutamağının çerçeveyi kaydırması,
3B'den atom seçme, seçim dili, diagnostik ekleme/çıkarma, γ ↔ kTemp,
`.cfg`/`.sh` yamalama, sıcaklık tutarlılığı, huni önerisi, **dört şekil
teriminin de kurulup çizilmesi, torna profili düzenleme ve önizleme, geçersiz
profilin yakalanması, denklem terimi + bölge anahtarı, huninin kapatılıp
toplam alan görünümü**, Shapes sekmesindeki 34 denetimin tek tek gerçekten
uygulanması, tutamakların fareyle yakalanabilmesi, panelden ve uçlardaki
tutamaklardan eğim verme, kutu sınırının arayüzde de tutması, kalıntı numarası
ile diagnostik ekleme, grup önerisinin var olanı ezmemesi, arayüzden dışa
aktarma + anlık görüntü, oturum, prob ve doğrulama eylemleri.

---

## 13. Klavye

| Kısayol | İşlev |
|---|---|
| `Ctrl+O` / `Ctrl+E` | iş setini içe al / dışa aktar |
| `Ctrl+S` / `Ctrl+Shift+S` | oturumu kaydet / yalnızca `.pot` kaydet |
| `Ctrl+Z` / `Ctrl+Shift+Z` | geri al / yinele |
| `Ctrl+F` / `Ctrl+G` | huniyi cebe oturt / CV grubu önerisi |
| `1` `2` `3` `4` `5` | eksen / yan / huniye sığdır / her şeye sığdır / ligand |
| `F5` / `F6` | yeniden denetle / potansiyeli sayısal doğrula |
| `F9` / `F10` | sağ panel / alt grafikler |
| `Ctrl+P` | anlık görüntü |

---

## 14. Notlar ve sınırlar

* Arayüz etiketleri `.pot` değişken adlarıyla birebir aynı tutuldu
  (`z_cc`, `r_cyl`, `cone_slope`, `k_rad`, `k_z`, `h0`, `sigma_z`, `ktemp`),
  böylece paneldeki her sayı dosyada gözle bulunabilir.
* `.cms` hiç değiştirilmez: atom sırası, kuvvet alanı, su ve iyonlar aynen
  korunur; yalnızca iş klasörüne kopyalanır/bağlanır.
* Tutamaklar VTK'nın donanım seçicisiyle değil, fare ışınına göre CPU'da
  seçilir: donanım geçişi önde duran saydam kabuğu döndürüyordu ve tutamaklar
  hiç yakalanamıyordu. Sürükleme sırasında olay artık doğru şekilde
  durdurulduğu için kamera da beraber dönmüyor.
* İçe alınan dosyalar arasında `.pot` yoksa hiçbir kısıtlama oluşturulmaz;
  yeni `FunnelSpec` tamamen boştur (huni kapalı, geometri sıfır) ve 3B görünüm
  de buna göre boş kalır. Aynı ana ada sahip bir `.pot` **varsa** topluca içe
  alınır — bu kasıtlıdır.
* Yorumlayıcı `meta()` çağrılarını t = 0'da sıfır yanlanma ile değerlendirir;
  yani doğrulama koşunun başlangıç durumunu kontrol eder (biriken tepe geçmişi
  simülasyon sırasında oluşur).
* Şeffaflık için depth peeling yalnızca GL bağlamı alfa düzlemi veriyorsa
  açılır; `View ▸ Toggle high-quality transparency` ile elle
  değiştirebilirsiniz. Açılamazsa sıradan alfa karışımı kullanılır.
* Kütleler `ffio_sites`'tan okunur (C = 12.01115, N = 14.0067, O = 15.9994,
  S = 32.064), bu yüzden kütle merkezleri Desmond'un hesapladığıyla birebir
  aynıdır.
* İlk `.cms` okuması ~0.9 s sürer; sonuç `~/.cache/funnelforge` altına
  önbelleklenir, sonraki açılışlar anında olur.

---

## 15. Ekran görüntüleri

| | |
|---|---|
| ![](docs/02-groups-and-potential-map.png) | ![](docs/03-job-files-and-wall-cuts.png) |
| CV grupları + potansiyel haritası | İş dosyaları + duvar kesitleri |
| ![](docs/04-cross-section.png) | ![](docs/05-volume-glow.png) |
| Eksenden geçen kesit düzlemi | Hacimsel parıltı (duvarı saran kabuk) |
| ![](docs/07-shapes-lathe.png) | ![](docs/08-shapes-combined-field.png) |
| Torna terimi: profil, önizleme ve gerçek izinli bölge | Huni + terimlerin toplamının eş-enerji yüzeyi |
| ![](docs/09-multiple-terms-3d.png) | ![](docs/10-shapes-expression-region.png) |
| Aynı potansiyelde dört ayrı kısıtlama | Denklemle tanımlı terim (yeşil) ve etkin bölge halkaları |
| ![](docs/11-no-funnel-imported.png) | ![](docs/12-funnel-added-and-placement.png) |
| `.pot` içermeyen içe alma: huni yok, hiçbir şey uydurulmaz | Huni eklendikten sonra tam sayısal düzenleme ve gövdeye sabit çerçeve |
| ![](docs/13-handles-overlay.png) | |
| Tutamaklar saydam şeklin üstünde: görünür ve tıklanabilir | |

![Cepteki ligand](docs/06-ligand-in-pocket.png)

---

## 16. Dosya haritası

```
funnelforge/
  core/
    maestro.py    Maestro/.cms metin biçimi okuyucusu (satır aralıklı, hızlı)
    cms.py        Yapı modeli: koordinat, kütle, bağ, kalıntı, kutu, min_image
    elements.py   Element kütleleri, yarıçapları, CPK renkleri, kalıntı sınıfları
    asl.py        Atom seçim dili
    funnel.py     FunnelSpec + FunnelModel: CV'ler, duvar potansiyeli, ağlar, denetimler
    terms.py      Şekil terimleri: torna, küre, pencere, serbest denklem + bölge anahtarı
    potfile.py    .pot çözümleyici ve üretici (bayt-bayt gidiş-dönüş)
    mexpr.py      Desmond M-expression yorumlayıcısı + statik denetleyici (kılavuz bölüm 11)
    blocktext.py  .msj/.cfg süslü parantez sözdizimi için aralık koruyan düzenleyici
    jobfiles.py   CfgFile / MsjFile / ShFile + iş seti keşfi
    project.py    Job: içe alma, denetleme, doğrulama, dışa aktarma, oturum
  gui/
    theme.py      Koyu tema, renk ölçekleri
    widgets.py    Hassas sayı satırları, okumalar, sorun tablosu
    reps.py       Moleküler gösterimler (VTK)
    funnel_actors.py  Huni yüzeyleri, kabuklar, kesit, hacim, cetvel, tutamaklar
    viewer.py     3B görünüm, tutamak sürükleme, atom seçme, kamera
    panels.py     Funnel / MetaD / Groups panelleri
    shapes_panel.py  Shapes sekmesi: terim listesi, torna önizlemesi, denklem editörü
    panels_job.py Job files / Check / .pot / View panelleri
    plots.py      Profil grafikleri (matplotlib)
    main_window.py Ana pencere, menü, akış
tests/            Çekirdek ve arayüz testleri
funnelforge.sh    Başlatıcı
install.sh        Bağımlılık kurulumu + hızlı test
```
