"""Entry point: ``python -m funnelforge [job file]``."""

from __future__ import annotations

import os
import sys


def main(argv=None) -> int:
    argv = list(sys.argv if argv is None else argv)
    os.environ.setdefault("QT_AUTO_SCREEN_SCALE_FACTOR", "1")
    from PyQt5 import QtCore, QtGui, QtWidgets
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_ShareOpenGLContexts, True)
    try:
        QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling,
                                             True)
    except AttributeError:
        pass
    app = QtWidgets.QApplication(argv)
    app.setApplicationName("FunnelForge")
    app.setOrganizationName("FunnelForge")

    from .gui import theme
    from .gui.main_window import MainWindow
    app.setStyle("Fusion")
    pal = QtGui.QPalette()
    pal.setColor(QtGui.QPalette.Window, QtGui.QColor(theme.BG0))
    pal.setColor(QtGui.QPalette.WindowText, QtGui.QColor(theme.FG0))
    pal.setColor(QtGui.QPalette.Base, QtGui.QColor(theme.BG2))
    pal.setColor(QtGui.QPalette.AlternateBase, QtGui.QColor(theme.BG1))
    pal.setColor(QtGui.QPalette.Text, QtGui.QColor(theme.FG0))
    pal.setColor(QtGui.QPalette.Button, QtGui.QColor(theme.BG2))
    pal.setColor(QtGui.QPalette.ButtonText, QtGui.QColor(theme.FG0))
    pal.setColor(QtGui.QPalette.Highlight, QtGui.QColor(theme.ACCENT_DIM))
    pal.setColor(QtGui.QPalette.HighlightedText, QtGui.QColor("#ffffff"))
    pal.setColor(QtGui.QPalette.ToolTipBase, QtGui.QColor(theme.BG2))
    pal.setColor(QtGui.QPalette.ToolTipText, QtGui.QColor(theme.FG0))
    pal.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.Text,
                 QtGui.QColor(theme.FG2))
    pal.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.WindowText,
                 QtGui.QColor(theme.FG2))
    app.setPalette(pal)
    app.setStyleSheet(theme.QSS)

    path = None
    for a in argv[1:]:
        if not a.startswith("-") and os.path.exists(a):
            path = a
            break
    win = MainWindow(path)
    win.show()
    return app.exec_()


if __name__ == "__main__":
    raise SystemExit(main())
