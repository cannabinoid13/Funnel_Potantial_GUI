"""Adapter onto the officially installed Schrodinger Desmond toolchain.

Only this package may pronounce a potential Desmond-valid.  It does so by
running the suite's own enhanced-sampling parser in a separate process under
the suite's own interpreter, and reporting exactly what came back together
with a manifest that makes the run reproducible.

Typical use from the GUI, on a worker thread::

    from funnelforge.core.desmond import default_installation, validate

    inst = default_installation()
    if inst is None:
        ...              # tell the user no suite was found
    result = validate(pot_text, cms_path, installation=inst, cancel=stop_event)
    if result.ok:
        ...
    elif result.ran:
        show(result.error_message, result.line, result.col)
    else:
        explain(result.error_message)      # we never got a verdict
"""

from .adapter import (
    ADAPTER_VERSION,
    CAPTURE_CAP_BYTES,
    MESSAGE_CAP_CHARS,
    NO_TOPOLOGY_REASON,
    OFFICIAL_REASONS,
    TESTED_RELEASES,
    Installation,
    OfficialResult,
    default_installation,
    discover_installations,
    validate,
)

__all__ = [
    "ADAPTER_VERSION",
    "CAPTURE_CAP_BYTES",
    "MESSAGE_CAP_CHARS",
    "NO_TOPOLOGY_REASON",
    "OFFICIAL_REASONS",
    "TESTED_RELEASES",
    "Installation",
    "OfficialResult",
    "default_installation",
    "discover_installations",
    "validate",
]
