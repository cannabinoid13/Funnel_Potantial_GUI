"""A source-preserving bridge from custom M-expressions to the designer.

The imported program remains authoritative.  Controls patch only the spans
they own; preview evaluates the same program, including additional forces.
No funnel frame, hill expression or diagnostic is regenerated on import.
"""
from __future__ import annotations

from functools import lru_cache
import json
import math
import re

import numpy as np

from .lang import cst, sema, patch


SCALARS = ("z_cc", "r_cyl", "cone_slope", "k_rad", "z_min", "z_max",
           "k_z", "ktemp", "h0", "sigma_z", "sigma_rho")
POSE = ("origin_mode", "origin_frac", "origin_offset", "origin_lat1",
        "origin_lat2", "axis_tilt_deg", "axis_azimuth_deg")
DECL = {"kernel_cutoff": ("declare_meta", "cutoff"),
        "dimension": ("declare_meta", "dimension"),
        "meta_first": ("declare_meta", "first"),
        "meta_interval": ("declare_meta", "interval"),
        "kerseq_name": ("declare_meta", "name"),
        "initial_kernels": ("declare_meta", "initial"),
        "cvseq_name": ("declare_output", "name"),
        "cv_first": ("declare_output", "first"),
        "cv_interval": ("declare_output", "interval")}


@lru_cache(maxsize=24)
def _analysis(text):
    return sema.analyse(cst.parse(text))


def _unwrap(node):
    while node.kind == cst.PAREN:
        node = node.children[0]
    return node


def _resolve(an, node, visited=None):
    node = _unwrap(node)
    visited = set() if visited is None else visited
    while node.kind == cst.NAME and node.name in an.symbols:
        if node.name in visited:
            break
        visited.add(node.name)
        node = _unwrap(an.symbols[node.name].value)
    return node


def _deps(an, names, stop=()):
    out, pending = set(), list(names)
    while pending:
        name = pending.pop()
        if name in out or name in stop:
            continue
        out.add(name)
        if name in an.symbols:
            pending.extend(an.symbols[name].deps)
    return out


def _name(node):
    node = _unwrap(node)
    return node.name if node.kind == cst.NAME else ""


def _constant_name(an, node):
    name = _name(node)
    return name if name and sema.const_value(an, node) is not None else ""


def _sum_names(node):
    node = _unwrap(node)
    if node.kind == cst.BINARY and node.op == "+":
        return _sum_names(node.children[0]) + _sum_names(node.children[1])
    return [_name(node)] if _name(node) else []


def import_source(spec, text, report):
    """Recognise geometry by data flow and attach serialisable edit metadata.

    Returns False for programs without an identifiable cylindrical frame;
    those remain available in the general source workbench.
    """
    from .funnel import Selection
    from .potfile import parse_asl_atoms
    an = _analysis(text)
    if an.parse.problems or an.energy_expr is None:
        return False
    variables, scalar_map = {}, {}
    candidates = []
    for mc in an.metas:
        cvs = sema.resolve_array(an, mc.cvs) if mc.cvs else None
        if cvs:
            candidates.extend(_name(n) for n in cvs)
    candidates += ["z"] + list(an.symbols)
    for candidate in dict.fromkeys(candidates):
        if candidate not in an.symbols:
            continue
        node = _resolve(an, an.symbols[candidate].value)
        if node.kind != cst.CALL or node.name != "dot" or len(node.children) != 2:
            continue
        for displacement, axis_node in (node.children, node.children[::-1]):
            dn = _resolve(an, displacement)
            if dn.kind != cst.CALL or dn.name != "min_image":
                continue
            diff = _resolve(an, dn.children[0])
            if diff.kind != cst.BINARY or diff.op != "-":
                continue
            com_node = _resolve(an, diff.children[0])
            if com_node.kind != cst.CALL or com_node.name not in ("center_of_mass", "center_of_geometry"):
                continue
            axis, origin = _name(axis_node), _name(diff.children[1])
            lig = _name(com_node.children[0])
            if axis and origin and lig:
                geometric = candidate
                while _name(an.symbols[geometric].value) in an.symbols:
                    geometric = _name(an.symbols[geometric].value)
                variables.update(z=geometric, axis=axis, origin=origin,
                                 lig_com=_name(diff.children[0]), lig=lig)
                break
        if variables:
            break
    if not variables:
        return False
    z = variables["z"]
    # The radial excess explicitly couples a radial CV to the allowed radius.
    for sym in an.symbols.values():
        n = _resolve(an, sym.value)
        if n.kind != cst.IFELSE:
            continue
        cond = _resolve(an, n.children[0])
        if cond.kind != cst.BINARY or cond.op != "-":
            continue
        radial, radius = (_name(x) for x in cond.children)
        if not radial or not radius or radius not in an.symbols:
            continue
        rn = _resolve(an, cond.children[0])
        if rn.kind == cst.CALL and rn.name in ("sqrt", "norm") and z in _deps(an, [radial]):
            variables.update(rho=radial, r_allowed=radius, rad_excess=sym.name)
            break
    if "rho" not in variables:
        return False
    total_name = _name(an.energy_expr)
    variables["total"] = total_name
    variables["v_total"] = total_name
    total_node = an.symbols[total_name].value if total_name in an.symbols else an.energy_expr
    terms = _sum_names(total_node)
    radial_terms, axial_terms = [], []
    designer_energies = {t.energy_var for t in spec.terms}
    for name in terms:
        if name in designer_energies:
            continue
        deps = _deps(an, [name])
        if any(n.kind == cst.CALL and n.name == "meta"
               for dep in deps if dep in an.symbols
               for n in an.symbols[dep].value.walk()):
            continue
        if variables["rho"] in deps:
            radial_terms.append(name)
        elif z in deps:
            axial_terms.append(name)
    variables["v_rad"] = radial_terms[0] if len(radial_terms) == 1 else ""
    variables["v_z"] = axial_terms[0] if len(axial_terms) == 1 else ""
    for name in ("hill", "axis_len", "v_meta", "v_old"):
        if name in an.symbols:
            variables[name] = name
    # Canonical names are merely preferred; otherwise infer scalar roles from
    # the radius and one-sided inequalities, irrespective of their vocabulary.
    for attr in SCALARS:
        if attr in an.symbols and sema.const_value(an, an.symbols[attr].value) is not None:
            scalar_map[attr] = [attr]
    radius = _resolve(an, an.symbols[variables["r_allowed"]].value)
    if radius.kind == cst.IFELSE:
        rc = _constant_name(an, radius.children[2])
        if rc:
            scalar_map.setdefault("r_cyl", [rc])
        cond = _resolve(an, radius.children[0])
        if cond.kind == cst.BINARY and cond.op == "-" and _name(cond.children[1]) == z:
            cc = _constant_name(an, cond.children[0])
            if cc:
                scalar_map.setdefault("z_cc", [cc])
        constants = [n for n in _deps(an, [variables["r_allowed"]], stop=(z, variables["rho"]))
                     if n in an.symbols and sema.const_value(an, an.symbols[n].value) is not None]
        remaining = [n for n in constants if n not in sum(scalar_map.values(), [])]
        if len(remaining) == 1:
            scalar_map.setdefault("cone_slope", remaining)
    for sym in an.symbols.values():
        node = _resolve(an, sym.value)
        if node.kind != cst.IFELSE:
            continue
        cond = _resolve(an, node.children[0])
        if cond.kind != cst.BINARY or cond.op != "-":
            continue
        left, right = cond.children
        if _name(right) == z and _constant_name(an, left):
            role = "z_min" if sym.name in _deps(an, axial_terms) else None
            if role:
                scalar_map.setdefault(role, [_name(left)])
        if _name(left) == z and _constant_name(an, right) and sym.name in _deps(an, axial_terms):
            scalar_map.setdefault("z_max", [_name(right)])
    for attr, energy_names in (("k_rad", radial_terms), ("k_z", axial_terms)):
        if attr not in scalar_map:
            names = [n for n in an.order if n in _deps(an, energy_names, stop=(z, variables["rho"]))
                     and n in an.symbols and n not in sum(scalar_map.values(), [])
                     and sema.const_value(an, an.symbols[n].value) is not None]
            if names:
                scalar_map[attr] = names
    # Widths may be literals directly inside meta(), or arbitrarily named.
    width_spans = {}
    for mc in an.metas:
        if mc.zero_height:
            continue
        widths = sema.resolve_array(an, mc.hills) if mc.hills else None
        if widths:
            for attr, n in zip(("sigma_z", "sigma_rho"), widths[1:]):
                value = sema.const_value(an, n)
                if value is not None:
                    setattr(spec, attr, float(value))
                    nm = _constant_name(an, n)
                    if nm:
                        scalar_map[attr] = [nm]
                    else:
                        width_spans[attr] = [n.start, n.end]
            if mc.wt and mc.wt.confirmed:
                if mc.wt.h0 is not None:
                    spec.h0 = float(mc.wt.h0)
                if mc.wt.ktemp is not None:
                    spec.ktemp = float(mc.wt.ktemp)
                height = widths[0]
                hdeps = _deps(an, [_name(height)])
                for attr, expected in (("h0", mc.wt.h0), ("ktemp", mc.wt.ktemp)):
                    if expected is None or attr in scalar_map:
                        continue
                    names = [n for n in an.order if n in hdeps and n in an.symbols
                             and sema.const_value(an, an.symbols[n].value) == expected]
                    if len(names) == 1:
                        scalar_map[attr] = names
                    else:
                        roots = [height] + [an.symbols[n].value for n in an.order
                                            if n in hdeps and n in an.symbols]
                        matches = [node for root in roots for node in root.walk()
                                   if node.kind != cst.NAME and sema.const_value(an, node) == expected]
                        if matches:
                            selected = matches[0]
                            width_spans[attr] = [selected.start, selected.end]
        break
    groups = {"lig": variables["lig"]}
    available = [s.name for s in an.selections if s.name != groups["lig"]]
    frame_deps = _deps(an, [variables["origin"], variables["axis"]])
    frame_groups = [name for name in available if name in frame_deps]
    for role, preferences in (("core", ("core", "frame_o")),
                               ("site", ("site", "frame_u")),
                               ("frame_ref", ("fref", "frame_v"))):
        name = next((n for n in preferences if n in frame_groups), "")
        if not name:
            name = next((n for n in frame_groups if n not in groups.values()), "")
        if name:
            groups[role] = name
    if "core" not in groups or "site" not in groups:
        return False
    for role, name in groups.items():
        node = _resolve(an, an.symbols[name].value)
        if node.kind != cst.CALL or node.name != "atomsel" or not node.children:
            return False
        asl = node.children[0].text.strip('"')
        try:
            ids = parse_asl_atoms(asl)
        except ValueError:
            ids = []
        setattr(spec, role, Selection(name, ids, asl))
    for attr, names in scalar_map.items():
        value = float(sema.const_value(an, an.symbols[names[0]].value))
        setattr(spec, attr, value)
    spec.funnel_enabled = bool(radial_terms or axial_terms)
    spec.origin_mode = "absolute"
    spec.origin_offset = spec.origin_lat1 = spec.origin_lat2 = 0.0
    spec.origin_frac = spec.axis_tilt_deg = spec.axis_azimuth_deg = 0.0
    spec.source_adapter = {
        "version": 1, "variables": variables, "groups": groups,
        "scalars": scalar_map, "width_spans": width_spans,
        "radial_terms": radial_terms, "axial_terms": axial_terms,
        "baseline": {name: getattr(spec, name) for name in SCALARS + POSE + tuple(DECL) + ("funnel_enabled",)},
        "group_baseline": {role: list(getattr(spec, role).indices) for role in groups},
        "terms_baseline": [t.to_dict() for t in spec.terms],
        "diagnostics_baseline": [d.__dict__.copy() for d in spec.diagnostics],
        "prints_baseline": [list(p) for p in spec.prints],
    }
    report.errors.clear()
    report.warnings = [w for w in report.warnings if not any(
        fragment in w for fragment in ("default", "will not be re-emitted", "canonical", "models z and rho only", "will be added"))]
    report.unknown_statements.clear()
    report.recognised.append("custom source-preserving funnel frame and potential")
    return True


def _number(value):
    from .potfile import fmt_number
    if not math.isfinite(float(value)):
        raise ValueError("Custom potential parameters must be finite numbers.")
    return fmt_number(value)


def _pose_changed(spec):
    base = spec.source_adapter["baseline"]
    return any(getattr(spec, key) != base[key] for key in POSE)


def _basis_expression(spec, axis_expression):
    """A protein-attached perpendicular vector, without laboratory axes."""
    md = spec.source_adapter
    groups = md["groups"]
    if "frame_ref" not in groups:
        raise ValueError("A third protein frame selection is required for sideways placement or rotation.")
    ref, core = groups["frame_ref"], groups["core"]
    vector = f"min_image(center_of_mass({ref})-center_of_mass({core}))"
    return f"({vector}-dot({vector},({axis_expression}))*({axis_expression}))"


def emit_source(spec):
    """Patch explicitly changed controls while preserving all other bytes."""
    md, text = spec.source_adapter, spec.source_text
    an = _analysis(text)
    edits, base = [], md["baseline"]
    changed = lambda name: getattr(spec, name) != base[name]
    for attr in SCALARS:
        if not changed(attr):
            continue
        if attr == "sigma_rho" and spec.dimension != base["dimension"] and int(spec.dimension) == 2:
            # The new width belongs to the new array component below.
            continue
        names = md["scalars"].get(attr, [])
        if names:
            for name in names:
                node = an.symbols[name].value
                old = float(sema.const_value(an, node))
                value = getattr(spec, attr)
                if len(names) > 1 and base[attr] != 0:
                    value *= old / base[attr]
                edits.append(patch.replace_node(node, _number(value), attr))
        elif attr in md.get("width_spans", {}):
            start, end = md["width_spans"][attr]
            edits.append(patch.Edit(start, end, _number(getattr(spec, attr)), attr))
        else:
            raise ValueError(f"The custom source has no independently editable {attr} parameter; edit its expression in the source workbench.")
    for attr, (which, key) in DECL.items():
        if not changed(attr):
            continue
        decls = [d for d in an.declarations if d.which == which]
        if not decls or key not in decls[0].terms:
            raise ValueError(f"The source does not declare {key}.")
        value = getattr(spec, attr)
        rendered = json.dumps(value, ensure_ascii=False) if isinstance(value, str) else _number(value)
        edits.append(patch.replace_node(decls[0].terms[key], rendered, attr))
    if changed("dimension"):
        dimension = int(spec.dimension)
        if dimension not in (1, 2):
            raise ValueError("The cylindrical designer supports one or two CVs; edit other dimensions in the source workbench.")
        variables = md["variables"]
        for mc in an.metas:
            if mc.index != 0:
                continue
            cvs = sema.resolve_array(an, mc.cvs) if mc.cvs else None
            widths = sema.resolve_array(an, mc.hills) if mc.hills else None
            if not cvs or not widths or len(cvs) not in (1, 2):
                raise ValueError("The custom metadynamics arrays cannot be changed by the cylindrical CV control.")
            def geometric_name(node):
                name = _name(node)
                seen = set()
                while name in an.symbols and name not in seen and _name(an.symbols[name].value):
                    seen.add(name)
                    name = _name(an.symbols[name].value)
                return name
            if geometric_name(cvs[0]) != variables["z"] or (len(cvs) > 1 and geometric_name(cvs[1]) != variables["rho"]):
                raise ValueError("The source biases additional custom CVs; edit their arrays in the source workbench.")
            cv_exprs = [cvs[0].span_text(text)]
            hill_exprs = [widths[0].span_text(text), widths[1].span_text(text)]
            if dimension == 2:
                cv_exprs.append(variables["rho"])
                hill_exprs.append("0.0" if mc.zero_height else _number(spec.sigma_rho))
            # Existing literal widths within this replaced array are rendered
            # here, avoiding overlapping literal and whole-array patches.
            if changed("sigma_z") and "sigma_z" in md.get("width_spans", {}):
                hill_exprs[1] = "0.0" if mc.zero_height else _number(spec.sigma_z)
                edits = [e for e in edits if not (mc.hills.start <= e.start and e.end <= mc.hills.end)]
            edits.append(patch.replace_node(mc.cvs, "array(" + ",".join(cv_exprs) + ")", "CV dimension"))
            edits.append(patch.replace_node(mc.hills, "array(" + ",".join(hill_exprs) + ")", "hill dimension"))
    for role, name in md["groups"].items():
        group = getattr(spec, role)
        if group.indices != md["group_baseline"][role]:
            node = _resolve(an, an.symbols[name].value)
            edits.append(patch.replace_node(node.children[0], json.dumps(group.asl()), role))
    if _pose_changed(spec):
        variables = md["variables"]
        axis_node = an.symbols[variables["axis"]].value
        origin_node = an.symbols[variables["origin"]].value
        axis0 = f"({axis_node.span_text(text)})"
        lateral = bool(spec.origin_lat1 or spec.origin_lat2 or spec.axis_tilt_deg)
        axis = axis0
        if lateral:
            projection = _basis_expression(spec, axis0)
            p1 = f"({projection}/norm({projection}))"
            p2 = f"cross({axis0},{p1})"
            if spec.axis_tilt_deg:
                t, a = math.radians(spec.axis_tilt_deg), math.radians(spec.axis_azimuth_deg)
                axis = f"({_number(math.cos(t))}*{axis0}+{_number(math.sin(t)*math.cos(a))}*{p1}+{_number(math.sin(t)*math.sin(a))}*{p2})"
            e1raw = f"({p1}-dot({p1},{axis})*{axis})"
            e1 = f"({e1raw}/norm({e1raw}))"
            e2 = f"cross({axis},{e1})"
        offset = spec.origin_offset
        if spec.origin_mode == "fraction":
            core, site = md["groups"]["core"], md["groups"]["site"]
            shift = f"{_number(spec.origin_frac)}*norm(min_image(center_of_mass({site})-center_of_mass({core})))"
        else:
            shift = _number(offset)
        original_origin = _rename_expression(origin_node.span_text(text), {variables["axis"]: axis0})
        origin = f"({original_origin})+({shift})*{axis0}"
        if spec.origin_lat1:
            origin += f"+{_number(spec.origin_lat1)}*{e1}"
        if spec.origin_lat2:
            origin += f"+{_number(spec.origin_lat2)}*{e2}"
        if spec.axis_tilt_deg:
            edits.append(patch.replace_node(axis_node, axis, "axis orientation"))
        edits.append(patch.replace_node(origin_node, origin, "origin placement"))
    if changed("funnel_enabled") and not spec.funnel_enabled:
        for name in md["radial_terms"] + md["axial_terms"]:
            edits.append(patch.replace_node(an.symbols[name].value, "0.0", "disable funnel wall"))
    edits.extend(_extra_edits(spec, an))
    return patch.apply(text, edits).text


def _rename_expression(text, names):
    """Rename identifier tokens, leaving comments and strings unchanged."""
    from .lang.lexer import tokenize, IDENT
    return patch.apply(text, [patch.Edit(t.start, t.end, names[t.text])
                              for t in tokenize(text).tokens
                              if t.kind == IDENT and t.text in names]).text


def _extra_edits(spec, an):
    """Insert designer additions without rebuilding the imported program."""
    from .terms import EmitCtx, emit_term
    md, text = spec.source_adapter, spec.source_text
    terms_changed = [t.to_dict() for t in spec.terms] != md["terms_baseline"]
    diagnostics_changed = [d.__dict__ for d in spec.diagnostics] != md["diagnostics_baseline"]
    prints_changed = [list(p) for p in spec.prints] != md["prints_baseline"]
    if not (terms_changed or diagnostics_changed or prints_changed):
        return []
    variables = md["variables"]
    total = variables["total"]
    anchor = an.symbols[total].bind if total else an.energy_stmt
    inserted, tail, edits = [], [], []
    if terms_changed:
        old_names = {"v_" + t["var"] for t in md["terms_baseline"]}
        # Energy names are normally v_<var>; honour an explicit implementation
        # property by constructing the original Term when reading older files.
        from .terms import Term
        old_terms = [Term.from_dict(t) for t in md["terms_baseline"]]
        old_names = {t.energy_var for t in old_terms}
        for sym in an.symbols.values():
            if any(sym.name == t.energy_var or sym.name.startswith(t.var + "_") for t in old_terms):
                edits.append(patch.replace_node(sym.bind, "", "replace designer shape"))
        for match in re.finditer(r"^[ \t]*#\s*@ff-term\s+(\{.*\})[^\S\n]*$", text, re.M):
            try:
                if json.loads(match.group(1)).get("var") in {t.var for t in old_terms}:
                    edits.append(patch.Edit(match.start(), match.end(), "", "replace shape marker"))
            except ValueError:
                pass
        active = [t for t in spec.terms if t.enabled]
        source_names = set(an.symbols)
        for term in active:
            if term.energy_var in source_names and term.energy_var not in old_names:
                raise ValueError(f"Shape name {term.var!r} conflicts with an imported source variable.")
        renamed = {name: variables[name] for name in ("axis", "origin", "z", "rho", "lig_com") if variables.get(name)}
        if any(t.needs_perp_frame for t in active):
            # Reserve collision-free helper names; they are recomputed from
            # the edited axis and retain the protein-attached orientation.
            prefix = "ff_source"
            while any(n.startswith(prefix + "_") for n in source_names):
                prefix += "_"
            axis0 = an.symbols[variables["axis"]].value.span_text(text)
            projection = _basis_expression(spec, axis0)
            inserted += [f"{prefix}_perp = {projection};",
                         f"{prefix}_p1 = {prefix}_perp/norm({prefix}_perp);",
                         f"{prefix}_e1r = {prefix}_p1-dot({prefix}_p1,{variables['axis']})*{variables['axis']};",
                         f"{prefix}_e1 = {prefix}_e1r/norm({prefix}_e1r);",
                         f"{prefix}_e2 = cross({variables['axis']},{prefix}_e1);"]
            renamed.update(e1=prefix + "_e1", e2=prefix + "_e2")
        ctx = EmitCtx(spec.funnel_enabled, variables["z"], variables["rho"], variables["lig_com"])
        for term in active:
            inserted.extend(_rename_expression("\n".join(emit_term(term, ctx)), renamed).splitlines())
        energy_node = an.symbols[total].value if total else an.energy_expr
        energy = energy_node.span_text(text)
        energy = _rename_expression(energy, {name: "0.0" for name in old_names})
        if active:
            energy = "(" + energy + ")+" + "+".join(t.energy_var for t in active)
        edits.append(patch.replace_node(energy_node, energy, "designer shape contributions"))
    if diagnostics_changed:
        old = md["diagnostics_baseline"]
        owned = {name for d in old for name in (d["var"], d["var"] + "_sel", d["dist_var"])}
        for name in owned:
            if name in an.symbols:
                edits.append(patch.replace_node(an.symbols[name].bind, "", "replace monitoring group"))
        for d in spec.diagnostics:
            for name in (d.var, d.var + "_sel", d.dist_var):
                if name in an.symbols and name not in owned:
                    raise ValueError(f"Monitoring variable {name!r} conflicts with imported source.")
            asl = "atom. " + ",".join(str(i) for i in d.indices)
            inserted += [f"{d.var}_sel = atomsel({json.dumps(asl)});",
                         f"{d.var} = center_of_mass({d.var}_sel);",
                         f"{d.dist_var} = norm(min_image({variables['lig_com']}-{d.var}));"]
        prints_changed = True
    if prints_changed:
        # Only simple symbol prints are controlled by this panel.  Arbitrary
        # expressions, vector outputs and untouched monitoring remain exact.
        controlled = {tuple(p) for p in md["prints_baseline"]}
        for node in an.parse.program.children:
            if node.kind != cst.EXPR_STMT or not node.children:
                continue
            call = _unwrap(node.children[0])
            if call.kind == cst.CALL and call.name == "print" and len(call.children) == 2:
                label, value = call.children
                if label.kind == cst.STR and value.kind == cst.NAME and (label.text.strip('"'), value.name) in controlled:
                    edits.append(patch.replace_node(node, "", "update printed quantities"))
        old_diag_vars = {d["dist_var"] for d in md["diagnostics_baseline"]}
        current_diag_vars = {d.dist_var for d in spec.diagnostics}
        current = [(label, name) for label, name in spec.prints
                   if name not in old_diag_vars or name in current_diag_vars]
        if diagnostics_changed:
            for d in spec.diagnostics:
                if not any(name == d.dist_var for _, name in current):
                    current.append((d.print_label, d.dist_var))
        tail = [f"print({json.dumps(label, ensure_ascii=False)},{name});" for label, name in current]
    if inserted:
        edits.append(patch.Edit(anchor.start, anchor.start, "\n".join(inserted) + "\n", "designer additions"))
    if tail:
        edits.append(patch.Edit(an.energy_stmt.start, an.energy_stmt.start, "\n".join(tail) + "\n", "printed quantities"))
    return edits


def _slice(text, targets, overrides=(), expression=None):
    an = _analysis(text)
    needed = _deps(an, targets, stop=overrides)
    nodes = [sym.bind for sym in an.symbols.values()
             if sym.name in needed and sym.scope == "program"]
    nodes += [node for node in an.parse.program.children
              if node.kind == cst.STATIC
              and any(child.name in needed for child in node.children)]
    statements = [node.span_text(text) for node in sorted(nodes, key=lambda node: node.start)]
    # Statements already carry their terminators in the CST.
    body = "\n".join(s if s.rstrip().endswith(";") else s + ";" for s in statements)
    return body + "\n" + (expression or (targets[-1] if targets else "0.0")) + ";\n"


def evaluate_source(spec, structure, probe=None):
    from .mexpr import evaluate_pot
    text = emit_source(spec)
    an = _analysis(text)
    energy = an.energy_expr.span_text(text)
    targets = [n.name for n in an.energy_expr.walk() if n.kind == cst.NAME]
    # Include geometric observables without evaluating unrelated print-only
    # diagnostics (which may require trajectory state or future functions).
    targets += [v for k, v in spec.source_adapter["variables"].items()
                if k in ("axis", "origin", "z", "rho", "r_allowed", "lig_com") and v]
    sliced = _slice(text, targets, expression=energy)
    return evaluate_pot(sliced, structure, probe=probe, probe_group=spec.lig.var)


def source_field(spec, structure, points):
    result = evaluate_source(spec, structure, probe=points)
    value = np.asarray(result.value.data, dtype=float)[..., 0]
    return np.broadcast_to(value, np.asarray(points).shape[:-1])


def source_cvs(spec, structure, points=None):
    """Evaluate the actual axial/radial CV expressions without force terms.

    In particular this retains custom radial regularisation and does not
    assume that every imported rho uses the designer's default epsilon.
    """
    from .mexpr import evaluate_pot
    variables = spec.source_adapter["variables"]
    text = emit_source(spec)
    result = evaluate_pot(_slice(text, [variables["z"], variables["rho"]]),
                          structure, probe=points, probe_group=spec.lig.var)
    return tuple(np.asarray(result.array(variables[key]), dtype=float)
                 for key in ("z", "rho"))


def source_frame(spec, structure):
    from .funnel import Frame
    from .mexpr import evaluate_pot
    md = spec.source_adapter
    variables = md["variables"]
    text = emit_source(spec)
    result = evaluate_pot(_slice(text, [variables["axis"], variables["origin"], variables["lig_com"]]), structure)
    axis, origin, lig_com = (np.asarray(result.array(variables[key]), dtype=float)
                             for key in ("axis", "origin", "lig_com"))
    axis = axis.reshape(3)
    axis_norm = float(np.linalg.norm(axis))
    if not np.isfinite(axis_norm) or axis_norm < 1e-10 or abs(axis_norm - 1.0) > 1e-5:
        raise ValueError("The custom funnel axis must be a finite unit vector.")
    core = structure.center_of_mass(spec.core.idx0())
    site = structure.center_of_mass(spec.site.idx0())
    raw = structure.min_image(site - core)
    length = float(np.linalg.norm(raw))
    if spec.frame_ref.indices:
        ref = structure.center_of_mass(spec.frame_ref.idx0())
        # The controls use the source's unmodified axis as their reference.
        base_spec = spec.copy()
        for attr in POSE:
            setattr(base_spec, attr, md["baseline"][attr])
        original = evaluate_pot(_slice(emit_source(base_spec), [variables["axis"]]), structure)
        axis0 = np.asarray(original.array(variables["axis"]), float)
        v = structure.min_image(ref - core)
        p1 = v - np.dot(v, axis0) * axis0
        norm = np.linalg.norm(p1)
        if norm < 1e-9:
            raise ValueError("The third frame group is collinear with the custom funnel axis.")
        p1 /= norm
        e1 = p1 - np.dot(p1, axis) * axis
        e1 /= np.linalg.norm(e1)
    else:
        tmp = np.zeros(3)
        tmp[np.argmin(np.abs(axis))] = 1.0
        e1 = np.cross(axis, tmp)
        e1 /= np.linalg.norm(e1)
    e2 = np.cross(axis, e1)
    return Frame(site, core, lig_com.reshape(3), raw, length, axis,
                 origin.reshape(3), e1, e2)


def _cv_values(spec, targets, z, rho=None):
    from .mexpr import Interpreter, V
    md = spec.source_adapter
    z = np.asarray(z, dtype=float)
    env = {md["variables"]["z"]: V.num(z[..., None])}
    if rho is not None:
        rho = np.asarray(rho, dtype=float)
        z, rho = np.broadcast_arrays(z, rho)
        env[md["variables"]["z"]] = V.num(z[..., None])
        env[md["variables"]["rho"]] = V.num(rho[..., None])
    text = emit_source(spec)
    result = Interpreter(None, env=env).run(_slice(text, targets, overrides=env,
                                      expression="+".join(targets) or "0.0"))
    value = np.asarray(result.value.data, dtype=float)[..., 0]
    return np.broadcast_to(value, z.shape)


def source_radius(spec, z):
    return _cv_values(spec, [spec.source_adapter["variables"]["r_allowed"]], z)


def source_radial(spec, z, rho):
    return _cv_values(spec, spec.source_adapter["radial_terms"], z, rho)


def source_axial(spec, z):
    return _cv_values(spec, spec.source_adapter["axial_terms"], z)


def source_wall(spec, z, rho):
    return source_radial(spec, z, rho) + source_axial(spec, z)
