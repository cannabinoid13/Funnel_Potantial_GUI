"""The funnel itself, drawn so the protein behind it stays visible.

Layers, each independently toggleable:

* the flat-bottom boundary (where the restraint switches on),
* iso-potential shells at chosen energies, blue at weak and red at strong,
* a cross-section plane through the axis carrying the same colour scale,
* an optional volume rendering of the wall energy,
* the axis with a Angstrom ruler, dimension annotations, COM markers,
* draggable handles for every geometric parameter.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import vtk
from vtk.util import numpy_support as nps

from . import theme
from .reps import (triangle_polydata, line_polydata, sphere_actor,
                   line_actor, caption_actor, _points)


@dataclass
class Handle:
    """A draggable point constrained to one line in space.

    ``base`` and ``direction`` define that line, so the same machinery serves
    the funnel walls, a shape's axial position and its two sideways offsets:
    the mouse ray is projected onto the line and the parameter is the value.
    """

    key: str
    kind: str                 # 'axial' | 'radial' | 'lateral'
    actor: vtk.vtkActor
    label: str = ""
    z_ref: float = 0.0
    phi: float = 0.0
    tip: str = ""
    base: object = None
    direction: object = None


@dataclass
class FunnelStyle:
    show_terms: bool = True
    show_term_shells: bool = True
    show_total_field: bool = False
    term_opacity: float = 0.15
    total_levels: tuple = (1.0, 5.0, 20.0)
    field_grid: int = 64
    show_boundary: bool = True
    show_shells: bool = True
    show_section: bool = False
    show_volume: bool = False
    show_caps: bool = True
    show_axis: bool = True
    show_ruler: bool = True
    show_labels: bool = True
    show_com: bool = True
    show_handles: bool = True
    handle_term_var: str = ""      # only this term shows its own handles
    wireframe_rings: bool = True
    scale_name: str = theme.DEFAULT_SCALE
    v_max: float = 20.0
    shell_mode: str = "distance"          # 'distance' or 'energy'
    shell_levels: tuple = (2.0, 6.0, 12.0, 20.0)
    shell_offsets: tuple = (0.75, 1.5, 2.25)
    boundary_opacity: float = 0.13
    boundary_by_stiffness: bool = False
    shell_opacity: float = 0.11
    section_opacity: float = 0.55
    section_pad: float = 6.0
    section_phi: float = 1.5707963267948966
    volume_opacity: float = 0.35
    n_theta: int = 96


class FunnelVisual:
    """Owns every funnel-related prop in the scene."""

    def __init__(self, renderer: vtk.vtkRenderer, overlay=None):
        self.ren = renderer
        #: handles live in a depth-cleared overlay layer so a translucent
        #: shape can never hide or block them
        self.overlay = overlay if overlay is not None else renderer
        self.style = FunnelStyle()
        self.actors: list[vtk.vtkProp] = []
        self.handles: list[Handle] = []
        #: how many props each layer contributed on the last rebuild, so the
        #: scene can be checked rather than eyeballed
        self.counts: dict = {"funnel": 0, "terms": 0, "field": 0, "frame": 0}
        self.volume: vtk.vtkVolume | None = None
        self._model = None

    # ------------------------------------------------------------------
    def clear(self) -> None:
        for a in self.actors:
            self.ren.RemoveViewProp(a)
        self.actors = []
        for h in self.handles:
            self.overlay.RemoveViewProp(h.actor)
        self.handles = []
        if self.volume is not None:
            self.ren.RemoveViewProp(self.volume)
            self.volume = None

    def _add(self, prop: vtk.vtkProp) -> vtk.vtkProp:
        # nothing except a handle is pickable, so a click can only ever mean
        # "grab a handle" or "rotate the camera"
        try:
            prop.PickableOff()
        except AttributeError:
            pass
        self.ren.AddViewProp(prop)
        self.actors.append(prop)
        return prop

    # ------------------------------------------------------------------
    def rebuild(self, model) -> None:
        self.clear()
        if model is None:
            return
        self._model = model
        sp, st_, fr = model.spec, self.style, model.frame
        # Nothing about the built-in funnel is drawn unless it is actually part
        # of the potential: an imported job without a .pot has no funnel, and
        # the view must show exactly that.
        funnel = bool(sp.funnel_enabled) and not model.funnel_is_degenerate()
        self.counts = {"funnel": 0, "terms": 0, "field": 0, "frame": 0}
        mark = len(self.actors)

        if funnel:
            if st_.show_boundary:
                self._boundary(model)
            if st_.show_caps:
                self._caps(model)
            if st_.show_shells:
                self._shells(model)
            if st_.show_section:
                self._section(model)
            if st_.show_volume:
                self._volume(model)
        self.counts["funnel"] = len(self.actors) - mark
        mark = len(self.actors)
        if st_.show_terms:
            self._terms(model)
        self.counts["terms"] = len(self.actors) - mark
        mark = len(self.actors)
        if st_.show_total_field:
            self._total_field(model)
        self.counts["field"] = len(self.actors) - mark
        mark = len(self.actors)
        if st_.show_axis:
            self._axis(model)
        if funnel and st_.show_ruler:
            self._ruler(model)
        if st_.show_com:
            self._markers(model)
        if funnel and st_.show_labels:
            self._annotations(model)
        self.counts["frame"] = len(self.actors) - mark
        if st_.show_handles:
            self._handles(model, funnel=funnel)

    # -- layers --------------------------------------------------------
    def _boundary(self, model) -> None:
        pts, faces, zline, rline = model.boundary_mesh(
            n_theta=self.style.n_theta, n_z=3)
        pd = triangle_polydata(pts, faces)
        # the boundary is the V = 0 contour, so it takes the cold end of the
        # scale unless the user asks to see stiffness as colour
        t = (float(np.clip(model.spec.k_rad / 100.0, 0.05, 1.0))
             if self.style.boundary_by_stiffness else 0.02)
        rgb = theme.scale_rgb(self.style.scale_name, t)
        normals = vtk.vtkPolyDataNormals()
        normals.SetInputData(pd)
        normals.SplittingOff()
        normals.ConsistencyOn()
        normals.Update()
        mp = vtk.vtkPolyDataMapper()
        mp.SetInputConnection(normals.GetOutputPort())
        ac = vtk.vtkActor()
        ac.SetMapper(mp)
        p = ac.GetProperty()
        p.SetColor(*[float(x) for x in rgb])
        p.SetOpacity(self.style.boundary_opacity)
        p.SetSpecular(0.4)
        p.SetSpecularPower(60)
        p.SetAmbient(0.45)
        p.SetDiffuse(0.6)
        p.BackfaceCullingOff()
        p.FrontfaceCullingOff()
        self._add(ac)

        if self.style.wireframe_rings:
            self._rings(model, zline)

    def _rings(self, model, zline) -> None:
        sp = model.spec
        zs = [sp.z_min, sp.z_cc, sp.z_max]
        zs += list(np.arange(np.ceil(sp.z_min / 5) * 5, sp.z_max, 5.0))
        zs = sorted({round(float(z), 4) for z in zs
                     if sp.z_min - 1e-6 <= z <= sp.z_max + 1e-6})
        n = 72
        theta = np.linspace(0, 2 * np.pi, n, endpoint=True)
        chunks, segs, allpts = [], [], []
        off = 0
        for z in zs:
            r = float(sp.r_allowed(z))
            ring = model.frame.cyl_to_world(np.full(n, z), np.full(n, r), theta)
            allpts.append(ring)
            segs.append(np.column_stack([np.arange(off, off + n - 1),
                                         np.arange(off + 1, off + n)]))
            off += n
        if not allpts:
            return
        pd = line_polydata(np.vstack(allpts), np.vstack(segs))
        mp = vtk.vtkPolyDataMapper()
        mp.SetInputData(pd)
        ac = vtk.vtkActor()
        ac.SetMapper(mp)
        p = ac.GetProperty()
        rgb = theme.scale_rgb(self.style.scale_name, 0.08)
        p.SetColor(*[float(x) for x in rgb])
        p.SetLineWidth(1.3)
        p.SetOpacity(0.55)
        p.LightingOff()
        self._add(ac)
        # meridians
        mer = []
        segm = []
        off = 0
        for phi in np.linspace(0, 2 * np.pi, 12, endpoint=False):
            zl = np.linspace(sp.z_min, sp.z_max, 40)
            rl = sp.r_allowed(zl)
            line = model.frame.cyl_to_world(zl, rl, np.full(40, phi))
            mer.append(line)
            segm.append(np.column_stack([np.arange(off, off + 39),
                                         np.arange(off + 1, off + 40)]))
            off += 40
        pd2 = line_polydata(np.vstack(mer), np.vstack(segm))
        mp2 = vtk.vtkPolyDataMapper()
        mp2.SetInputData(pd2)
        ac2 = vtk.vtkActor()
        ac2.SetMapper(mp2)
        p2 = ac2.GetProperty()
        p2.SetColor(*[float(x) for x in rgb])
        p2.SetLineWidth(1.0)
        p2.SetOpacity(0.35)
        p2.LightingOff()
        self._add(ac2)

    def _caps(self, model) -> None:
        sp = model.spec
        for which, v in (("low", 0.0), ("high", 0.0)):
            pts, faces = model.cap_mesh(which, n_theta=self.style.n_theta)
            pd = triangle_polydata(pts, faces)
            mp = vtk.vtkPolyDataMapper()
            mp.SetInputData(pd)
            ac = vtk.vtkActor()
            ac.SetMapper(mp)
            k = sp.k_z / 100.0
            rgb = theme.scale_rgb(self.style.scale_name,
                                  float(np.clip(k, 0.05, 1.0))
                                  if self.style.boundary_by_stiffness else 0.06)
            p = ac.GetProperty()
            p.SetColor(*[float(x) for x in rgb])
            p.SetOpacity(min(0.4, self.style.boundary_opacity * 1.3))
            p.SetAmbient(0.5)
            p.SetDiffuse(0.5)
            p.LightingOn()
            self._add(ac)

    def shell_pairs(self, sp) -> list[tuple[float, float, float]]:
        """(radial offset, axial offset, energy) for each iso-surface.

        In 'distance' mode the shells sit at fixed distances outside the wall,
        so their colour reads directly as "how hard the wall pushes 1 A out" -
        a stiff wall turns red immediately, a soft one stays blue.
        """
        out = []
        if self.style.shell_mode == "energy":
            for v in sorted(self.style.shell_levels):
                if v <= 0:
                    continue
                dr = sp.radial_offset_for(v)
                dz = sp.axial_offset_for(v)
                if np.isfinite(dr):
                    out.append((dr, dz, float(v)))
        else:
            for dr in sorted(self.style.shell_offsets):
                if dr <= 0:
                    continue
                v = 0.5 * sp.k_rad * dr * dr
                dz = sp.axial_offset_for(v)
                out.append((float(dr), float(dz), float(v)))
        return out

    def _shells(self, model) -> None:
        """One translucent surface per iso-energy of the wall potential."""
        if model.spec.source_adapter:
            return self._source_shells(model)
        sp = model.spec
        pairs = self.shell_pairs(sp)
        if not pairs:
            return
        vmax = max(self.style.v_max, 1e-6)
        n = len(pairs)
        for k, (dr, dz, v) in enumerate(pairs):
            fade = 1.0 - 0.55 * (k / max(1, n - 1))
            pts, faces, _, _ = model.boundary_mesh(
                n_theta=max(32, self.style.n_theta // 2), n_z=3,
                radial_offset=dr)
            pd = triangle_polydata(pts, faces)
            t = float(np.clip(v / vmax, 0.0, 1.0))
            rgb = theme.scale_rgb(self.style.scale_name, t)
            mp = vtk.vtkPolyDataMapper()
            mp.SetInputData(pd)
            ac = vtk.vtkActor()
            ac.SetMapper(mp)
            p = ac.GetProperty()
            p.SetColor(*[float(x) for x in rgb])
            p.SetOpacity(self.style.shell_opacity * fade)
            p.SetAmbient(0.55)
            p.SetDiffuse(0.45)
            p.SetSpecular(0.12)
            self._add(ac)
            for which in ("low", "high"):
                cpts, cfaces = model.cap_mesh(
                    which, n_theta=max(32, self.style.n_theta // 2),
                    radial_offset=dr, axial_offset=dz)
                cpd = triangle_polydata(cpts, cfaces)
                cmp_ = vtk.vtkPolyDataMapper()
                cmp_.SetInputData(cpd)
                cac = vtk.vtkActor()
                cac.SetMapper(cmp_)
                cp = cac.GetProperty()
                cp.SetColor(*[float(x) for x in rgb])
                cp.SetOpacity(self.style.shell_opacity * fade * 0.85)
                cp.SetAmbient(0.55)
                cp.SetDiffuse(0.45)
                self._add(cac)

    def _source_shells(self, model) -> None:
        """Use the imported field instead of assuming harmonic walls."""
        vmax = max(self.style.v_max, 1e-6)
        if self.style.shell_mode == "energy":
            n = int(np.clip(self.style.field_grid, 24, 128))
            xs, ys, zs, values = model.sample_field_grid(n_axial=n, n_radial=n)
            levels = sorted(v for v in self.style.shell_levels if v > 0)
            for k, level in enumerate(levels):
                fade = 1.0 - 0.55 * k / max(1, len(levels) - 1)
                color = theme.scale_rgb(self.style.scale_name,
                                        float(np.clip(level / vmax, 0, 1)))
                actor = _iso_actor(xs, ys, zs, values, level, color,
                                   self.style.shell_opacity * fade,
                                   model.local_to_world_matrix())
                if actor is not None:
                    self._add(actor)
            return
        offsets = sorted(v for v in self.style.shell_offsets if v > 0)
        for k, offset in enumerate(offsets):
            fade = 1.0 - 0.55 * k / max(1, len(offsets) - 1)
            pts, faces, _, _ = model.boundary_mesh(
                n_theta=max(32, self.style.n_theta // 2), radial_offset=offset)
            surfaces = [(pts, faces, 1.0)]
            for which in ("low", "high"):
                pts, faces = model.cap_mesh(
                    which, n_theta=max(32, self.style.n_theta // 2),
                    radial_offset=offset, axial_offset=offset)
                surfaces.append((pts, faces, 0.85))
            for pts, faces, opacity in surfaces:
                values = np.asarray(model.total_field(points=pts))
                colors = theme.scale_rgb(self.style.scale_name,
                                          np.clip(values / vmax, 0, 1))
                poly = triangle_polydata(pts, faces)
                scalars = nps.numpy_to_vtk(
                    np.ascontiguousarray(colors * 255, dtype=np.uint8),
                    deep=True, array_type=vtk.VTK_UNSIGNED_CHAR)
                scalars.SetName("source_energy")
                poly.GetPointData().SetScalars(scalars)
                mapper = vtk.vtkPolyDataMapper()
                mapper.SetInputData(poly)
                mapper.SetColorModeToDirectScalars()
                actor = vtk.vtkActor()
                actor.SetMapper(mapper)
                prop = actor.GetProperty()
                prop.SetOpacity(self.style.shell_opacity * fade * opacity)
                prop.SetAmbient(0.55)
                prop.SetDiffuse(0.45)
                prop.SetSpecular(0.12)
                self._add(actor)

    # -- extra shape terms ---------------------------------------------
    def _terms(self, model) -> None:
        for t in model.spec.active_terms:
            try:
                if t.kind == "lathe":
                    self._term_lathe(model, t)
                elif t.kind == "sphere":
                    self._term_sphere(model, t)
                elif t.kind == "slab":
                    self._term_slab(model, t)
                else:
                    self._term_isosurface(model, t)
            except Exception:
                continue

    def _surface_actor(self, pts, faces, color, opacity: float,
                       lighting: bool = True) -> vtk.vtkActor:
        pd = triangle_polydata(pts, faces)
        nrm = vtk.vtkPolyDataNormals()
        nrm.SetInputData(pd)
        nrm.SplittingOff()
        nrm.ConsistencyOn()
        nrm.Update()
        mp = vtk.vtkPolyDataMapper()
        mp.SetInputConnection(nrm.GetOutputPort())
        ac = vtk.vtkActor()
        ac.SetMapper(mp)
        p = ac.GetProperty()
        p.SetColor(*[float(c) for c in color])
        p.SetOpacity(float(opacity))
        p.SetAmbient(0.5)
        p.SetDiffuse(0.55)
        p.SetSpecular(0.25)
        p.SetSpecularPower(50)
        if not lighting:
            p.LightingOff()
        return self._add(ac)

    def _term_lathe(self, model, t) -> None:
        n = 90
        o, u, v1, v2 = model.term_frame(t)
        zs = np.linspace(t.z_lo, t.z_hi, n)
        r = model.term_profile(t, zs)
        if r is None:
            return
        r = np.where(np.isfinite(r), r, 0.0)
        if t.clamp_radius and t.radius_cap > 0:
            r = np.minimum(r, t.radius_cap)
        pts, faces = model.revolve_about(o, u, v1, v2, zs, r,
                                         n_theta=self.style.n_theta)
        self._surface_actor(pts, faces, t.color, self.style.term_opacity)
        # profile rings so the shape reads without relying on shading
        rings = np.linspace(t.z_lo, t.z_hi, 12)
        rr = model.term_profile(t, rings)
        segs, allpts, off = [], [], 0
        nt = 64
        theta = np.linspace(0, 2 * np.pi, nt, endpoint=True)
        for z, radius in zip(rings, np.where(np.isfinite(rr), rr, 0.0)):
            radius = max(float(radius), 1e-6)
            ring = (o + z * u + (radius * np.cos(theta))[:, None] * v1
                    + (radius * np.sin(theta))[:, None] * v2)
            allpts.append(ring)
            segs.append(np.column_stack([np.arange(off, off + nt - 1),
                                         np.arange(off + 1, off + nt)]))
            off += nt
        if allpts:
            pd = line_polydata(np.vstack(allpts), np.vstack(segs))
            mp = vtk.vtkPolyDataMapper()
            mp.SetInputData(pd)
            ac = vtk.vtkActor()
            ac.SetMapper(mp)
            pr = ac.GetProperty()
            pr.SetColor(*[float(c) for c in t.color])
            pr.SetLineWidth(1.2)
            pr.SetOpacity(0.6)
            pr.LightingOff()
            self._add(ac)
        # caps that actually close the volume
        if t.cap in ("solvent", "both"):
            rz = model.term_profile(t, np.array([t.z_hi]))
            self._cap_disc(model, t, t.z_hi, float(np.nan_to_num(rz[0])))
        if t.cap in ("pocket", "both"):
            rz = model.term_profile(t, np.array([t.z_lo]))
            self._cap_disc(model, t, t.z_lo, float(np.nan_to_num(rz[0])))
        self._region_rings(model, t)
        if self.style.show_term_shells:
            for dr, _dz, v in self._term_shells(t):
                rr2 = np.where(np.isfinite(r), r, 0.0) + dr
                pts2, faces2 = model.revolve_about(
                    o, u, v1, v2, zs, rr2,
                    n_theta=max(32, self.style.n_theta // 2))
                col = theme.scale_rgb(self.style.scale_name,
                                      float(np.clip(v / max(self.style.v_max,
                                                            1e-9), 0, 1)))
                self._surface_actor(pts2, faces2, col,
                                    self.style.shell_opacity * 0.8)

    def _cap_disc(self, model, t, z: float, radius: float) -> None:
        if radius <= 0:
            return
        o, u, v1, v2 = model.term_frame(t)
        pts, faces = model.disc_about(o, u, v1, v2, z, radius,
                                      n_theta=self.style.n_theta)
        self._surface_actor(pts, faces, t.color,
                            min(0.45, self.style.term_opacity * 2.2))

    def _term_shells(self, t):
        """(radial offset, axial offset, energy) shells for one term.

        A term may carry its own levels, which matters when terms differ
        wildly in stiffness: one global energy list cannot show both a
        k = 2 and a k = 120 wall usefully.
        """
        mode = t.level_mode if t.own_levels else self.style.shell_mode
        if t.own_levels:
            values = list(t.levels)
        else:
            values = list(self.style.shell_levels
                          if mode == "energy" else self.style.shell_offsets)
        out = []
        for x in sorted(v for v in values if v > 0):
            if mode == "energy":
                out.append((t.radial_offset_for(x), 0.0, float(x)))
            else:
                out.append((float(x), 0.0, t.energy_at_distance(x)))
        return out

    def _term_sphere(self, model, t) -> None:
        centre = model.term_center(t)
        self._add(sphere_actor(centre, t.radius, t.color,
                               opacity=self.style.term_opacity, res=48))
        if self.style.show_term_shells:
            for dr, _dz, v in self._term_shells(t):
                col = theme.scale_rgb(self.style.scale_name,
                                      float(np.clip(v / max(self.style.v_max,
                                                            1e-9), 0, 1)))
                r = t.radius + dr if t.mode == "confine" else t.radius - dr
                if r > 0:
                    self._add(sphere_actor(centre, r, col,
                                           opacity=self.style.shell_opacity
                                           * 0.8, res=40))
        self._region_rings(model, t)
        if self.style.show_labels:
            self._add(caption_actor(f"{t.label} R={t.radius:.2f} A",
                                    centre + np.array([0, 0, t.radius + 1.0]),
                                    t.color, 11))

    def _term_slab(self, model, t) -> None:
        _z0, _z1, r_out = model.field_bounds(pad=2.0)
        o, u, v1, v2 = model.term_frame(t)
        for z in (t.z_lo, t.z_hi):
            pts, faces = model.disc_about(o, u, v1, v2, z, r_out, n_theta=64)
            self._surface_actor(pts, faces, t.color,
                                self.style.term_opacity, lighting=False)
        if self.style.show_labels:
            pos = o + t.z_hi * u + (r_out * 0.7) * v2
            self._add(caption_actor(t.label, pos, t.color, 11))

    def _term_isosurface(self, model, t) -> None:
        """Marching cubes on the term's own field: works for any expression."""
        n = int(np.clip(self.style.field_grid, 24, 128))
        # the bare shape, without the region switch, so an absolute level
        # shows the geometry instead of slivers at the taper edges
        xs, ys, zs, V = model.sample_field_grid(n_axial=n, n_radial=n,
                                                term=t, apply_region=False)
        levels = [0.5]
        if self.style.show_term_shells:
            levels += [v for _dr, _dz, v in self._term_shells(t) if v > 0.5]
        mat = model.local_to_world_matrix()
        for k, lev in enumerate(sorted(set(levels))):
            col = (t.color if k == 0 else theme.scale_rgb(
                self.style.scale_name,
                float(np.clip(lev / max(self.style.v_max, 1e-9), 0, 1))))
            op = (self.style.term_opacity if k == 0
                  else self.style.shell_opacity * 0.8)
            ac = _iso_actor(xs, ys, zs, V, lev, col, op, mat)
            if ac is not None:
                self._add(ac)
        self._region_rings(model, t)
        if self.style.show_labels:
            pos = model.frame.cyl_to_world(
                np.array([0.5 * (zs[0] + zs[-1])]),
                np.array([float(xs[-1]) * 0.8]), np.array([0.5 * np.pi]))[0]
            self._add(caption_actor(t.label, pos, t.color, 11))

    def _region_rings(self, model, t) -> None:
        """Dashed circles marking where a switched term starts and stops."""
        if not t.region.enabled:
            return
        _z0, _z1, r_out = model.field_bounds(pad=1.0)
        nt = 72
        theta = np.linspace(0, 2 * np.pi, nt, endpoint=True)
        allpts, segs, off = [], [], 0
        for z in (t.region.z_lo, t.region.z_hi):
            ring = model.frame.cyl_to_world(np.full(nt, z),
                                            np.full(nt, r_out * 0.55), theta)
            allpts.append(ring)
            segs.append(np.column_stack([np.arange(off, off + nt - 1),
                                         np.arange(off + 1, off + nt)]))
            off += nt
        pd = line_polydata(np.vstack(allpts), np.vstack(segs))
        mp = vtk.vtkPolyDataMapper()
        mp.SetInputData(pd)
        ac = vtk.vtkActor()
        ac.SetMapper(mp)
        p = ac.GetProperty()
        p.SetColor(*[float(c) for c in t.color])
        p.SetLineWidth(1.4)
        p.SetOpacity(0.55)
        p.SetLineStipplePattern(0xF0F0)
        p.LightingOff()
        self._add(ac)

    def _total_field(self, model) -> None:
        """Iso-surfaces of everything added together."""
        n = int(np.clip(self.style.field_grid, 24, 128))
        xs, ys, zs, V = model.sample_field_grid(n_axial=n, n_radial=n)
        mat = model.local_to_world_matrix()
        levels = sorted({float(v) for v in self.style.total_levels if v > 0})
        for lev in levels:
            col = theme.scale_rgb(self.style.scale_name,
                                  float(np.clip(lev / max(self.style.v_max,
                                                          1e-9), 0, 1)))
            ac = _iso_actor(xs, ys, zs, V, lev, col,
                            self.style.shell_opacity * 1.1, mat)
            if ac is not None:
                self._add(ac)

    def _section(self, model) -> None:
        """A plane through the axis, textured with the wall potential.

        The colour fades back out above the scale maximum, so the plane reads
        as a band hugging the wall instead of a solid sheet that would hide
        the protein behind it.
        """
        sp = model.spec
        fr = model.frame
        pad_r = self.style.section_pad
        pad_z = self.style.section_pad
        nz, nr = 240, 200
        zs = np.linspace(sp.z_min - pad_z, sp.z_max + pad_z, nz)
        rs = np.linspace(-(sp.r_base() + pad_r), sp.r_base() + pad_r, nr)
        ZZ, RR = np.meshgrid(zs, rs, indexing="ij")
        phi0 = float(self.style.section_phi)
        pts = fr.cyl_to_world(ZZ.ravel(), np.abs(RR).ravel(),
                              np.where(RR.ravel() >= 0, phi0, phi0 + np.pi))
        if sp.source_adapter:
            V = np.asarray(model.total_field(points=pts)).reshape(ZZ.shape)
        else:
            V = sp.wall_potential(ZZ, np.abs(RR))
        vmax = max(1e-9, self.style.v_max)
        u = V.ravel() / vmax
        t = np.clip(u, 0.0, 1.0)
        rgb = theme.scale_rgb(self.style.scale_name, t)
        alpha = np.where(u <= 1.0, t ** 0.55,
                         np.exp(-(u - 1.0) * 1.6)) * self.style.section_opacity
        rgba = np.clip(np.column_stack([rgb, alpha]) * 255, 0, 255).astype(np.uint8)
        pd = vtk.vtkPolyData()
        pd.SetPoints(_points(pts))
        quads = vtk.vtkCellArray()
        i, j = np.meshgrid(np.arange(nz - 1), np.arange(nr - 1), indexing="ij")
        a = (i * nr + j).ravel()
        b = a + nr
        c = b + 1
        d = a + 1
        m = len(a)
        ids = np.empty(5 * m, dtype=np.int64)
        ids[0::5] = 4
        ids[1::5] = a
        ids[2::5] = b
        ids[3::5] = c
        ids[4::5] = d
        quads.SetCells(m, nps.numpy_to_vtkIdTypeArray(ids, deep=True))
        pd.SetPolys(quads)
        arr = nps.numpy_to_vtk(np.ascontiguousarray(rgba), deep=True,
                               array_type=vtk.VTK_UNSIGNED_CHAR)
        arr.SetName("rgba")
        pd.GetPointData().SetScalars(arr)
        mp = vtk.vtkPolyDataMapper()
        mp.SetInputData(pd)
        mp.SetColorModeToDirectScalars()
        ac = vtk.vtkActor()
        ac.SetMapper(mp)
        ac.GetProperty().LightingOff()
        self._add(ac)

    def _volume(self, model) -> None:
        """A glow shell around the wall: transparent inside, fading outside."""
        sp = model.spec
        fr = model.frame
        vmax = max(1e-6, self.style.v_max)
        # sample only out to where the energy has clearly passed the scale top
        xs, ys, zs, V = model.sample_volume(n_axial=128, n_radial=80,
                                            v_max=1.6 * vmax, margin=1.0)
        img = vtk.vtkImageData()
        img.SetDimensions(len(xs), len(ys), len(zs))
        img.SetOrigin(float(xs[0]), float(ys[0]), float(zs[0]))
        img.SetSpacing(float(xs[1] - xs[0]), float(ys[1] - ys[0]),
                       float(zs[1] - zs[0]))
        arr = nps.numpy_to_vtk(np.ascontiguousarray(
            V.transpose(2, 1, 0).ravel(), dtype=np.float32), deep=True)
        arr.SetName("V")
        img.GetPointData().SetScalars(arr)

        color = vtk.vtkColorTransferFunction()
        for t in np.linspace(0, 1, 12):
            rgb = theme.scale_rgb(self.style.scale_name, t)
            color.AddRGBPoint(t * vmax, float(rgb[0]), float(rgb[1]),
                              float(rgb[2]))
        color.AddRGBPoint(2.0 * vmax, *[float(x) for x in
                                        theme.scale_rgb(self.style.scale_name,
                                                        1.0)])
        peak = self.style.volume_opacity
        opacity = vtk.vtkPiecewiseFunction()
        opacity.AddPoint(0.0, 0.0)
        opacity.AddPoint(0.04 * vmax, 0.05 * peak)
        opacity.AddPoint(0.35 * vmax, 0.55 * peak)
        opacity.AddPoint(0.80 * vmax, peak)
        opacity.AddPoint(1.20 * vmax, 0.35 * peak)
        opacity.AddPoint(1.60 * vmax, 0.0)
        opacity.AddPoint(4.00 * vmax, 0.0)
        prop = vtk.vtkVolumeProperty()
        prop.SetColor(color)
        prop.SetScalarOpacity(opacity)
        prop.SetScalarOpacityUnitDistance(2.5)
        prop.SetInterpolationTypeToLinear()
        prop.ShadeOff()
        mapper = vtk.vtkSmartVolumeMapper()
        mapper.SetInputData(img)
        mapper.SetBlendModeToComposite()
        vol = vtk.vtkVolume()
        vol.SetMapper(mapper)
        vol.SetProperty(prop)
        mat = vtk.vtkMatrix4x4()
        basis = np.column_stack([fr.e1, fr.e2, fr.axis])
        for r in range(3):
            for c in range(3):
                mat.SetElement(r, c, float(basis[r, c]))
            mat.SetElement(r, 3, float(fr.origin[r]))
        vol.SetUserMatrix(mat)
        self.ren.AddViewProp(vol)
        self.volume = vol

    def _axis(self, model) -> None:
        sp = model.spec
        if sp.funnel_enabled and not model.funnel_is_degenerate():
            a, b = model.axis_polyline(pad_low=2.0, pad_high=2.0)
        else:
            lo, hi, _r = model.field_bounds(pad=2.0)
            fr = model.frame
            a = fr.origin + lo * fr.axis
            b = fr.origin + hi * fr.axis
        ac = line_actor(a, b, (0.55, 0.62, 0.78), width=1.6, opacity=0.8)
        self._add(ac)

    def _ruler(self, model) -> None:
        sp = model.spec
        fr = model.frame
        step = 5.0 if (sp.z_max - sp.z_min) <= 60 else 10.0
        z0 = np.ceil(sp.z_min / step) * step
        zs = np.arange(z0, sp.z_max + 1e-6, step)
        if len(zs) == 0:
            return
        pts, segs = [], []
        off = 0
        tick = 1.1
        for z in zs:
            c = fr.cyl_to_world(np.array([z]), np.array([0.0]),
                                np.array([0.0]))[0]
            pts.append(c + tick * fr.e1)
            pts.append(c - tick * fr.e1)
            segs.append([off, off + 1])
            off += 2
        pd = line_polydata(np.array(pts), np.array(segs))
        mp = vtk.vtkPolyDataMapper()
        mp.SetInputData(pd)
        ac = vtk.vtkActor()
        ac.SetMapper(mp)
        p = ac.GetProperty()
        p.SetColor(0.6, 0.66, 0.8)
        p.SetLineWidth(1.4)
        p.LightingOff()
        self._add(ac)
        if self.style.show_labels:
            for z in zs:
                c = fr.cyl_to_world(np.array([z]), np.array([1.6]),
                                    np.array([np.pi]))[0]
                self._add(caption_actor(f"{z:g}", c, (0.62, 0.68, 0.82), 10))

    def _markers(self, model) -> None:
        fr = model.frame
        specs = [
            (fr.lig_com, 0.55, (1.0, 0.56, 0.25), "lig COM"),
            (fr.site_com, 0.5, (0.35, 0.85, 0.95), "SITE"),
            (fr.core_com, 0.5, (0.55, 0.95, 0.60), "CORE"),
            (fr.origin, 0.45, (1.0, 0.85, 0.35), "origin"),
        ]
        for pos, r, col, name in specs:
            self._add(sphere_actor(pos, r, col, opacity=0.95))
            if self.style.show_labels:
                self._add(caption_actor(name, np.asarray(pos) + np.array([0, 0, r + 0.6]),
                                        col, 11, bold=True))
        self._add(line_actor(fr.core_com, fr.site_com, (0.5, 0.85, 0.7),
                             width=1.6, dashed=True, opacity=0.7))

    def _annotations(self, model) -> None:
        sp = model.spec
        fr = model.frame
        z_mid = 0.5 * (sp.z_cc + sp.z_max)
        H, Q = 0.5 * np.pi, 1.5 * np.pi
        items = [
            (z_mid, sp.r_cyl + 1.6, H, f"r_cyl {sp.r_cyl:.2f} A"),
            (sp.z_min + 1.0, sp.r_base() + 1.6, Q,
             f"R_base {sp.r_base():.2f} A   cone {sp.cone_angle_deg:.2f} deg"),
            (sp.z_cc, sp.r_cyl + 1.6, H, f"z_cc {sp.z_cc:.2f} A"),
            (sp.z_min, sp.r_base() + 1.6, H, f"z_min {sp.z_min:.2f} A"),
            (sp.z_max, sp.r_cyl + 1.6, Q, f"z_max {sp.z_max:.2f} A"),
        ]
        for z, r, phi, text in items:
            pos = fr.cyl_to_world(np.array([z]), np.array([r]),
                                  np.array([phi]))[0]
            self._add(caption_actor(text, pos, (0.82, 0.88, 1.0), 11))
        # radial dimension arrow at the cylinder
        p0 = fr.cyl_to_world(np.array([z_mid]), np.array([0.0]),
                             np.array([0.0]))[0]
        p1 = fr.cyl_to_world(np.array([z_mid]), np.array([sp.r_cyl]),
                             np.array([0.5 * np.pi]))[0]
        self._add(line_actor(p0, p1, (0.9, 0.93, 1.0), width=1.4, dashed=True,
                             opacity=0.8))

    # -- handles -------------------------------------------------------
    def handle_scale(self) -> float:
        """World size of a handle, kept at roughly a constant pixel size."""
        cam = self.ren.GetActiveCamera()
        size = self.ren.GetSize()
        height = float(size[1]) if size and size[1] else 600.0
        try:
            if cam.GetParallelProjection():
                world_per_px = 2.0 * cam.GetParallelScale() / height
            else:
                d = float(np.linalg.norm(
                    np.asarray(cam.GetPosition())
                    - np.asarray(cam.GetFocalPoint())))
                world_per_px = (2.0 * d
                                * np.tan(np.radians(cam.GetViewAngle()) / 2.0)
                                / height)
        except Exception:
            return 0.62
        return float(np.clip(world_per_px * 9.0, 0.35, 3.0))

    def _handles(self, model, funnel: bool = True) -> None:
        sp = model.spec
        fr = model.frame
        r_h = self.handle_scale()

        def add(key, kind, pos, base, direction, color, label, tip,
                radius=None):
            ac = sphere_actor(pos, radius or r_h, color, opacity=1.0, res=20)
            ac.PickableOn()
            ac.GetProperty().SetAmbient(0.45)
            ac.GetProperty().SetDiffuse(0.7)
            self.overlay.AddViewProp(ac)
            self.handles.append(Handle(key=key, kind=kind, actor=ac,
                                       label=label, tip=tip,
                                       base=np.asarray(base, dtype=float),
                                       direction=np.asarray(direction,
                                                            dtype=float)))

        def cyl(z, rho, phi):
            return fr.cyl_to_world(np.array([z]), np.array([rho]),
                                   np.array([phi]))[0]

        add("origin", "axial", fr.origin, fr.origin, fr.axis,
            (1.0, 0.88, 0.40), "origin",
            "Drag along the axis to slide the funnel frame")
        if sp.has_frame_ref:
            add("origin_lat1", "lateral", fr.origin + 1.6 * fr.e1,
                fr.origin, fr.e1, (1.0, 0.80, 0.55), "origin e1",
                "Drag sideways to move the frame across the axis (e1)")
            add("origin_lat2", "lateral", fr.origin + 1.6 * fr.e2,
                fr.origin, fr.e2, (1.0, 0.72, 0.70), "origin e2",
                "Drag sideways to move the frame across the axis (e2)")

        if funnel:
            add("z_min", "axial", cyl(sp.z_min, 0.0, 0.0), fr.origin, fr.axis,
                (0.45, 0.75, 1.0), "z_min",
                "Drag along the axis to move the lower wall")
            add("z_max", "axial", cyl(sp.z_max, 0.0, 0.0), fr.origin, fr.axis,
                (1.0, 0.45, 0.45), "z_max",
                "Drag along the axis to move the bulk-side wall")
            add("z_cc", "axial", cyl(sp.z_cc, sp.r_cyl, 0.0), fr.origin,
                fr.axis, (1.0, 0.82, 0.30), "z_cc",
                "Drag along the axis to move the cone/cylinder junction")
            z_mid = 0.5 * (sp.z_cc + sp.z_max)
            e_r = np.cos(0.5 * np.pi) * fr.e1 + np.sin(0.5 * np.pi) * fr.e2
            add("r_cyl", "radial", cyl(z_mid, sp.r_cyl, 0.5 * np.pi),
                fr.origin + z_mid * fr.axis, e_r, (0.55, 0.95, 0.65),
                "r_cyl", "Drag outward to widen the bulk cylinder")
            e_r2 = np.cos(np.pi) * fr.e1 + np.sin(np.pi) * fr.e2
            add("cone", "radial", cyl(sp.z_min, sp.r_base(), np.pi),
                fr.origin + sp.z_min * fr.axis, e_r2, (0.85, 0.60, 1.00),
                "cone", "Drag to open or close the cone angle")
            if sp.has_frame_ref:
                for z_end, suffix in ((sp.z_max, ""), (sp.z_min, "_lo")):
                    if abs(z_end) < 1e-6:
                        continue
                    end = fr.origin + z_end * fr.axis
                    r_here = max(1.8 * self.handle_scale(),
                                 float(sp.r_allowed(z_end)) * 0.8)
                    for k, vv in ((1, fr.e1), (2, fr.e2)):
                        add(f"axis_tilt{k}{suffix}", "lateral",
                            end + r_here * vv, end, vv, (0.95, 0.75, 0.95),
                            f"funnel swing {k}",
                            "Drag to swing the funnel axis away from the "
                            "CORE→SITE direction",
                            radius=0.75 * self.handle_scale())

        # -- handles for the selected shape term
        want = self.style.handle_term_var
        for t in sp.active_terms:
            if want and t.var != want:
                continue
            if not want:
                continue
            self._term_handles(model, t, add)

    def _term_handles(self, model, t, add) -> None:
        """Axial position, two sideways offsets and one size handle."""
        fr = model.frame
        sp = model.spec
        base_origin = (fr.origin + t.offset_e1 * fr.e1
                       + t.offset_e2 * fr.e2)
        col = tuple(t.color)
        zc = t.axial_position()
        centre = base_origin + zc * fr.axis
        add(f"t:{t.var}:axial", "axial", centre, base_origin, fr.axis, col,
            f"{t.label} position",
            "Drag along the axis to move this shape, keeping its size")
        if sp.has_frame_ref:
            add(f"t:{t.var}:e1", "lateral", centre + 1.8 * fr.e1, centre,
                fr.e1, col, f"{t.label} e1",
                "Drag sideways to place the shape off the axis (e1)")
            add(f"t:{t.var}:e2", "lateral", centre + 1.8 * fr.e2, centre,
                fr.e2, col, f"{t.label} e2",
                "Drag sideways to place the shape off the axis (e2)")
        # swing handles: grab either end and turn the shape about its origin
        if sp.has_frame_ref:
            o, u, v1, v2 = model.term_frame(t)
            ends = ((t.center_z, "") if t.kind == "sphere"
                    else (t.z_hi, ""), )
            pairs = ([(t.center_z, "")] if t.kind == "sphere"
                     else [(t.z_hi, ""), (t.z_lo, "_lo")])
            for z_end, suffix in pairs:
                if abs(z_end) < 1e-6:
                    continue
                end = o + z_end * u
                r_here = 1.6 * self.handle_scale()
                if t.kind == "lathe":
                    rr = model.term_profile(t, np.array([z_end]))
                    if rr is not None and np.isfinite(rr[0]):
                        r_here = max(r_here, float(rr[0]) * 0.75)
                elif t.kind == "sphere":
                    r_here = max(r_here, t.radius * 0.75)
                for k, vv in ((1, v1), (2, v2)):
                    add(f"t:{t.var}:tilt{k}{suffix}", "lateral",
                        end + r_here * vv, end, vv, col,
                        f"{t.label} swing {k}",
                        "Drag to swing this end: the shape turns about its "
                        "own origin, in the body-fixed frame",
                        radius=0.75 * self.handle_scale())
        if t.kind in ("lathe", "slab"):
            small = 0.8 * self.handle_scale()
            add(f"t:{t.var}:z_lo", "axial",
                base_origin + t.z_lo * fr.axis, base_origin, fr.axis, col,
                f"{t.label} z_lo", "Drag to move this end of the shape",
                radius=small)
            add(f"t:{t.var}:z_hi", "axial",
                base_origin + t.z_hi * fr.axis, base_origin, fr.axis, col,
                f"{t.label} z_hi", "Drag to move this end of the shape",
                radius=small)
        if t.kind == "sphere":
            e_r = fr.e2
            add(f"t:{t.var}:R", "radial", centre + t.radius * e_r, centre,
                e_r, col, f"{t.label} radius",
                "Drag to resize the sphere",
                radius=0.8 * self.handle_scale())

    def handle_actors(self) -> dict:
        return {h.actor: h for h in self.handles}

    def highlight(self, handle: Handle | None) -> None:
        base = self.handle_scale()
        for h in self.handles:
            p = h.actor.GetProperty()
            if handle is not None and h is handle:
                p.SetColor(*_hex_rgb(theme.HANDLE_HOT))
                h.actor._source.SetRadius(base * 1.45)
            else:
                h.actor._source.SetRadius(base)
            h.actor._source.Modified()


def _iso_actor(xs, ys, zs, values, level: float, color, opacity: float,
               matrix) -> vtk.vtkActor | None:
    """One iso-surface of a scalar field sampled in the funnel-local frame."""
    values = np.asarray(values, dtype=np.float32)
    if not np.isfinite(values).any():
        return None
    if float(values.max()) < level or float(values.min()) > level:
        return None
    img = vtk.vtkImageData()
    img.SetDimensions(len(xs), len(ys), len(zs))
    img.SetOrigin(float(xs[0]), float(ys[0]), float(zs[0]))
    img.SetSpacing(float(xs[1] - xs[0]) if len(xs) > 1 else 1.0,
                   float(ys[1] - ys[0]) if len(ys) > 1 else 1.0,
                   float(zs[1] - zs[0]) if len(zs) > 1 else 1.0)
    arr = nps.numpy_to_vtk(np.ascontiguousarray(
        values.transpose(2, 1, 0).ravel()), deep=True)
    arr.SetName("V")
    img.GetPointData().SetScalars(arr)
    surf = vtk.vtkFlyingEdges3D()
    surf.SetInputData(img)
    surf.SetValue(0, float(level))
    surf.ComputeNormalsOn()
    smooth = vtk.vtkWindowedSincPolyDataFilter()
    smooth.SetInputConnection(surf.GetOutputPort())
    smooth.SetNumberOfIterations(10)
    smooth.BoundarySmoothingOff()
    smooth.FeatureEdgeSmoothingOff()
    smooth.NormalizeCoordinatesOn()
    smooth.Update()
    out = smooth.GetOutput()
    if out.GetNumberOfPoints() == 0:
        return None
    mp = vtk.vtkPolyDataMapper()
    mp.SetInputData(out)
    ac = vtk.vtkActor()
    ac.SetMapper(mp)
    m = vtk.vtkMatrix4x4()
    for r in range(4):
        for c in range(4):
            m.SetElement(r, c, float(matrix[r, c]))
    ac.SetUserMatrix(m)
    p = ac.GetProperty()
    p.SetColor(*[float(c) for c in color])
    p.SetOpacity(float(opacity))
    p.SetAmbient(0.5)
    p.SetDiffuse(0.55)
    p.SetSpecular(0.2)
    return ac


def _hex_rgb(s: str):
    s = s.lstrip("#")
    return tuple(int(s[i:i + 2], 16) / 255.0 for i in (0, 2, 4))


def scalar_bar(scale_name: str, vmax: float,
               title: str = "wall energy  kcal/mol") -> vtk.vtkScalarBarActor:
    lut = theme.make_lut(scale_name, 0.0, vmax, max_opacity=1.0,
                         zero_transparent=False)
    bar = vtk.vtkScalarBarActor()
    bar.SetLookupTable(lut)
    bar.SetTitle(title)
    bar.SetNumberOfLabels(5)
    bar.SetOrientationToVertical()
    bar.SetPosition(0.925, 0.06)
    bar.SetWidth(0.055)
    bar.SetHeight(0.34)
    bar.SetUnconstrainedFontSize(True)
    for tp in (bar.GetTitleTextProperty(), bar.GetLabelTextProperty()):
        tp.SetColor(0.82, 0.86, 0.95)
        tp.SetFontSize(11)
        tp.ItalicOff()
        tp.BoldOff()
        tp.SetShadow(False)
    bar.GetTitleTextProperty().SetFontSize(11)
    return bar
