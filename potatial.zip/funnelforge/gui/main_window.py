"""FunnelForge main window: the 3-D funnel designer for Desmond WT-MetaD."""

from __future__ import annotations

import os
import traceback

import numpy as np
from PyQt5 import QtCore, QtWidgets

from ..core.project import Job, APP_NAME, APP_VERSION
from . import theme
from .viewer import Viewer3D
from .panels import FunnelPanel, MetaDPanel, GroupsPanel
from .shapes_panel import ShapesPanel
from .panels_job import JobPanel, ValidatePanel, PotentialPanel, DisplayPanel
from .plots import ProfileDock

SETTINGS = QtCore.QSettings("FunnelForge", "FunnelForge")


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, initial_path: str | None = None):
        super().__init__()
        self.job = Job()
        self._undo: list = []
        self._redo: list = []
        self._last_valid_spec = None
        self.setWindowTitle(f"{APP_NAME} — Desmond Funnel WT-MetaD designer")
        self.resize(1720, 990)
        self.setDockOptions(QtWidgets.QMainWindow.AnimatedDocks |
                            QtWidgets.QMainWindow.AllowTabbedDocks)

        # -- 3-D view
        self.viewer = Viewer3D(self)
        self.setCentralWidget(self.viewer)
        self.viewer.value_of = self.handle_value
        self.viewer.handleGrabbed.connect(lambda key: self.push_undo())
        self.viewer.handleDragged.connect(self.apply_handle)
        self.viewer.handleReleased.connect(self.on_handle_released)
        self.viewer.atomPicked.connect(self.on_atom_picked)
        self.viewer.atomHovered.connect(self.on_atom_hovered)

        # -- panels
        self.funnel = FunnelPanel(self)
        self.shapes = ShapesPanel(self)
        self.metad = MetaDPanel(self)
        self.groups = GroupsPanel(self)
        self.jobpanel = JobPanel(self)
        self.validate = ValidatePanel(self)
        self.potential = PotentialPanel(self)
        self.display = DisplayPanel(self)

        self.tabs = QtWidgets.QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.addTab(self.funnel, "Funnel")
        self.tabs.addTab(self.shapes, "Shapes")
        self.tabs.addTab(self.metad, "MetaD")
        self.tabs.addTab(self.groups, "Groups")
        self.tabs.addTab(self.display, "View")
        self.tabs.addTab(self.jobpanel, "Job files")
        self.tabs.addTab(self.validate, "Check")
        self.tabs.addTab(self.potential, ".pot")

        self.right = QtWidgets.QDockWidget("Design")
        self.right.setObjectName("design")
        self.right.setWidget(self.tabs)
        self.right.setFeatures(QtWidgets.QDockWidget.DockWidgetMovable |
                               QtWidgets.QDockWidget.DockWidgetFloatable)
        self.right.setMinimumWidth(430)
        self.addDockWidget(QtCore.Qt.RightDockWidgetArea, self.right)

        self.plots = ProfileDock(self)
        self.bottom = QtWidgets.QDockWidget("Profiles")
        self.bottom.setObjectName("profiles")
        self.bottom.setWidget(self.plots)
        self.bottom.setMinimumHeight(240)
        self.addDockWidget(QtCore.Qt.BottomDockWidgetArea, self.bottom)

        # -- wiring
        self.funnel.changed.connect(lambda: self.on_changed(geometry=True))
        self.funnel.requestFit.connect(self.suggest_funnel)
        self.funnel.requestReset.connect(self.revert_spec)
        self.shapes.changed.connect(lambda: self.on_changed(geometry=True))
        self.metad.changed.connect(lambda: self.on_changed())
        self.groups.changed.connect(lambda: self.on_changed(geometry=True,
                                                           structure=True))
        self.groups.suggestRequested.connect(self.suggest_groups)
        self.jobpanel.changed.connect(lambda: self.on_changed())
        self.jobpanel.exportRequested.connect(self.do_export)
        self.validate.recheckRequested.connect(self.run_validation)
        self.validate.verifyRequested.connect(self.do_verify)
        self.display.changed.connect(self.on_display_changed)
        self.display.funnelChanged.connect(self.on_funnel_display_changed)

        self._t_pot = QtCore.QTimer(self, singleShot=True, interval=180)
        self._t_pot.timeout.connect(self.potential.refresh)
        self._t_val = QtCore.QTimer(self, singleShot=True, interval=550)
        self._t_val.timeout.connect(self.run_validation)
        self._t_plot = QtCore.QTimer(self, singleShot=True, interval=260)
        self._t_plot.timeout.connect(self._refresh_plots)

        self._build_menu()
        self._build_toolbar()
        self._build_status()
        self._restore_state()
        self.set_enabled(False)
        if initial_path:
            QtCore.QTimer.singleShot(60, lambda: self.import_bundle(initial_path))

    # ------------------------------------------------------------------
    # chrome
    # ------------------------------------------------------------------
    def _act(self, text, slot, shortcut=None, tip="", checkable=False):
        a = QtWidgets.QAction(text, self)
        a.triggered.connect(slot)
        if shortcut:
            a.setShortcut(shortcut)
        if tip:
            a.setToolTip(tip)
            a.setStatusTip(tip)
        a.setCheckable(checkable)
        return a

    def _build_menu(self):
        m = self.menuBar()
        f = m.addMenu("&File")
        f.addAction(self._act("Import job set…", self.pick_bundle, "Ctrl+O",
                              "Pick any of the .pot/.cms/.msj/.cfg/.sh files; "
                              "the whole set is imported together."))
        f.addAction(self._act("Attach a different .cms…", self.pick_cms, "",
                              "Keep the current potential but load another "
                              "structure."))
        f.addSeparator()
        f.addAction(self._act("Export job set…", self.do_export, "Ctrl+E"))
        f.addAction(self._act("Save .pot only…", self.potential._save,
                              "Ctrl+Shift+S"))
        f.addSeparator()
        f.addAction(self._act("Save session…", self.save_session, "Ctrl+S"))
        f.addAction(self._act("Load session…", self.load_session, ""))
        f.addSeparator()
        self.recent_menu = f.addMenu("Recent jobs")
        self._refresh_recent()
        f.addSeparator()
        f.addAction(self._act("Quit", self.close, "Ctrl+Q"))

        e = m.addMenu("&Edit")
        e.addAction(self._act("Undo", self.undo, "Ctrl+Z"))
        e.addAction(self._act("Redo", self.redo, "Ctrl+Shift+Z"))
        e.addSeparator()
        e.addAction(self._act("Revert to the imported potential",
                              self.revert_spec))
        e.addAction(self._act("Suggest funnel from the pocket",
                              self.suggest_funnel, "Ctrl+F"))
        e.addAction(self._act("Suggest CV groups from the structure",
                              self.suggest_groups, "Ctrl+G"))
        e.addSeparator()
        for kind in ("funnel", "lathe", "sphere", "slab", "expression"):
            e.addAction(self._act(
                f"Add a {kind} potential term",
                lambda checked=False, k=kind: self._add_term(k)))
        e.addSeparator()
        e.addAction(self._act("Recompute kTemp from γ and T",
                              self.recompute_ktemp))

        v = m.addMenu("&View")
        v.addAction(self._act("Look down the funnel axis",
                              self.viewer.view_funnel_axis, "1"))
        v.addAction(self._act("Look across the axis",
                              self.viewer.view_funnel_side, "2"))
        v.addAction(self._act("Fit the funnel", self.viewer.fit_funnel, "3"))
        v.addAction(self._act("Fit everything", self.viewer.fit_all, "4"))
        v.addAction(self._act("Centre on the ligand", self.viewer.fit_ligand,
                              "5"))
        v.addSeparator()
        v.addAction(self._act("Save a snapshot…", self.snapshot, "Ctrl+P"))
        v.addSeparator()
        v.addAction(self._act("Toggle high-quality transparency",
                              lambda: self.display.peel.setChecked(
                                  not self.display.peel.isChecked())))
        v.addSeparator()
        v.addAction(self._act("Design panel", lambda: self.right.setVisible(
            not self.right.isVisible()), "F9"))
        v.addAction(self._act("Profile plots", lambda: self.bottom.setVisible(
            not self.bottom.isVisible()), "F10"))

        t = m.addMenu("&Tools")
        t.addAction(self._act("Re-check everything", self.run_validation, "F5"))
        t.addAction(self._act("Verify the potential numerically",
                              self.do_verify, "F6"))
        t.addAction(self._act("Probe the potential at the ligand…",
                              self.probe_dialog))
        t.addSeparator()
        t.addAction(self._act("Open the source workbench…",
                              self.open_source_workbench, "Ctrl+Shift+S"))
        h = m.addMenu("&Help")
        h.addAction(self._act("How this maps onto Desmond", self.help_dialog))
        h.addAction(self._act("About", self.about))

    def open_source_workbench(self):
        """The general .pot source editor, on this job's potential if there is one.

        The designer models one shape of potential; the workbench models the
        *language*, so it opens any Desmond potential - including ones this
        interface cannot draw - and never rewrites what it cannot model.
        """
        from .source_window import SourceWindow
        path = ""
        if getattr(self.job, "pot_path", ""):
            path = self.job.pot_path
        elif getattr(self.job, "paths", None) is not None:
            path = getattr(self.job.paths, "pot", "") or ""
        win = SourceWindow(path, parent=None)
        if self.job.structure is not None:
            # Open the current edited potential, not a stale on-disk copy.
            try:
                current = self.job.pot_text()
                if win.editor.toPlainText() != current:
                    win.editor.setPlainText(current)
                    win._reanalyse()
            except ValueError:
                # The workbench remains available for repairing source that
                # cannot currently be represented by the designer controls.
                pass
        if self.job.structure is not None and \
                getattr(self.job.structure, "path", ""):
            win.cms_path = self.job.structure.path
            win._reanalyse()
        win.show()
        self._source_windows = getattr(self, "_source_windows", [])
        self._source_windows.append(win)
        return win

    def _build_toolbar(self):
        tb = QtWidgets.QToolBar("main")
        tb.setObjectName("main")
        tb.setIconSize(QtCore.QSize(16, 16))
        tb.setToolButtonStyle(QtCore.Qt.ToolButtonTextOnly)
        self.addToolBar(tb)
        tb.addAction(self._act("Import", self.pick_bundle))
        tb.addAction(self._act("Export", self.do_export))
        tb.addSeparator()
        tb.addAction(self._act("Axis view", self.viewer.view_funnel_axis))
        tb.addAction(self._act("Side view", self.viewer.view_funnel_side))
        tb.addAction(self._act("Fit funnel", self.viewer.fit_funnel))
        tb.addAction(self._act("Fit all", self.viewer.fit_all))
        tb.addSeparator()
        self.act_pick = self._act("Pick atoms", self.toggle_pick,
                                  tip="Click atoms in the 3-D view to edit the "
                                      "active group.", checkable=True)
        tb.addAction(self.act_pick)
        self.act_handles = self._act("Handles", self.toggle_handles,
                                     tip="Show the draggable geometry handles.",
                                     checkable=True)
        self.act_handles.setChecked(True)
        tb.addAction(self.act_handles)
        tb.addSeparator()
        tb.addWidget(QtWidgets.QLabel(" preset "))
        self.preset_combo = QtWidgets.QComboBox()
        self.preset_combo.addItems(["Shape only", "Shells (default)",
                                    "Cross-section", "Volume glow",
                                    "Everything"])
        self.preset_combo.setCurrentText("Shells (default)")
        self.preset_combo.currentTextChanged.connect(
            self.display.preset.setCurrentText)
        self.preset_combo.currentTextChanged.connect(
            self.display._apply_preset)
        tb.addWidget(self.preset_combo)
        tb.addSeparator()
        tb.addAction(self._act("Verify", self.do_verify))
        tb.addAction(self._act("Snapshot", self.snapshot))

    def _build_status(self):
        sb = self.statusBar()
        self.lbl_struct = QtWidgets.QLabel("no structure")
        self.lbl_hover = QtWidgets.QLabel("")
        self.lbl_hover.setMinimumWidth(240)
        self.lbl_check = QtWidgets.QLabel("")
        sb.addWidget(self.lbl_struct)
        sb.addWidget(self.lbl_hover, 1)
        sb.addPermanentWidget(self.lbl_check)

    def set_enabled(self, on: bool):
        for w in (self.funnel, self.metad, self.groups, self.jobpanel,
                  self.display, self.potential):
            w.setEnabled(on)

    # ------------------------------------------------------------------
    # import / export
    # ------------------------------------------------------------------
    def pick_bundle(self):
        start = SETTINGS.value("lastdir", os.path.expanduser("~"))
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Import a Desmond funnel-metadynamics job", start,
            "Desmond job packages (*.zip *.pot *.cms *.msj *.cfg *.sh);;All files (*)")
        if path:
            self.import_bundle(path)

    def pick_cms(self):
        start = SETTINGS.value("lastdir", os.path.expanduser("~"))
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Attach a structure", start, "Desmond structure (*.cms *.mae)")
        if not path:
            return
        prog = self._progress("Reading structure")
        try:
            self.job.attach_structure(path, progress=lambda f, m: self._tick(
                prog, f, m))
        finally:
            prog.close()
        self.after_import()

    def import_bundle(self, path: str):
        prog = self._progress("Importing job")
        try:
            rep = self.job.import_bundle(path, progress=lambda f, m: self._tick(
                prog, f, m))
        except Exception as exc:
            prog.close()
            QtWidgets.QMessageBox.critical(
                self, "Import failed",
                f"{exc}\n\n{traceback.format_exc(limit=3)}")
            return
        prog.close()
        SETTINGS.setValue("lastdir", os.path.dirname(os.path.abspath(path)))
        self._push_recent(path)
        self.after_import(rep)

    def _progress(self, title: str) -> QtWidgets.QProgressDialog:
        d = QtWidgets.QProgressDialog(title, "", 0, 100, self)
        d.setWindowTitle(APP_NAME)
        d.setCancelButton(None)
        d.setWindowModality(QtCore.Qt.ApplicationModal)
        d.setMinimumDuration(0)
        d.setAutoClose(False)
        d.show()
        QtWidgets.QApplication.processEvents()
        return d

    def _tick(self, dialog, fraction, message):
        dialog.setValue(int(max(0.0, min(1.0, fraction)) * 100))
        dialog.setLabelText(str(message))
        QtWidgets.QApplication.processEvents()

    def after_import(self, rep=None):
        self.set_enabled(True)
        self.job.refresh_model()
        self.viewer.set_job(self.job.structure, self.job.model,
                            view="side")
        self.display.refresh()
        self.refresh_all()
        st = self.job.structure
        if st is not None:
            L = np.linalg.norm(st.box, axis=1)
            self.lbl_struct.setText(
                f"{os.path.basename(self.job.paths.cms or '')} · "
                f"{st.n_atoms:,} atoms · box {L[0]:.1f}×{L[1]:.1f}×{L[2]:.1f} Å"
                f" · {len(st.residues):,} residues")
        self.setWindowTitle(f"{APP_NAME} — {self.job.jobname}")
        self._undo.clear()
        self._redo.clear()
        self._last_valid_spec = self.job.spec.copy()
        if rep is not None:
            self._import_report(rep)

    def _import_report(self, rep):
        lines = []
        if rep.loaded:
            lines.append("<b>Loaded</b><br>" + "<br>".join(
                f"· {os.path.basename(p)}" for p in rep.loaded))
        if rep.missing:
            lines.append("<b>Missing</b><br>" + "<br>".join(
                f"· {m}" for m in rep.missing))
        pr = rep.pot_report
        if pr is not None:
            lines.append(f"<b>Potential</b><br>· {pr.summary()}")
            for w in pr.warnings[:6]:
                lines.append(f"<span style='color:{theme.WARN}'>· {w}</span>")
            for e in pr.errors[:6]:
                lines.append(f"<span style='color:{theme.BAD}'>· {e}</span>")
            for u in pr.unknown_statements[:6]:
                lines.append(f"<span style='color:{theme.WARN}'>· not "
                             f"modelled: <code>{u}</code></span>")
        for m in rep.messages:
            lines.append(f"<span style='color:{theme.WARN}'>· {m}</span>")
        lines.append(f"<br><i>{rep.seconds:.2f} s</i>")
        box = QtWidgets.QMessageBox(self)
        box.setWindowTitle("Import report")
        box.setTextFormat(QtCore.Qt.RichText)
        box.setText("<br><br>".join(lines))
        box.setIcon(QtWidgets.QMessageBox.Information
                    if not (pr and pr.errors) else
                    QtWidgets.QMessageBox.Warning)
        box.exec_()

    def do_export(self):
        if self.job.structure is None:
            return
        opts = self.jobpanel.export_options()
        outdir = opts.pop("outdir")
        if not outdir:
            QtWidgets.QMessageBox.warning(
                self, "Export", "Choose an output folder first.")
            self.tabs.setCurrentWidget(self.jobpanel)
            return
        jobname = opts.pop("jobname") or self.job.jobname
        issues = self.job.validate()
        errors = [i for i in issues if i.level == "error"]
        if errors:
            text = "\n".join(f"· {i.message}" for i in errors[:8])
            ans = QtWidgets.QMessageBox.warning(
                self, "Export anyway?",
                f"The job still has {len(errors)} error(s):\n\n{text}\n\n"
                "Write the files regardless?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No)
            if ans != QtWidgets.QMessageBox.Yes:
                self.tabs.setCurrentWidget(self.validate)
                return
        existing = [f"{jobname}{ext}" for ext in (".pot", ".msj", ".cfg", ".sh")
                    if os.path.exists(os.path.join(outdir, f"{jobname}{ext}"))]
        if existing:
            ans = QtWidgets.QMessageBox.question(
                self, "Overwrite?",
                "These files already exist in the folder and will be "
                "replaced:\n\n" + "\n".join("· " + e for e in existing),
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No)
            if ans != QtWidgets.QMessageBox.Yes:
                return
        try:
            res = self.job.export(outdir, jobname, **opts)
            if not res.verified and not res.written:
                v = res.verification
                ans = QtWidgets.QMessageBox.critical(
                    self, "Verification failed",
                    "The generated potential did not re-evaluate to the "
                    "values shown in this interface, so nothing was "
                    "written.\n\n"
                    f"{v.get('error', '')}\n"
                    f"worst deviation: {v.get('worst', 0):.3g}\n\n"
                    "Write the files anyway?",
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.No)
                if ans == QtWidgets.QMessageBox.Yes:
                    res = self.job.export(outdir, jobname, force=True, **opts)
                else:
                    self.validate.set_verification(res.verification)
                    self.tabs.setCurrentWidget(self.validate)
                    return
        except Exception as exc:
            QtWidgets.QMessageBox.critical(
                self, "Export failed",
                f"{exc}\n\n{traceback.format_exc(limit=4)}")
            return
        self.refresh_all()
        self._export_report(res, outdir, jobname)

    def _export_report(self, res, outdir, jobname):
        v = res.verification
        ok = res.verified
        lines = [f"<b>Written to</b> <code>{outdir}</code><br>" + "<br>".join(
            f"· {os.path.basename(p)}" for p in res.written)]
        if ok:
            lines.append(
                f"<span style='color:{theme.GOOD}'><b>Verified.</b></span> "
                "The exported potential was re-read with an independent "
                "M-expression evaluator; every CV and energy matches this "
                f"interface (worst deviation {v.get('worst_rel', 0):.1e}, "
                f"field deviation {v.get('field_error_rel', 0):.1e}, both "
                f"relative, over {v.get('n_probe', 0)} probe positions).")
        else:
            lines.append(
                f"<span style='color:{theme.BAD}'><b>Verification "
                f"failed.</b></span> {v.get('error', '')}")
        errs = [i for i in res.issues if i.level == "error"]
        warns = [i for i in res.issues if i.level == "warning"]
        if errs:
            lines.append(f"<span style='color:{theme.BAD}'>"
                         f"{len(errs)} error(s) remain</span>")
        if warns:
            lines.append(f"<span style='color:{theme.WARN}'>"
                         f"{len(warns)} warning(s)</span>")
        lines.append("<b>Run it with</b><br>"
                     f"<code>cd {outdir} &amp;&amp; ./{jobname}.sh</code>")
        box = QtWidgets.QMessageBox(self)
        box.setWindowTitle("Export complete")
        box.setTextFormat(QtCore.Qt.RichText)
        box.setText("<br><br>".join(lines))
        box.setIcon(QtWidgets.QMessageBox.Information if ok
                    else QtWidgets.QMessageBox.Critical)
        box.exec_()

    def do_verify(self):
        if self.job.structure is None:
            return
        QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
        try:
            info = self.job.verify_pot_text(self.job.pot_text())
        finally:
            QtWidgets.QApplication.restoreOverrideCursor()
        self.validate.set_verification(info)
        self.tabs.setCurrentWidget(self.validate)
        msg = ("potential verified" if info.get("ok")
               else "potential verification FAILED")
        self.statusBar().showMessage(msg, 6000)

    # ------------------------------------------------------------------
    # change propagation
    # ------------------------------------------------------------------
    def checkpoint(self):
        """Coalesced undo snapshot: at most one every 1.5 s of editing."""
        now = QtCore.QDateTime.currentMSecsSinceEpoch()
        if now - getattr(self, "_last_ckpt", 0) > 1500:
            self._undo.append(self.job.spec.copy())
            del self._undo[:-40]
            self._redo.clear()
        self._last_ckpt = now

    def on_changed(self, geometry: bool = False, structure: bool = False):
        if not self.job.spec.source_adapter:
            self._apply_changed(geometry, structure)
            self._last_valid_spec = self.job.spec.copy()
            return
        try:
            # Check source patches before rendering from a modified spec.
            # Unsupported edits must not escape a Qt signal callback.
            self.job.pot_text()
            self._apply_changed(geometry, structure)
            self._last_valid_spec = self.job.spec.copy()
        except Exception as exc:
            if self._last_valid_spec is not None:
                self.job.spec = self._last_valid_spec.copy()
                self.job.refresh_model()
                self.viewer.model = self.job.model
                self.viewer.rebuild_all()
                self.refresh_all()
            QtWidgets.QMessageBox.warning(
                self, "Custom potential edit", str(exc))

    def _apply_changed(self, geometry: bool = False, structure: bool = False):
        self.checkpoint()
        self.job.refresh_model()
        if geometry and self.job.model is not None:
            pulled = self.job.model.clamp_to_box()
            if pulled:
                self.statusBar().showMessage(
                    "kept inside the solvent box: " + "; ".join(pulled[:3])
                    + (" …" if len(pulled) > 3 else ""), 8000)
                self.funnel.refresh()
                self.shapes.refresh_placement()
        if structure:
            self.viewer.rebuild_structure()
        if geometry or structure:
            self.viewer.rebuild_funnel()
            self.viewer.render()
        self.funnel.refresh_readouts()
        self.shapes.refresh()
        self.metad.refresh_readouts()
        self.jobpanel.refresh_readouts()
        self.groups.refresh()
        self.job.dirty = True
        self._t_pot.start()
        self._t_val.start()
        self.plots.invalidate()
        self._t_plot.start()

    def on_display_changed(self):
        self.viewer.rebuild_structure()
        self.viewer.render()

    def on_funnel_display_changed(self):
        self.viewer.rebuild_funnel()
        self.viewer.render()
        self.plots.invalidate()
        self._t_plot.start()

    def refresh_all(self):
        self.funnel.refresh()
        self.shapes.refresh()
        self.metad.refresh()
        self.groups.refresh()
        self.jobpanel.refresh()
        self.potential.refresh()
        self.run_validation()
        self.plots.invalidate()
        self.plots.refresh()

    def _refresh_plots(self):
        self.plots.refresh()

    def run_validation(self):
        if self.job.structure is None and self.job.cfg is None:
            return
        issues = self.job.validate()
        self.validate.set_issues(issues)
        n_err = sum(1 for i in issues if i.level == "error")
        n_warn = sum(1 for i in issues if i.level == "warning")
        if n_err:
            self.lbl_check.setText(
                f"<span style='color:{theme.BAD}'>● {n_err} error(s)</span>")
        elif n_warn:
            self.lbl_check.setText(
                f"<span style='color:{theme.WARN}'>● {n_warn} warning(s)"
                "</span>")
        else:
            self.lbl_check.setText(
                f"<span style='color:{theme.GOOD}'>● ready</span>")
        idx = self.tabs.indexOf(self.validate)
        if idx >= 0:
            self.tabs.setTabText(idx, f"Check ({n_err + n_warn})"
                                 if (n_err or n_warn) else "Check")

    # ------------------------------------------------------------------
    # handles / picking
    # ------------------------------------------------------------------
    def _term_by_var(self, var: str):
        for t in self.job.spec.terms:
            if t.var == var:
                return t
        return None

    def handle_value(self, key: str) -> float:
        """Current value behind a drag handle, asked for at grab time."""
        sp = self.job.spec
        model = self.job.model
        if key.startswith("t:"):
            _p, var, what = key.split(":", 2)
            t = self._term_by_var(var)
            if t is None:
                return 0.0
            if what.startswith("tilt"):
                return self._swing_value(t, what)
            return {"axial": t.axial_position(), "e1": t.offset_e1,
                    "e2": t.offset_e2, "z_lo": t.z_lo, "z_hi": t.z_hi,
                    "R": t.radius}.get(what, 0.0)
        if key.startswith("axis_tilt"):
            return self._swing_value(None, key[len("axis_"):])
        return {"z_min": sp.z_min, "z_max": sp.z_max, "z_cc": sp.z_cc,
                "r_cyl": sp.r_cyl, "cone": sp.r_base(),
                "origin": model.origin_offset_A if model else 0.0,
                "origin_lat1": sp.origin_lat1,
                "origin_lat2": sp.origin_lat2}.get(key, 0.0)

    def _swing_lever(self, term, low_end: bool) -> float:
        """Distance from the pivot (the shape origin) to the grabbed end."""
        sp = self.job.spec
        if term is None:
            z = sp.z_min if low_end else sp.z_max
        elif term.kind == "sphere":
            z = term.center_z
        else:
            z = term.z_lo if low_end else term.z_hi
        return max(1.0, abs(float(z)))

    def _swing_value(self, term, what: str) -> float:
        """Swing handles carry an arc length, so a drag in Å adds up cleanly.

        The stored value is the tilt component in radians times the lever
        arm, which is exactly the distance the grabbed end travels.
        """
        import math
        low = what.endswith("_lo")
        comp = 1 if what.startswith("tilt1") else 2
        sp = self.job.spec
        if term is None:
            a1, a2 = self._axis_tilt_components()
        else:
            a1, a2 = term.tilt_components()
        a = a1 if comp == 1 else a2
        sign = -1.0 if low else 1.0
        return sign * math.radians(a) * self._swing_lever(term, low)

    def _axis_tilt_components(self):
        import math
        sp = self.job.spec
        t = math.radians(sp.axis_tilt_deg)
        a = math.radians(sp.axis_azimuth_deg)
        return (math.degrees(t * math.cos(a)), math.degrees(t * math.sin(a)))

    def _set_axis_tilt_components(self, a1_deg, a2_deg):
        import math
        sp = self.job.spec
        a1, a2 = math.radians(a1_deg), math.radians(a2_deg)
        sp.axis_tilt_deg = math.degrees(math.hypot(a1, a2))
        sp.axis_azimuth_deg = (math.degrees(math.atan2(a2, a1))
                               if (a1 or a2) else 0.0)

    def _apply_swing(self, term, what: str, value: float) -> None:
        import math
        low = what.endswith("_lo")
        comp = 1 if what.startswith("tilt1") else 2
        lever = self._swing_lever(term, low)
        sign = -1.0 if low else 1.0
        angle = math.degrees(sign * value / lever)
        angle = float(np.clip(angle, -80.0, 80.0))
        if term is None:
            a1, a2 = self._axis_tilt_components()
            if math.isclose(a1 if comp == 1 else a2, angle,
                            rel_tol=0.0, abs_tol=1e-12):
                return
            if comp == 1:
                a1 = angle
            else:
                a2 = angle
            self._set_axis_tilt_components(a1, a2)
        else:
            a1, a2 = term.tilt_components()
            if math.isclose(a1 if comp == 1 else a2, angle,
                            rel_tol=0.0, abs_tol=1e-12):
                return
            if comp == 1:
                a1 = angle
            else:
                a2 = angle
            term.set_tilt_components(a1, a2)

    def apply_handle(self, key: str, value: float):
        sp = self.job.spec
        model = self.job.model
        if model is None:
            return
        limited = self.job.clamp_handle_value(key, value)
        if abs(limited - value) > 1e-9:
            self.statusBar().showMessage(
                f"{key} stopped at {limited:.4f} Å — the solvent box ends "
                "there", 2500)
        value = limited
        if key.startswith("axis_tilt"):
            self._apply_swing(None, key[len("axis_"):], value)
            model.invalidate()
            model.clamp_tilts()
            model.invalidate()
            self.viewer.rebuild_funnel(fast=True)
            self.viewer.render()
            self.funnel.refresh()
            self.statusBar().showMessage(
                f"funnel axis tilted {sp.axis_tilt_deg:.3f}° at azimuth "
                f"{sp.axis_azimuth_deg:.2f}°", 2000)
            return
        if key.startswith("t:"):
            _p, var, what = key.split(":", 2)
            t = self._term_by_var(var)
            if t is None:
                return
            if what.startswith("tilt"):
                self._apply_swing(t, what, value)
                model.invalidate()
                model.clamp_tilts()
                model.invalidate()
                self.viewer.rebuild_funnel(fast=True)
                self.viewer.render()
                self.shapes.refresh_placement()
                self.statusBar().showMessage(
                    f"{t.label} tilted {t.tilt_deg:.3f}° at azimuth "
                    f"{t.azimuth_deg:.2f}°", 2000)
                return
            if what == "axial":
                t.move_axially(value)
            elif what == "e1":
                t.offset_e1 = value
            elif what == "e2":
                t.offset_e2 = value
            elif what == "z_lo":
                t.z_lo = min(value, t.z_hi - 0.25)
            elif what == "z_hi":
                t.z_hi = max(value, t.z_lo + 0.25)
            elif what == "R":
                t.radius = max(0.1, value)
            model.invalidate()
            model.clamp_tilts()
            model.invalidate()
            self.viewer.rebuild_funnel(fast=True)
            self.viewer.render()
            self.shapes.refresh_placement()
            self.statusBar().showMessage(
                f"{t.label} · {what} = {value:.4f} Å", 1500)
            return
        if key in ("origin_lat1", "origin_lat2"):
            setattr(sp, key, value)
            model.invalidate()
            self.viewer.rebuild_funnel(fast=True)
            self.viewer.render()
            self.funnel.refresh()
            self.statusBar().showMessage(f"{key} = {value:.4f} Å", 1500)
            return
        if key == "z_min":
            sp.z_min = min(value, sp.z_max - 0.5)
            sp.literals.pop("z_min", None)
        elif key == "z_max":
            sp.z_max = max(value, sp.z_min + 0.5)
            sp.literals.pop("z_max", None)
        elif key == "z_cc":
            sp.z_cc = value
            sp.literals.pop("z_cc", None)
        elif key == "r_cyl":
            sp.r_cyl = max(0.2, value)
            sp.literals.pop("r_cyl", None)
        elif key == "cone":
            span = sp.z_cc - sp.z_min
            if span > 1e-6:
                sp.cone_slope = max(0.0, (max(sp.r_cyl, value) - sp.r_cyl) / span)
                sp.literals.pop("cone_slope", None)
        elif key == "origin":
            model.set_origin_offset_A(value)
        model.invalidate()
        self.viewer.rebuild_funnel(fast=True)
        self.viewer.render()
        self.funnel.refresh()
        self.statusBar().showMessage(f"{key} = {value:.4f}", 1500)

    def on_handle_released(self, key: str):
        self.viewer.end_drag()
        self.on_changed(geometry=True)

    def toggle_pick(self, on: bool):
        self.set_pick_mode(on)
        if on:
            self.tabs.setCurrentWidget(self.groups)

    def set_pick_mode(self, on: bool):
        self.viewer.pick_mode = on
        self.act_pick.setChecked(on)
        self.viewer.setCursor(QtCore.Qt.CrossCursor if on
                              else QtCore.Qt.ArrowCursor)

    def toggle_handles(self, on: bool):
        self.viewer.funnel.style.show_handles = on
        self.display.f_handles.setChecked(on)
        self.viewer.rebuild_funnel()
        self.viewer.render()

    def on_atom_picked(self, index1: int):
        self.push_undo()
        self.groups.handle_pick(index1)
        st = self.job.structure
        if st is not None:
            self.statusBar().showMessage("picked " + st.describe_atom(index1),
                                         4000)

    def on_atom_hovered(self, text: str):
        self.lbl_hover.setText(text)

    # ------------------------------------------------------------------
    # tools
    # ------------------------------------------------------------------
    def push_undo(self):
        self._undo.append(self.job.spec.copy())
        del self._undo[:-40]
        self._redo.clear()

    def _restore(self, spec):
        self.job.spec = spec
        self.job.refresh_model()
        if self.job.model is not None:
            # a restored state can only ever be moved back in, never out
            pulled = self.job.model.clamp_to_box()
            if pulled:
                self.statusBar().showMessage(
                    "kept inside the solvent box: " + "; ".join(pulled[:2]),
                    6000)
        self.viewer.model = self.job.model
        self.viewer.rebuild_all()
        self.refresh_all()
        self._last_valid_spec = self.job.spec.copy()

    def undo(self):
        if not self._undo:
            return
        self._redo.append(self.job.spec.copy())
        self._restore(self._undo.pop())

    def redo(self):
        if not self._redo:
            return
        self._undo.append(self.job.spec.copy())
        self._restore(self._redo.pop())

    def revert_spec(self):
        src = self.job.spec.source_text
        if not src:
            QtWidgets.QMessageBox.information(
                self, "Revert", "No imported potential to revert to.")
            return
        from ..core.potfile import parse_pot
        self.push_undo()
        spec, _ = parse_pot(src, self.job.spec.source_path)
        self.job.spec = spec
        self.job.refresh_model()
        self.viewer.model = self.job.model
        self.viewer.rebuild_all()
        self.refresh_all()
        self.statusBar().showMessage("reverted to the imported potential", 4000)

    def recompute_ktemp(self):
        self.push_undo()
        self.job.spec.sync_ktemp()
        self.metad.lock_ktemp.setChecked(False)
        self.metad.refresh()
        self.on_changed()

    def _add_term(self, kind: str):
        self.push_undo()
        self.tabs.setCurrentWidget(self.shapes)
        if kind == "funnel":
            self.shapes.add_funnel()
        else:
            self.shapes._add(kind)

    def choose_ligand(self) -> list | None:
        """Ask which molecule is the ligand instead of guessing silently."""
        st = self.job.structure
        if st is None:
            return None
        from ..core.autobuild import candidate_ligands
        cands = candidate_ligands(st)
        if not cands:
            QtWidgets.QMessageBox.information(
                self, "Ligand",
                "No non-solvent, non-ion residue was found. Select the ligand "
                "by hand in the Groups tab.")
            return None
        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle("Which molecule is the ligand?")
        dlg.resize(560, 420)
        lay = QtWidgets.QVBoxLayout(dlg)
        lay.addWidget(QtWidgets.QLabel(
            "The biased particle is the centre of mass of this group. Pick "
            "the molecule you want to pull out of the pocket:"))
        tree = QtWidgets.QTreeWidget()
        tree.setHeaderLabels(["residue", "heavy atoms", "atom range"])
        tree.setColumnWidth(0, 160)
        for res, n, idx in cands:
            it = QtWidgets.QTreeWidgetItem(
                tree, [res.long_label, str(n), f"{idx[0]}-{idx[-1]}"])
            it.setData(0, QtCore.Qt.UserRole, idx)
        tree.setCurrentItem(tree.topLevelItem(0))
        lay.addWidget(tree, 1)
        note = QtWidgets.QLabel(
            "Or close this and use <b>Set from clicked residue</b> in the "
            "Groups tab to click it directly in the 3-D view.")
        note.setWordWrap(True)
        note.setProperty("dim", "true")
        lay.addWidget(note)
        buttons = QtWidgets.QHBoxLayout()
        ok = QtWidgets.QPushButton("Use this one")
        ok.setProperty("accent", "true")
        cancel = QtWidgets.QPushButton("Cancel")
        buttons.addStretch(1)
        buttons.addWidget(ok)
        buttons.addWidget(cancel)
        lay.addLayout(buttons)
        ok.clicked.connect(dlg.accept)
        cancel.clicked.connect(dlg.reject)
        tree.itemDoubleClicked.connect(lambda *a: dlg.accept())
        if dlg.exec_() != QtWidgets.QDialog.Accepted:
            return None
        it = tree.currentItem()
        return list(it.data(0, QtCore.Qt.UserRole)) if it else None

    def suggest_groups(self):
        """Fill the CV groups, keeping whatever ligand the user already chose."""
        st = self.job.structure
        if st is None:
            return
        from ..core.autobuild import suggest_groups
        sp = self.job.spec
        pinned = list(sp.lig.indices) if sp.lig.indices else None
        if pinned is None:
            pinned = self.choose_ligand()
            if pinned is None:
                return
        try:
            sug = suggest_groups(st, lig_indices=pinned,
                                 site_indices=(list(sp.site.indices)
                                               if sp.site.indices else None),
                                 core_indices=(list(sp.core.indices)
                                               if sp.core.indices else None))
        except Exception as exc:
            QtWidgets.QMessageBox.warning(self, "Suggest groups", str(exc))
            return
        self.push_undo()
        sp.lig, sp.site, sp.core = sug.lig, sug.site, sug.core
        sp.ligand_label = sug.label
        self.job.refresh_model()
        self.viewer.model = self.job.model
        self.viewer.rebuild_all()
        self.refresh_all()
        QtWidgets.QMessageBox.information(
            self, "Suggested CV groups",
            "\n".join("- " + n for n in sug.notes) +
            "\n\nNothing you had already selected was replaced - only the "
            "empty groups were filled in. SITE and CORE are backbone groups "
            "of ordinary residues by design: they are what fixes the funnel "
            "axis to the protein, and they are not part of the biased "
            "particle.\n\nClear a group in the Groups tab if you want it "
            "re-suggested, then fit a funnel with Ctrl+F.")

    def suggest_funnel(self):
        st, model = self.job.structure, self.job.model
        if st is None or model is None:
            return
        if not (self.job.spec.lig.indices and self.job.spec.site.indices
                and self.job.spec.core.indices):
            QtWidgets.QMessageBox.information(
                self, "Suggest funnel",
                "The ligand, SITE and CORE groups have to be defined first - "
                "use Suggest CV groups from the structure (Ctrl+G), or set "
                "them in the Groups tab.")
            return
        self.push_undo()
        rep = model.initialise_funnel(cutoff=self.job.cutoff_radius)
        self.viewer.rebuild_funnel()
        self.viewer.render()
        self.refresh_all()
        opened = ("the channel opens into bulk here"
                  if rep["channel_opened"] else
                  "no clear opening was found; this is the widest point")
        QtWidgets.QMessageBox.information(
            self, "Funnel fitted to the pocket",
            f"Ligand starts at z = {rep['z0']:.3f} Å, ρ = {rep['rho0']:.3f} Å.\n\n"
            f"z_min = {rep['z_min']:.3f} Å   (3 Å below the bound state)\n"
            f"z_cc  = {rep['z_cc']:.3f} Å   ({opened}; the axis is clear of "
            f"solute by {rep['free_at_zcc']:.2f} Å there)\n"
            f"z_max = {rep['z_max']:.3f} Å"
            + (f"   (pulled back {rep['pulled_back']:.1f} Å for the box)\n"
               if rep["pulled_back"] else "\n")
            + f"r_cyl = {rep['r_cyl']:.3f} Å   ·   cone "
            f"{rep['cone_deg']:.2f}°  →  R_base = {rep['r_base']:.3f} Å\n"
            f"envelope clears every box face by {rep['clearance']:.2f} Å\n"
            f"restraint energy at the start: {rep['start_energy']:.4f} "
            "kcal/mol\n"
            f"{rep['atoms_in_funnel']} solute heavy atoms lie inside the "
            "funnel volume, which is normal - the wall only ever acts on the "
            "ligand.\n\n"
            "z_cc comes from the solvent-accessible radius along the axis, so "
            "the cylinder starts where the channel really opens into bulk. "
            "The cone is the usual 30°, widened only if the ligand needed the "
            "room.\n\nEvery number stays editable: by hand here and in the "
            "Shapes tab, or by dragging the handles in the 3-D view.")

    def probe_dialog(self):
        if self.job.structure is None:
            return
        from ..core.mexpr import evaluate_pot
        try:
            res = evaluate_pot(self.job.pot_text(), self.job.structure)
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "Probe", str(exc))
            return
        rows = "".join(
            f"<tr><td><code>{k}</code></td><td align='right'>"
            f"<code>{v:.6f}</code></td></tr>"
            for k, v in res.printed().items())
        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle("Potential evaluated at the current geometry")
        lay = QtWidgets.QVBoxLayout(dlg)
        lbl = QtWidgets.QLabel(
            "<p>Every <code>print()</code> in the generated potential, "
            "evaluated by the built-in M-expression interpreter with no hills "
            "deposited (t = 0):</p>"
            f"<table cellpadding='3'>{rows}</table>")
        lbl.setTextFormat(QtCore.Qt.RichText)
        lay.addWidget(lbl)
        b = QtWidgets.QPushButton("Close")
        b.clicked.connect(dlg.accept)
        lay.addWidget(b)
        dlg.exec_()

    def snapshot(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Save snapshot", f"{self.job.jobname}_funnel.png",
            "PNG image (*.png)")
        if not path:
            return
        self.viewer.screenshot(path, magnification=2)
        self.statusBar().showMessage(f"snapshot written to {path}", 6000)

    # ------------------------------------------------------------------
    # sessions / settings
    # ------------------------------------------------------------------
    def save_session(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Save session", f"{self.job.jobname}.funnelforge.json",
            "FunnelForge session (*.json)")
        if path:
            self.job.save_session(path)
            self.statusBar().showMessage(f"session saved to {path}", 5000)

    def load_session(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Load session", SETTINGS.value("lastdir",
                                                 os.path.expanduser("~")),
            "FunnelForge session (*.json)")
        if not path:
            return
        prog = self._progress("Loading session")
        try:
            rep = self.job.load_session(path, progress=lambda f, m: self._tick(
                prog, f, m))
        except Exception as exc:
            prog.close()
            QtWidgets.QMessageBox.critical(self, "Session", str(exc))
            return
        prog.close()
        self.after_import(rep)

    def _push_recent(self, path: str):
        items = SETTINGS.value("recent", []) or []
        if isinstance(items, str):
            items = [items]
        items = [p for p in items if p != path]
        items.insert(0, path)
        SETTINGS.setValue("recent", items[:8])
        self._refresh_recent()

    def _refresh_recent(self):
        self.recent_menu.clear()
        items = SETTINGS.value("recent", []) or []
        if isinstance(items, str):
            items = [items]
        for p in items:
            self.recent_menu.addAction(self._act(
                os.path.basename(p), lambda checked=False, q=p:
                self.import_bundle(q)))
        if not items:
            a = self.recent_menu.addAction("(nothing yet)")
            a.setEnabled(False)

    def _restore_state(self):
        g = SETTINGS.value("geometry")
        if g is not None:
            self.restoreGeometry(g)
        s = SETTINGS.value("state")
        if s is not None:
            self.restoreState(s)

    def closeEvent(self, ev):
        SETTINGS.setValue("geometry", self.saveGeometry())
        SETTINGS.setValue("state", self.saveState())
        super().closeEvent(ev)

    # ------------------------------------------------------------------
    def help_dialog(self):
        text = """
<h3>How this maps onto Desmond</h3>
<p><b>The potential file</b> is a Desmond M-expression evaluated every step by
the backend. <code>declare_meta</code> switches on metadynamics with
<code>dimension</code> CVs, Gaussians truncated at <code>cutoff</code> kernel
widths, the first hill after <code>first</code> ps and one hill every
<code>interval</code> ps, writing the hill history to
<code>name</code>.</p>
<p><b>The funnel</b> is a flat-bottom restraint, not a CV: the biased CV is the
axial coordinate <code>z</code>, while <code>rho</code> only feeds a one-sided
harmonic wall that is exactly zero inside the cone/cylinder. The frame is
built from two backbone groups, so the funnel rotates and translates with the
protein and <code>min_image</code> keeps it valid across the periodic
boundary.</p>
<p><b>Well tempering</b> is done in the file itself: the accumulated bias is
read back with a zero-height <code>meta()</code> call, the next hill height is
scaled by <code>exp(-V/kTemp)</code>, and that height is deposited by the
second <code>meta()</code> call. <code>kTemp = (γ-1)·k<sub>B</sub>·T</code>, so
T here must be the ensemble temperature in the .cfg.</p>
<p><b>The stage chain</b> in the .msj must reach the biased stage with
<code>meta = FILE</code> and <code>meta_file</code> pointing at the potential,
and that stage takes its backend settings from <code>cfg_file</code>. In the
.cfg <code>meta_file</code> stays <code>?</code> because Multisim fills it in.
<code>$JOBNAME</code> inside the potential resolves to the Multisim job name,
which is the <code>-JOBNAME</code> in the launcher, so all five files share one
basename.</p>
<p><b>Sanity limits.</b> The funnel envelope has to stay inside the periodic
box with at least the non-bonded cutoff to spare, the bulk end of the funnel
should contain only solvent, and the ligand must start with zero restraint
energy.  The Check tab tests all of this.</p>

<h3>Shapes other than a funnel</h3>
<p>The Shapes tab adds terms to the same potential, and the built-in funnel can
be switched off entirely.  A <b>lathe</b> term takes a profile
<code>r(z)</code> you write as an expression and turns it around the funnel
axis; the solvent-facing end is closed for you, because that is the end a
dissociating ligand would leave through.  An <b>expression</b> term is emitted
verbatim: the energy is exactly what you type.  <b>Sphere</b> and <b>slab</b>
cover the two common primitives, and a sphere may be centred on the centre of
mass of an atom group, which keeps it valid under rotation and translation.</p>
<p>Each term can be limited to a stretch of the axis.  The switch is a cubic
(smoothstep) ramp of the width you choose, so the energy and its first
derivative stay continuous - a hard gate would jump the energy and kick the
integrator, and the interface says so if you ask for one.  This is how a
region such as the bulk cylinder can carry a tighter wall than the rest of the
funnel.</p>
<p>Terms may also act on a group other than the ligand.  Such a term gets its
own <code>atomsel</code>, centre of mass and CVs in the generated file, so it
restrains that group without touching the metadynamics CV.</p>

<h3>What the language allows</h3>
<p>Expressions are checked against the function table of the Desmond guide
before anything is written.  The traps worth remembering: <code>^</code> takes
<b>integer</b> exponents only and <code>pow(a,b)</code> needs a positive base;
there is no <code>abs</code>, <code>min</code> or <code>max</code>
(use <code>x*sign(x)</code>, or <code>gibbs_min</code>/<code>gibbs_max</code>);
every value is an array, so <code>*</code> is element-wise and an inner product
is <code>dot(a,b)</code>; subtraction does not apply the minimum image; and a
name may be assigned only once.</p>
<p>Each term also writes an <code>@ff-term</code> comment holding its own
definition.  Desmond ignores it, the interface reads the terms back from it,
and on import the block is regenerated and compared with the file so the two
cannot drift apart.  If a potential adds something to <code>v_total</code>
that the interface cannot model, it refuses to export rather than quietly
dropping it.</p>
"""
        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle("Desmond notes")
        dlg.resize(660, 560)
        lay = QtWidgets.QVBoxLayout(dlg)
        br = QtWidgets.QTextBrowser()
        br.setHtml(text)
        lay.addWidget(br)
        b = QtWidgets.QPushButton("Close")
        b.clicked.connect(dlg.accept)
        lay.addWidget(b)
        dlg.exec_()

    def about(self):
        QtWidgets.QMessageBox.about(
            self, f"About {APP_NAME}",
            f"<h3>{APP_NAME} {APP_VERSION}</h3>"
            "<p>A desktop designer for one-dimensional well-tempered "
            "funnel-metadynamics potentials for Desmond.</p>"
            "<p>Imports a whole job set, shows the protein, ligands, solvent "
            "box and funnel in 3-D, lets the funnel be shaped by dragging, "
            "verifies the generated M-expression with an independent "
            "evaluator, and exports a consistent, ready-to-run "
            ".pot/.msj/.cfg/.sh set.</p>")
