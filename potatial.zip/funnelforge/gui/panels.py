"""Parameter panels: funnel geometry, metadynamics, groups, job files."""

from __future__ import annotations

import numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets

from ..core import elements
from ..core.funnel import Diagnostic, Selection, DEFAULT_PRINTS
from ..core.asl import parse_selection, SelectionError, describe_indices
from . import theme
from .widgets import (ParamRow, TextRow, ComboRow, Readout, group, vbox,
                      hline, scroll_area)


# ==========================================================================
class FunnelPanel(QtWidgets.QWidget):
    """Geometry and stiffness of the funnel restraint."""

    changed = QtCore.pyqtSignal()
    geometryChanged = QtCore.pyqtSignal()
    requestFit = QtCore.pyqtSignal()
    requestReset = QtCore.pyqtSignal()

    def __init__(self, window, parent=None):
        super().__init__(parent)
        self.w = window
        self._loading = False

        self.use_funnel = QtWidgets.QCheckBox(
            "Use the built-in funnel (cone + cylinder + axial walls)")
        self.use_funnel.setToolTip(
            "An imported job without a .pot has no funnel. Tick this to "
            "create one fitted to the pocket, or build the restraint out of "
            "shape terms instead.")
        self.use_funnel.toggled.connect(self._funnel_toggled)
        self.no_funnel_note = QtWidgets.QLabel(
            "No funnel is defined - nothing was invented for you. "
            "Tick the box above, or use the Shapes tab.")
        self.no_funnel_note.setWordWrap(True)
        self.no_funnel_note.setProperty("dim", "true")
        self.origin_lat1 = ParamRow("origin e1", 0.0, -80, 80, 0.05, 6, "Å",
                                    tip="Slides the funnel sideways across the "
                                        "axis. Needs a frame reference group "
                                        "(Shapes tab); leaves z untouched and "
                                        "changes only rho.")
        self.axis_tilt = ParamRow("axis tilt", 0.0, 0.0, 60.0, 0.25, 4, "°",
                                  tip="Turns the biased coordinate away from "
                                      "the CORE→SITE direction, in the "
                                      "body-fixed frame. Needs a frame "
                                      "reference group (Shapes tab).")
        self.axis_azimuth = ParamRow("tilt towards", 0.0, -180.0, 180.0, 1.0,
                                     4, "°")
        self.origin_lat2 = ParamRow("origin e2", 0.0, -80, 80, 0.05, 6, "Å")
        for row in (self.origin_lat1, self.origin_lat2, self.axis_tilt,
                    self.axis_azimuth):
            row.valueChanged.connect(self._push_lateral)
        self.z_cc = ParamRow("z_cc", 26.0, -50, 120, 0.25, 4, "Å",
                             tip="Axial position where the cone meets the "
                                 "bulk cylinder.")
        self.r_cyl = ParamRow("r_cyl", 4.0, 0.2, 40, 0.1, 4, "Å",
                              tip="Radius of the cylindrical channel in bulk "
                                  "solvent.")
        self.cone_deg = ParamRow("cone angle", 31.5, 0.0, 80.0, 0.25, 4, "°",
                                 tip="Half-angle of the cone at the pocket; "
                                     "slope = tan(angle).")
        self.cone_slope = ParamRow("cone slope", 0.6131, 0.0, 6.0, 0.01, 6, "",
                                   tip="dr/dz of the cone wall (the value "
                                       "written to the .pot).")
        self.z_min = ParamRow("z_min", -4.0, -80, 80, 0.25, 4, "Å",
                              tip="Lower axial wall, inside the pocket.")
        self.z_max = ParamRow("z_max", 34.0, -20, 150, 0.25, 4, "Å",
                              tip="Upper axial wall, in bulk solvent.")
        self.origin_off = ParamRow("origin", 10.4865, -80, 80, 0.05, 6, "Å",
                                   tip="Offset of the funnel origin from the "
                                       "CORE centre of mass, along the axis.")
        self.origin_frac = ParamRow("origin frac", 0.5334, -3.0, 3.0, 0.001, 9,
                                    "", slider=False,
                                    tip="The literal written to the .pot: "
                                        "origin = core_com + f*axis_raw.")
        self.r_base_lbl = QtWidgets.QLabel()
        self.r_base_lbl.setProperty("dim", "true")
        self.r_base_lbl.setWordWrap(True)

        self.k_rad = ParamRow("k_rad", 25.0, 0.1, 500, 1.0, 4,
                             "kcal/mol/Å²",
                             tip="Radial flat-bottom wall force constant.")
        self.k_z = ParamRow("k_z", 50.0, 0.1, 500, 1.0, 4, "kcal/mol/Å²",
                            tip="Axial end-wall force constant.")
        self.stiff = Readout([("r1", "V at 1 Å out"), ("r2", "V at 2 Å out"),
                              ("z1", "V_z at 1 Å out"), ("z2", "V_z at 2 Å out")])

        self.live = Readout([
            ("z0", "ligand z"), ("rho0", "ligand ρ"),
            ("rall", "r_allowed(z)"), ("v0", "start V"),
            ("axis", "axis length"), ("vol", "funnel volume"),
            ("clear", "box clearance"), ("nat", "solute atoms inside"),
        ])

        self.snap = ComboRow("drag snap", ["off", "0.01 Å", "0.05 Å", "0.1 Å",
                                          "0.25 Å", "0.5 Å", "1 Å"], "off",
                             tip="Quantise 3-D handle dragging. Hold Shift, "
                                 "Ctrl or both while dragging for 5x, 20x and "
                                 "100x finer control.")
        fit = QtWidgets.QPushButton("Suggest funnel from pocket")
        fit.setToolTip("Fit z_min/z_max/z_cc and the cone to the current "
                       "ligand position and the solvent boundary.")
        fit.clicked.connect(self.requestFit.emit)
        reset = QtWidgets.QPushButton("Revert to imported")
        reset.clicked.connect(self.requestReset.emit)
        btns = QtWidgets.QHBoxLayout()
        btns.addWidget(fit)
        btns.addWidget(reset)

        self.shape_group = group("Funnel shape", self.z_cc, self.r_cyl,
                                 self.cone_deg, self.cone_slope, self.z_min,
                                 self.z_max, self.r_base_lbl)
        inner = vbox(
            group("Built-in funnel", self.use_funnel, self.no_funnel_note),
            self.shape_group,
            group("Funnel origin", self.origin_off, self.origin_frac,
                  self.origin_lat1, self.origin_lat2, hline(),
                  self.axis_tilt, self.axis_azimuth),
            group("Wall stiffness", self.k_rad, self.k_z, hline(), self.stiff),
            group("Live collective variables", self.live),
            group("Interaction", self.snap, btns),
            None)
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(scroll_area(inner))

        for row in (self.z_cc, self.r_cyl, self.z_min, self.z_max,
                    self.k_rad, self.k_z):
            row.valueChanged.connect(self._push)
        self.cone_deg.valueChanged.connect(self._from_angle)
        self.cone_slope.valueChanged.connect(self._from_slope)
        self.origin_off.valueChanged.connect(self._from_offset)
        self.origin_frac.valueChanged.connect(self._from_frac)
        self.snap.currentChanged.connect(self._snap_changed)

    # -- sync out
    def _push(self, *_):
        if self._loading:
            return
        sp = self.w.job.spec
        sender = self.sender()
        for attr, row in (("z_cc", self.z_cc), ("r_cyl", self.r_cyl),
                          ("z_min", self.z_min), ("z_max", self.z_max),
                          ("k_rad", self.k_rad), ("k_z", self.k_z)):
            if sender is not None and sender is not row:
                continue
            v = row.value()
            if getattr(sp, attr) != v:
                setattr(sp, attr, v)
                sp.literals.pop(attr, None)
        self.geometryChanged.emit()
        self.changed.emit()

    def _from_angle(self, deg):
        if self._loading:
            return
        sp = self.w.job.spec
        sp.set_cone_angle_deg(deg)
        sp.literals.pop("cone_slope", None)
        self._loading = True
        self.cone_slope.setValue(sp.cone_slope)
        self._loading = False
        self.geometryChanged.emit()
        self.changed.emit()

    def _from_slope(self, slope):
        if self._loading:
            return
        sp = self.w.job.spec
        sp.cone_slope = slope
        sp.literals.pop("cone_slope", None)
        self._loading = True
        self.cone_deg.setValue(sp.cone_angle_deg)
        self._loading = False
        self.geometryChanged.emit()
        self.changed.emit()

    def _from_offset(self, value):
        if self._loading:
            return
        model = self.w.job.model
        if model is None:
            return
        model.set_origin_offset_A(value)
        self._loading = True
        self.origin_frac.setValue(self.w.job.spec.origin_frac)
        self._loading = False
        self.geometryChanged.emit()
        self.changed.emit()

    def _from_frac(self, value):
        if self._loading:
            return
        sp = self.w.job.spec
        sp.origin_mode = "fraction"
        sp.origin_frac = value
        sp.literals.pop("origin_frac", None)
        if self.w.job.model:
            self.w.job.model.invalidate()
            self._loading = True
            self.origin_off.setValue(self.w.job.model.origin_offset_A)
            self._loading = False
        self.geometryChanged.emit()
        self.changed.emit()

    def _funnel_toggled(self, on: bool):
        if self._loading:
            return
        job = self.w.job
        if on and job.model is not None and job.model.funnel_is_degenerate():
            if not (job.spec.lig.indices and job.spec.site.indices
                    and job.spec.core.indices):
                QtWidgets.QMessageBox.information(
                    self, "Add a funnel",
                    "The funnel axis comes from the ligand, SITE and CORE "
                    "groups, so those have to exist first (Ctrl+G suggests "
                    "them).")
                self._loading = True
                self.use_funnel.setChecked(False)
                self._loading = False
                return
            self.w.push_undo()
            job.model.initialise_funnel(cutoff=job.cutoff_radius)
        job.spec.funnel_enabled = on
        self.geometryChanged.emit()
        self.changed.emit()

    def _push_lateral(self, *_):
        if self._loading:
            return
        sp = self.w.job.spec
        wants_frame = bool(self.origin_lat1.value() or self.origin_lat2.value()
                           or self.axis_tilt.value())
        if wants_frame and not self.w.shapes.ensure_frame_ref(
                "the funnel offset and tilt"):
            self._loading = True
            self.origin_lat1.setValue(sp.origin_lat1)
            self.origin_lat2.setValue(sp.origin_lat2)
            self.axis_tilt.setValue(sp.axis_tilt_deg)
            self._loading = False
            return
        sender = self.sender()
        for attr, row in (("origin_lat1", self.origin_lat1),
                          ("origin_lat2", self.origin_lat2),
                          ("axis_tilt_deg", self.axis_tilt),
                          ("axis_azimuth_deg", self.axis_azimuth)):
            if sender is None or sender is row:
                setattr(sp, attr, row.value())
                sp.literals.pop(attr, None)
        if self.w.job.model:
            self.w.job.model.invalidate()
        self.geometryChanged.emit()
        self.changed.emit()

    def _snap_changed(self, text):
        v = 0.0
        if text != "off":
            v = float(text.split()[0])
        self.w.viewer.options.snap = v

    # -- sync in
    def refresh(self):
        try:
            self._refresh_funnel_inner()
        finally:
            self._loading = False

    def _refresh_funnel_inner(self):
        job = self.w.job
        sp = job.spec
        self._loading = True
        degenerate = job.model.funnel_is_degenerate() if job.model else True
        live = sp.funnel_enabled and not degenerate
        self.use_funnel.setChecked(sp.funnel_enabled)
        self.shape_group.setVisible(live)
        self.no_funnel_note.setVisible(not live)
        self.origin_lat1.setValue(sp.origin_lat1)
        self.origin_lat2.setValue(sp.origin_lat2)
        self.axis_tilt.setValue(sp.axis_tilt_deg)
        self.axis_azimuth.setValue(sp.axis_azimuth_deg)
        for row in (self.origin_lat1, self.origin_lat2, self.axis_tilt,
                    self.axis_azimuth):
            row.setEnabled(True)
        m = job.model
        if m is not None:
            lo, hi = m.axis_limits(margin=0.25)
            if hi > lo:
                for row in (self.z_cc, self.z_min, self.z_max):
                    row.setRangeKeepValue(lo, hi)
                self.origin_off.setRangeKeepValue(lo, hi)
            room = m.best_room(margin=0.25)
            if room > 0.2:
                self.r_cyl.setRangeKeepValue(0.1, room)
            for which, row in ((1, self.origin_lat1), (2, self.origin_lat2)):
                a, b = m.lateral_limits(which, margin=0.25)
                if b > a:
                    row.setRangeKeepValue(a, b)
        self.z_cc.setValue(sp.z_cc)
        self.r_cyl.setValue(sp.r_cyl)
        self.cone_deg.setValue(sp.cone_angle_deg)
        self.cone_slope.setValue(sp.cone_slope)
        self.z_min.setValue(sp.z_min)
        self.z_max.setValue(sp.z_max)
        self.origin_frac.setValue(sp.origin_frac)
        self.k_rad.setValue(sp.k_rad)
        self.k_z.setValue(sp.k_z)
        if job.model is not None:
            self.origin_off.setValue(job.model.origin_offset_A)
        self._loading = False
        self.refresh_readouts()

    def refresh_readouts(self):
        job = self.w.job
        sp = job.spec
        self.r_base_lbl.setText(
            f"R_base {sp.r_base():.3f} Å · cone {max(0.0, sp.z_cc - sp.z_min):.2f} Å"
            f" · cylinder {max(0.0, sp.z_max - sp.z_cc):.2f} Å")
        self.stiff.set("r1", f"{0.5 * sp.k_rad:.2f} kcal/mol")
        self.stiff.set("r2", f"{2.0 * sp.k_rad:.2f} kcal/mol")
        self.stiff.set("z1", f"{0.5 * sp.k_z:.2f} kcal/mol")
        self.stiff.set("z2", f"{2.0 * sp.k_z:.2f} kcal/mol")
        m = job.model
        if m is None:
            return
        z0, rho0 = m.cv_of_ligand()
        rall = float(sp.r_allowed(z0))
        v0 = float(sp.wall_potential(z0, rho0))
        self.live.set("z0", f"{z0:+.3f} Å")
        self.live.set("rho0", f"{rho0:.3f} Å")
        self.live.set("rall", f"{rall:.3f} Å")
        self.live.set("v0", f"{v0:.4f} kcal/mol",
                      theme.GOOD if v0 < 1e-6 else theme.BAD)
        self.live.set("axis", f"{m.frame.axis_len:.3f} Å")
        self.live.set("vol", f"{sp.funnel_volume() / 1000.0:.2f} nm³")
        try:
            clear, _ = m.funnel_clearance()
            col = theme.GOOD if clear >= self.w.job.cutoff_radius else theme.WARN
            if clear < 0:
                col = theme.BAD
            self.live.set("clear", f"{clear:.2f} Å", col)
        except Exception:
            self.live.set("clear", "-")
        st = job.structure
        if st is not None:
            mask = st.mask("heavy") & ~st.mask("water")
            n = len(m.atoms_in_funnel(mask))
            self.live.set("nat", f"{n}")


# ==========================================================================
class MetaDPanel(QtWidgets.QWidget):
    """Well-tempered metadynamics parameters and deposition schedule."""

    changed = QtCore.pyqtSignal()

    def __init__(self, window, parent=None):
        super().__init__(parent)
        self.w = window
        self._loading = False

        self.dimension = ComboRow("CV space", ["1-D  (z)", "2-D  (z, ρ)"],
                                  "1-D  (z)",
                                  tip="A second CV widens the bias to the "
                                      "radial coordinate as well.")
        self.h0 = ParamRow("hill height", 0.1, 0.001, 5.0, 0.01, 6,
                           "kcal/mol",
                           tip="Initial Gaussian height h0 before tempering.")
        self.sigma_z = ParamRow("σ z", 0.5, 0.01, 5.0, 0.05, 6, "Å",
                                tip="Kernel width along the axial CV.")
        self.sigma_rho = ParamRow("σ ρ", 0.5, 0.01, 5.0, 0.05, 6, "Å",
                                  tip="Kernel width along the radial CV (2-D "
                                      "only).")
        self.gamma = ParamRow("bias factor γ", 15.0, 1.001, 200.0, 0.5, 6, "",
                              tip="Well-tempered bias factor; kTemp = "
                                  "(γ-1)·kB·T.")
        self.temperature = ParamRow("temperature", 310.0, 1.0, 1000.0, 1.0, 4,
                                    "K",
                                    tip="Must match the .cfg ensemble "
                                        "temperature.")
        self.ktemp = ParamRow("kTemp", 8.624466483, 0.001, 500.0, 0.1, 9,
                              "kcal/mol", slider=False,
                              tip="Tempering energy written to the .pot. Edit "
                                  "γ or T to recompute, or set it directly.")
        self.lock_ktemp = QtWidgets.QCheckBox(
            "Keep kTemp literal exactly as imported")
        self.lock_ktemp.setChecked(True)
        self.lock_ktemp.setToolTip(
            "On: γ and T are shown for information and kTemp keeps its "
            "imported digits.  Off: kTemp is recomputed from γ and T.")

        self.first = ParamRow("first hill", 100.0, 0.0, 1e6, 10.0, 4, "ps",
                              tip="Simulation time before the first Gaussian "
                                  "is deposited.")
        self.interval = ParamRow("hill interval", 2.0, 0.001, 1e4, 0.5, 6, "ps",
                                 tip="Deposition period.")
        self.cutoff = ParamRow("kernel cutoff", 9.0, 1.0, 40.0, 0.5, 4, "σ",
                               tip="declare_meta cutoff: Desmond skips a "
                                   "Gaussian once the normalised distance "
                                   "|Δcv|/σ exceeds this, so it is a "
                                   "truncation in units of kernel width, not "
                                   "an Ångström distance.  Default 9.")
        self.kerseq = TextRow("kernel file", "$JOBNAME.kerseq",
                              tip="declare_meta name = the hill history file.")
        self.initial = TextRow("restart hills", "",
                              placeholder="empty for a fresh start",
                              tip="declare_meta initial = an existing kerseq "
                                  "to continue from.")
        self.cvseq = TextRow("CV file", "$JOBNAME.cvseq")
        self.cv_first = ParamRow("CV first", 0.0, 0.0, 1e6, 10.0, 4, "ps")
        self.cv_interval = ParamRow("CV interval", 1.0, 0.001, 1e4, 0.5, 6, "ps")

        self.dep = Readout([("hills", "hills in run"), ("rate", "hills / ns"),
                            ("erate", "energy rate"), ("dT", "ΔT = (γ-1)T"),
                            ("gimp", "γ from kTemp"), ("res", "CV resolution"),
                            ("trunc", "kernel truncation")])
        self.prints = QtWidgets.QTableWidget(0, 2)
        self.prints.setHorizontalHeaderLabels(["printed label", "variable"])
        self.prints.horizontalHeader().setStretchLastSection(True)
        self.prints.verticalHeader().setVisible(False)
        self.prints.setMaximumHeight(190)
        addp = QtWidgets.QPushButton("Add")
        delp = QtWidgets.QPushButton("Remove")
        defp = QtWidgets.QPushButton("Defaults")
        addp.clicked.connect(self._add_print)
        delp.clicked.connect(self._del_print)
        defp.clicked.connect(self._default_prints)
        prow = QtWidgets.QHBoxLayout()
        prow.addWidget(addp)
        prow.addWidget(delp)
        prow.addWidget(defp)
        prow.addStretch(1)

        inner = vbox(
            group("Collective variables", self.dimension),
            group("Well-tempered bias", self.h0, self.sigma_z, self.sigma_rho,
                  self.gamma, self.temperature, self.ktemp, self.lock_ktemp),
            group("Deposition schedule", self.first, self.interval,
                  self.cutoff, self.kerseq, self.initial),
            group("CV trace output", self.cvseq, self.cv_first,
                  self.cv_interval),
            group("Run summary", self.dep),
            group("print() statements", self.prints, prow),
            None)
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(scroll_area(inner))

        for row in (self.h0, self.sigma_z, self.sigma_rho, self.first,
                    self.interval, self.cutoff, self.cv_first,
                    self.cv_interval):
            row.valueChanged.connect(self._push)
        self.gamma.valueChanged.connect(self._from_gamma)
        self.temperature.valueChanged.connect(self._from_temperature)
        self.ktemp.valueChanged.connect(self._from_ktemp)
        self.dimension.currentChanged.connect(self._from_dimension)
        for tr in (self.kerseq, self.initial, self.cvseq):
            tr.editingFinished.connect(self._push_text)
        self.prints.itemChanged.connect(self._prints_edited)

    # -- out
    def _push(self, *_):
        if self._loading:
            return
        sp = self.w.job.spec
        pairs = (("h0", self.h0), ("sigma_z", self.sigma_z),
                 ("sigma_rho", self.sigma_rho), ("meta_first", self.first),
                 ("meta_interval", self.interval),
                 ("kernel_cutoff", self.cutoff), ("cv_first", self.cv_first),
                 ("cv_interval", self.cv_interval))
        sender = self.sender()
        for attr, row in pairs:
            if sender is not None and sender is not row:
                continue
            v = row.value()
            if getattr(sp, attr) != v:
                setattr(sp, attr, v)
                sp.literals.pop(attr, None)
        self.changed.emit()

    def _push_text(self, *_):
        sp = self.w.job.spec
        sp.kerseq_name = self.kerseq.text()
        sp.initial_kernels = self.initial.text()
        sp.cvseq_name = self.cvseq.text()
        self.changed.emit()

    def _from_gamma(self, g):
        if self._loading:
            return
        sp = self.w.job.spec
        sp.gamma = g
        if not self.lock_ktemp.isChecked():
            sp.sync_ktemp()
            self._loading = True
            self.ktemp.setValue(sp.ktemp)
            self._loading = False
        self.changed.emit()

    def _from_temperature(self, t):
        if self._loading:
            return
        sp = self.w.job.spec
        sp.temperature = t
        if not self.lock_ktemp.isChecked():
            sp.sync_ktemp()
            self._loading = True
            self.ktemp.setValue(sp.ktemp)
            self._loading = False
        self.changed.emit()

    def _from_ktemp(self, v):
        if self._loading:
            return
        sp = self.w.job.spec
        sp.ktemp = v
        sp.literals.pop("ktemp", None)
        sp.gamma = sp.gamma_from_ktemp()
        self._loading = True
        self.gamma.setValue(sp.gamma)
        self._loading = False
        self.changed.emit()

    def _from_dimension(self, text):
        if self._loading:
            return
        sp = self.w.job.spec
        sp.dimension = 2 if text.startswith("2") else 1
        self.sigma_rho.setEnabled(sp.dimension >= 2)
        self.changed.emit()

    def _add_print(self):
        sp = self.w.job.spec
        sp.prints.append(("new_label", sp.available_print_vars()[0]))
        self.refresh_prints()
        self.changed.emit()

    def _del_print(self):
        r = self.prints.currentRow()
        sp = self.w.job.spec
        if 0 <= r < len(sp.prints):
            sp.prints.pop(r)
            self.refresh_prints()
            self.changed.emit()

    def _default_prints(self):
        sp = self.w.job.spec
        base = [p for p in DEFAULT_PRINTS if p[1] != "v_total"]
        diag = [(d.print_label, d.dist_var) for d in sp.diagnostics]
        sp.prints = base + diag + [("total_bias_kcalmol", "v_total")]
        self.refresh_prints()
        self.changed.emit()

    def _prints_edited(self, item):
        if self._loading:
            return
        sp = self.w.job.spec
        r = item.row()
        if r >= len(sp.prints):
            return
        label, var = sp.prints[r]
        if item.column() == 0:
            label = item.text().strip()
        sp.prints[r] = (label, var)
        self.changed.emit()

    def _print_var_changed(self, row, var):
        sp = self.w.job.spec
        if row < len(sp.prints):
            sp.prints[row] = (sp.prints[row][0], var)
            self.changed.emit()

    # -- in
    def refresh(self):
        sp = self.w.job.spec
        self._loading = True
        self.dimension.setCurrentText("2-D  (z, ρ)" if sp.dimension >= 2
                                      else "1-D  (z)")
        self.h0.setValue(sp.h0)
        self.sigma_z.setValue(sp.sigma_z)
        self.sigma_rho.setValue(sp.sigma_rho)
        self.sigma_rho.setEnabled(sp.dimension >= 2)
        self.gamma.setValue(sp.gamma)
        self.temperature.setValue(sp.temperature)
        self.ktemp.setValue(sp.ktemp)
        self.first.setValue(sp.meta_first)
        self.interval.setValue(sp.meta_interval)
        self.cutoff.setValue(sp.kernel_cutoff)
        self.kerseq.setText(sp.kerseq_name)
        self.initial.setText(sp.initial_kernels)
        self.cvseq.setText(sp.cvseq_name)
        self.cv_first.setValue(sp.cv_first)
        self.cv_interval.setValue(sp.cv_interval)
        self._loading = False
        self.refresh_prints()
        self.refresh_readouts()

    def refresh_prints(self):
        sp = self.w.job.spec
        self._loading = True
        self.prints.setRowCount(len(sp.prints))
        for r, (label, var) in enumerate(sp.prints):
            it = QtWidgets.QTableWidgetItem(label)
            self.prints.setItem(r, 0, it)
            combo = QtWidgets.QComboBox()
            combo.addItems(sp.available_print_vars())
            if var not in sp.available_print_vars():
                combo.addItem(var)
            combo.setCurrentText(var)
            combo.currentTextChanged.connect(
                lambda t, row=r: self._print_var_changed(row, t))
            self.prints.setCellWidget(r, 1, combo)
        self._loading = False

    def refresh_readouts(self):
        sp = self.w.job.spec
        total = self.w.job.production_ps or 0.0
        n = sp.hills_for_time(total)
        self.dep.set("hills", f"{n:,}")
        self.dep.set("rate", f"{1000.0 / sp.meta_interval:.1f}"
                     if sp.meta_interval > 0 else "-")
        self.dep.set("erate", f"{sp.h0 * 1000.0 / sp.meta_interval:.2f} "
                     "kcal/mol/ns" if sp.meta_interval > 0 else "-")
        self.dep.set("dT", f"{(sp.gamma - 1) * sp.temperature:,.0f} K")
        g = sp.gamma_from_ktemp()
        col = theme.GOOD if abs(g - sp.gamma) < 1e-3 else theme.WARN
        self.dep.set("gimp", f"{g:.6f}", col)
        span = sp.z_max - sp.z_min
        self.dep.set("res", f"{span / sp.sigma_z:.0f} σ over {span:.1f} Å"
                     if sp.sigma_z > 0 else "-")
        self.dep.set("trunc", f"{sp.kernel_cutoff * sp.sigma_z:.2f} Å "
                     f"({sp.kernel_cutoff:g} σ)")


# ==========================================================================
class SelectionEditor(QtWidgets.QGroupBox):
    """Editor for one atom group: indices, expression, 3-D picking."""

    changed = QtCore.pyqtSignal()
    pickRequested = QtCore.pyqtSignal(object)      # self
    residueChosen = QtCore.pyqtSignal(str, int)

    def __init__(self, title: str, window, getter, tip: str = "", parent=None):
        super().__init__(title, parent)
        self.w = window
        self.getter = getter
        self._loading = False

        self.info = QtWidgets.QLabel("-")
        self.info.setProperty("dim", "true")
        self.info.setWordWrap(True)
        self.expr = QtWidgets.QLineEdit()
        self.expr.setPlaceholderText(
            "e.g.  chain B and resname LIG and heavy")
        self.expr.setToolTip(
            "Selection language: chain / resname / resnum / name / element / "
            "index / heavy / hydrogen / backbone / sidechain / protein / "
            "water / ion / hetero / ca / within <r> of <sel>, combined with "
            "and, or, not and parentheses.")
        apply_btn = QtWidgets.QPushButton("Apply")
        apply_btn.setProperty("accent", "true")
        apply_btn.clicked.connect(self._apply_expr)
        self.pick = QtWidgets.QToolButton()
        self.pick.setText("Pick in 3-D")
        self.pick.setCheckable(True)
        self.pick.setToolTip("Click atoms in the 3-D view to add or remove "
                             "them from this group.")
        self.pick.toggled.connect(lambda on: self.pickRequested.emit(self))
        self.whole_res = QtWidgets.QCheckBox("whole residue")
        self.whole_res.setToolTip(
            "A click takes every heavy atom of the residue instead of the one "
            "atom under the cursor.")
        self.replace_btn = QtWidgets.QToolButton()
        self.replace_btn.setText("Set from clicked residue")
        self.replace_btn.setCheckable(True)
        self.replace_btn.setToolTip(
            "Arm a single click: the next residue you click in the 3-D view "
            "replaces this group with its heavy atoms. This is the direct way "
            "to say \"this one is my ligand\".")
        self.replace_btn.toggled.connect(
            lambda on: self.pickRequested.emit(self) if on else None)
        erow = QtWidgets.QHBoxLayout()
        erow.addWidget(self.expr, 1)
        erow.addWidget(apply_btn)
        erow.addWidget(self.pick)
        prow = QtWidgets.QHBoxLayout()
        prow.addWidget(self.whole_res)
        prow.addWidget(self.replace_btn)
        prow.addStretch(1)

        self.indices = QtWidgets.QPlainTextEdit()
        self.indices.setMaximumHeight(66)
        self.indices.setFont(QtGui.QFont("DejaVu Sans Mono", 9))
        self.indices.setToolTip("1-based atom indices exactly as they go into "
                                "atomsel(\"atom. ...\").")
        commit = QtWidgets.QPushButton("Set from list")
        commit.clicked.connect(self._apply_indices)
        clear = QtWidgets.QPushButton("Clear")
        clear.clicked.connect(self._clear)
        bb_btn = QtWidgets.QPushButton("Backbone of these residues")
        bb_btn.setToolTip("Replace the group with the N/CA/C/O atoms of every "
                          "residue it currently touches.")
        bb_btn.clicked.connect(self._backbone_of)
        irow = QtWidgets.QHBoxLayout()
        irow.addWidget(commit)
        irow.addWidget(bb_btn)
        irow.addWidget(clear)
        irow.addStretch(1)

        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(8, 4, 8, 6)
        lay.setSpacing(4)
        if tip:
            hint = QtWidgets.QLabel(tip)
            hint.setProperty("dim", "true")
            hint.setWordWrap(True)
            lay.addWidget(hint)
        lay.addWidget(self.info)
        lay.addLayout(erow)
        lay.addLayout(prow)
        lay.addWidget(self.indices)
        lay.addLayout(irow)

    # -- helpers
    def selection(self) -> Selection:
        return self.getter()

    def _apply_expr(self):
        st = self.w.job.structure
        if st is None:
            return
        try:
            idx = parse_selection(self.expr.text(), st)
        except SelectionError as exc:
            QtWidgets.QMessageBox.warning(self, "Selection", str(exc))
            return
        if len(idx) == 0:
            QtWidgets.QMessageBox.information(
                self, "Selection", "That expression matches no atoms.")
            return
        sel = self.selection()
        sel.indices = sorted(int(i) + 1 for i in idx)
        sel.expression = self.expr.text()
        self.refresh()
        self.changed.emit()

    def _apply_indices(self):
        text = self.indices.toPlainText()
        out: list[int] = []
        for part in text.replace(",", " ").split():
            if "-" in part[1:]:
                a, _, b = part.partition("-")
                try:
                    out.extend(range(int(a), int(b) + 1))
                except ValueError:
                    pass
            else:
                try:
                    out.append(int(part))
                except ValueError:
                    pass
        st = self.w.job.structure
        if st is not None:
            bad = [i for i in out if i < 1 or i > st.n_atoms]
            if bad:
                QtWidgets.QMessageBox.warning(
                    self, "Selection",
                    f"{len(bad)} index/indices out of range 1..{st.n_atoms} "
                    f"(first: {bad[0]}).")
                return
        sel = self.selection()
        sel.indices = sorted(set(out))
        self.refresh()
        self.changed.emit()

    def _clear(self):
        self.selection().indices = []
        self.refresh()
        self.changed.emit()

    def _backbone_of(self):
        st = self.w.job.structure
        sel = self.selection()
        if st is None or not sel.indices:
            return
        out: set[int] = set()
        for i in sel.idx0():
            r = st.residue_of_atom(int(i))
            if r is None:
                continue
            for k in range(r.first, r.last):
                if str(st.atomname[k]) in elements.BACKBONE_HEAVY:
                    out.add(k + 1)
        sel.indices = sorted(out)
        self.refresh()
        self.changed.emit()

    def toggle_atom(self, index1: int):
        """Apply a 3-D click: one atom, a whole residue, or a replacement."""
        st = self.w.job.structure
        sel = self.selection()
        replacing = self.replace_btn.isChecked()
        whole = replacing or self.whole_res.isChecked()
        atoms = [index1]
        if whole and st is not None:
            from ..core.autobuild import residue_heavy_atoms
            atoms = residue_heavy_atoms(st, index1) or [index1]
        if replacing:
            sel.indices = sorted(atoms)
            sel.expression = ""
            self.replace_btn.setChecked(False)
            if st is not None:
                r = st.residue_of_atom(index1 - 1)
                if r is not None:
                    self.residueChosen.emit(r.long_label, len(atoms))
        elif set(atoms).issubset(set(sel.indices)):
            sel.indices = sorted(set(sel.indices) - set(atoms))
        else:
            sel.indices = sorted(set(sel.indices) | set(atoms))
        self.refresh()
        self.changed.emit()

    def refresh(self):
        sel = self.selection()
        st = self.w.job.structure
        self.indices.blockSignals(True)
        self.indices.setPlainText(",".join(str(i) for i in sel.indices))
        self.indices.blockSignals(False)
        if st is None:
            self.info.setText(f"{sel.n} atoms")
            return
        desc = describe_indices(st, sel.idx0())
        com = st.center_of_mass(sel.idx0()) if sel.n else np.zeros(3)
        self.info.setText(
            f"<b>{sel.n}</b> atoms · {desc}<br>"
            f"COM  {com[0]:+.3f}  {com[1]:+.3f}  {com[2]:+.3f} Å")
        if sel.expression:
            self.expr.setText(sel.expression)


# ==========================================================================
class GroupsPanel(QtWidgets.QWidget):
    """The three CV groups plus the reported diagnostic distances."""

    changed = QtCore.pyqtSignal()
    suggestRequested = QtCore.pyqtSignal()

    def __init__(self, window, parent=None):
        super().__init__(parent)
        self.w = window
        job = window.job
        self.lig = SelectionEditor(
            "Ligand  ·  lig", window, lambda: self.w.job.spec.lig,
            "Heavy atoms whose centre of mass is the biased particle. "
            "Clicking any atom of a ligand in the 3-D view takes the whole "
            "residue.")
        self.lig.whole_res.setChecked(True)
        self.site = SelectionEditor(
            "Pocket frame  ·  site", window, lambda: self.w.job.spec.site,
            "Backbone atoms at the binding site; with CORE they define the "
            "funnel axis direction.")
        self.core = SelectionEditor(
            "Body frame  ·  core", window, lambda: self.w.job.spec.core,
            "Backbone atoms deep in the protein body; the axis starts here.")

        self.diag = QtWidgets.QTableWidget(0, 4)
        self.diag.setHorizontalHeaderLabels(
            ["label", "variable", "atoms", "distance Å"])
        self.diag.horizontalHeader().setStretchLastSection(True)
        self.diag.verticalHeader().setVisible(False)
        self.diag.setMaximumHeight(170)
        add = QtWidgets.QPushButton("Add")
        add.setProperty("accent", "true")
        add.clicked.connect(self._add_diag)
        rem = QtWidgets.QPushButton("Remove")
        rem.clicked.connect(self._del_diag)
        self.diag_expr = QtWidgets.QLineEdit()
        self.diag_expr.setPlaceholderText(
            "114    ·    Tyr114    ·    A:114    ·    114:OH    ·    "
            "114, 197, 442")
        self.diag_expr.returnPressed.connect(self._add_diag)
        self.diag_pick = QtWidgets.QToolButton()
        self.diag_pick.setText("Pick in 3-D")
        self.diag_pick.setCheckable(True)
        self.diag_pick.setToolTip(
            "Click an atom in the 3-D view to add its residue as a reported "
            "distance.")
        self.diag_pick.toggled.connect(self._diag_pick_toggled)
        self.diag_atomwise = QtWidgets.QCheckBox("just the clicked atom")
        self.diag_atomwise.setToolTip(
            "Off: the whole residue is used, which is the usual choice for a "
            "centre-of-mass distance. On: only the atom you name or click.")
        drow = QtWidgets.QHBoxLayout()
        drow.addWidget(self.diag_expr, 1)
        drow.addWidget(add)
        drow.addWidget(rem)
        drow2 = QtWidgets.QHBoxLayout()
        drow2.addWidget(self.diag_pick)
        drow2.addWidget(self.diag_atomwise)
        drow2.addStretch(1)
        diag_help = QtWidgets.QLabel(
            "Type a residue number and press Enter. Give an atom name after a "
            "colon to use just that atom (<code>114:OH</code>); without one "
            "the whole residue's heavy atoms are used. Several at once: "
            "<code>114, 197, 442</code>. Full selection expressions still "
            "work.")
        diag_help.setWordWrap(True)
        diag_help.setProperty("dim", "true")

        self.ligand_label = TextRow("ligand tag", "LIG",
                                    tip="Short name used in the potential "
                                        "file comments.")
        self.ligand_label.editingFinished.connect(self._label_changed)
        self.suggest = QtWidgets.QPushButton("Suggest groups from the structure")
        self.suggest.setToolTip(
            "Pick the largest hetero residue as the ligand, the nearest "
            "pocket backbone as SITE and the deepest body backbone as CORE. "
            "Use this when starting a funnel for a new system.")
        self.suggest.clicked.connect(self.suggestRequested.emit)

        inner = vbox(self.lig, self.site, self.core,
                     group("Reported diagnostics (not biased)", diag_help,
                           self.diag, drow, drow2),
                     group("Annotation", self.ligand_label, self.suggest),
                     None)
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(scroll_area(inner))

        for ed in (self.lig, self.site, self.core):
            ed.changed.connect(self.changed.emit)
            ed.pickRequested.connect(self._pick_requested)
            ed.residueChosen.connect(
                lambda label, n, e=ed: self.w.statusBar().showMessage(
                    f"{e.title()}: {label} ({n} heavy atoms)", 6000))
        self.diag.itemChanged.connect(self._diag_edited)
        self._active_pick: SelectionEditor | None = None

    def _pick_requested(self, editor):
        for ed in (self.lig, self.site, self.core):
            if ed is not editor:
                for btn in (ed.pick, ed.replace_btn):
                    btn.blockSignals(True)
                    btn.setChecked(False)
                    btn.blockSignals(False)
        armed = editor.pick.isChecked() or editor.replace_btn.isChecked()
        self._active_pick = editor if armed else None
        self.w.set_pick_mode(self._active_pick is not None)

    def handle_pick(self, index1: int):
        if self.diag_pick.isChecked():
            st = self.w.job.structure
            if st is not None:
                from ..core.autobuild import residue_heavy_atoms
                r = st.residue_of_atom(index1 - 1)
                if self.diag_atomwise.isChecked():
                    label = (f"{r.resname.strip().capitalize()}{r.resnum}_"
                             f"{st.atomname[index1 - 1]}" if r else "Probe")
                    self._add_diag_group(label, [index1])
                else:
                    atoms = residue_heavy_atoms(st, index1) or [index1]
                    label = (f"{r.resname.strip().capitalize()}{r.resnum}"
                             if r else "Probe")
                    self._add_diag_group(label, atoms)
                self.refresh()
                self.changed.emit()
            return
        if self._active_pick is None:
            return
        ed = self._active_pick
        ed.toggle_atom(index1)
        if not (ed.pick.isChecked() or ed.replace_btn.isChecked()):
            self._active_pick = None
            self.w.set_pick_mode(False)

    def _label_changed(self, text):
        self.w.job.spec.ligand_label = text.strip() or "LIG"
        self.changed.emit()

    def _diag_pick_toggled(self, on: bool):
        if on:
            for ed in (self.lig, self.site, self.core):
                for btn in (ed.pick, ed.replace_btn):
                    btn.blockSignals(True)
                    btn.setChecked(False)
                    btn.blockSignals(False)
            self._active_pick = None
        self.w.set_pick_mode(on or self._active_pick is not None)

    def _add_diag_group(self, label: str, indices) -> None:
        from ..core.funnel import make_diagnostic
        sp = self.w.job.spec
        d = make_diagnostic(sp, label, indices)
        sp.diagnostics.append(d)
        sp.prints.insert(max(0, len(sp.prints) - 1),
                         (d.print_label, d.dist_var))

    def _add_diag(self):
        """Add one reported distance per residue the user named."""
        st = self.w.job.structure
        if st is None:
            return
        text = self.diag_expr.text().strip()
        if not text:
            return
        from ..core.asl import (parse_residue_shorthand, looks_like_shorthand,
                                SelectionError as SErr)
        added = 0
        try:
            if looks_like_shorthand(text):
                for g in parse_residue_shorthand(text, st):
                    self._add_diag_group(g["label"], g["indices"])
                    added += 1
            else:
                idx = parse_selection(text, st)
                if len(idx) == 0:
                    QtWidgets.QMessageBox.information(
                        self, "Diagnostics", "That matches no atoms.")
                    return
                names = st.residue_signature(idx)
                label = names[0] if len(names) == 1 else "Probe"
                self._add_diag_group(label,
                                     [int(i) + 1 for i in idx])
                added = 1
        except SErr as exc:
            QtWidgets.QMessageBox.warning(self, "Diagnostics", str(exc))
            return
        self.diag_expr.clear()
        self.refresh()
        self.changed.emit()
        if added:
            sp = self.w.job.spec
            last = sp.diagnostics[-1]
            self.w.statusBar().showMessage(
                f"added {added} reported distance(s); last: {last.label} "
                f"({len(last.indices)} atoms, printed as "
                f"{last.print_label})", 7000)

    def _del_diag(self):
        r = self.diag.currentRow()
        sp = self.w.job.spec
        if 0 <= r < len(sp.diagnostics):
            d = sp.diagnostics.pop(r)
            sp.prints = [p for p in sp.prints if p[1] != d.dist_var]
            self.refresh()
            self.changed.emit()

    def _diag_edited(self, item):
        sp = self.w.job.spec
        r = item.row()
        if r >= len(sp.diagnostics):
            return
        d = sp.diagnostics[r]
        old = d.print_label
        if item.column() == 0:
            d.label = item.text().strip() or d.label
        elif item.column() == 1:
            d.var = item.text().strip() or d.var
            d.dist_var = "d_" + d.var
        elif item.column() == 2:
            st = self.w.job.structure
            out = []
            for part in item.text().replace(",", " ").split():
                try:
                    out.append(int(part))
                except ValueError:
                    pass
            if st is not None:
                out = [i for i in out if 1 <= i <= st.n_atoms]
            if out:
                d.indices = sorted(set(out))
            self.refresh()
        sp.prints = [(d.print_label if lbl == old else lbl, var)
                     for lbl, var in sp.prints]
        self.changed.emit()

    def refresh(self):
        for ed in (self.lig, self.site, self.core):
            ed.refresh()
        self.ligand_label.setText(self.w.job.spec.ligand_label)
        sp = self.w.job.spec
        m = self.w.job.model
        dists = dict(m.diagnostic_distances()) if m else {}
        self.diag.blockSignals(True)
        self.diag.setRowCount(len(sp.diagnostics))
        for r, d in enumerate(sp.diagnostics):
            self.diag.setItem(r, 0, QtWidgets.QTableWidgetItem(d.label))
            self.diag.setItem(r, 1, QtWidgets.QTableWidgetItem(d.var))
            it = QtWidgets.QTableWidgetItem(
                ",".join(str(i) for i in d.indices))
            self.diag.setItem(r, 2, it)
            v = dists.get(d.label, float("nan"))
            it2 = QtWidgets.QTableWidgetItem(f"{v:.3f}")
            it2.setFlags(it2.flags() & ~QtCore.Qt.ItemIsEditable)
            self.diag.setItem(r, 3, it2)
        self.diag.blockSignals(False)
