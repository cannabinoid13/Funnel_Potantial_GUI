"""Panels for the job files, the validation report, the view and the export."""

from __future__ import annotations

import difflib
import os

from PyQt5 import QtCore, QtGui, QtWidgets

from ..core.jobfiles import CMS_COPY, CMS_HARDLINK, CMS_SYMLINK, CMS_SKIP
from . import theme
from .widgets import (ParamRow, IntRow, TextRow, ComboRow, Readout, IssueTable,
                      group, vbox, hline, scroll_area)
from .reps import REPRESENTATIONS, COLOR_MODES
from .viewer import GROUPS

CMS_MODES = {"copy the .cms": CMS_COPY, "hard-link the .cms": CMS_HARDLINK,
             "symlink the .cms": CMS_SYMLINK, "leave the .cms alone": CMS_SKIP}


# ==========================================================================
class JobPanel(QtWidgets.QWidget):
    """Job name, .cfg settings, .msj stages, .sh launcher and export."""

    changed = QtCore.pyqtSignal()
    exportRequested = QtCore.pyqtSignal()

    def __init__(self, window, parent=None):
        super().__init__(parent)
        self.w = window
        self._loading = False

        self.jobname = TextRow("job name", "",
                               tip="All five files are written as "
                                   "<job name>.pot/.msj/.cfg/.sh/.cms and "
                                   "$JOBNAME inside the potential resolves to "
                                   "it.")
        self.jobname.editingFinished.connect(self._jobname_changed)

        # -- cfg
        self.time_ns = ParamRow("production", 500.0, 0.001, 100000.0, 10.0, 4,
                                "ns", tip="Desmond .cfg time, shown in ns.")
        self.temperature = ParamRow("temperature", 310.0, 1.0, 1000.0, 1.0, 3,
                                    "K",
                                    tip="Ensemble temperature; kept in step "
                                        "with the well-tempered kTemp.")
        self.cutoff = ParamRow("cutoff", 9.0, 4.0, 20.0, 0.5, 3, "Å")
        self.traj = ParamRow("trajectory", 20.0, 0.1, 10000.0, 1.0, 3, "ps")
        self.ene = ParamRow("energy log", 2.0, 0.1, 10000.0, 1.0, 3, "ps")
        self.ckpt = ParamRow("checkpoint", 500.0, 1.0, 100000.0, 50.0, 3, "ps")
        self.maeff = ParamRow("structure out", 1000.0, 1.0, 100000.0, 100.0, 3,
                              "ps")
        self.dt = ParamRow("inner timestep", 2.0, 0.1, 5.0, 0.1, 4, "fs")
        self.ens_class = ComboRow("ensemble", ["NPT", "NVT"], "NPT")
        self.ens_method = ComboRow("integrator", ["MTK", "Langevin", "NH",
                                                 "Berendsen"], "MTK")
        self.tau_t = ParamRow("thermostat τ", 1.0, 0.01, 100.0, 0.1, 3, "ps")
        self.tau_p = ParamRow("barostat τ", 2.0, 0.01, 100.0, 0.1, 3, "ps")
        self.seed = IntRow("velocity seed", 114197, 1, 2 ** 31 - 1)
        self.cfg_info = Readout([("frames", "trajectory frames"),
                                 ("cvrec", "CV records"),
                                 ("hills", "hills deposited"),
                                 ("steps", "MD steps")], columns=2)

        # -- msj
        self.stages = QtWidgets.QTableWidget(0, 4)
        self.stages.setHorizontalHeaderLabels(["#", "stage", "title", "ps"])
        self.stages.horizontalHeader().setStretchLastSection(False)
        self.stages.horizontalHeader().setSectionResizeMode(
            2, QtWidgets.QHeaderView.Stretch)
        self.stages.verticalHeader().setVisible(False)
        self.stages.setColumnWidth(0, 28)
        self.stages.setColumnWidth(1, 74)
        self.stages.setColumnWidth(3, 78)
        self.stages.setMinimumHeight(190)
        self.msj_info = QtWidgets.QLabel("-")
        self.msj_info.setProperty("dim", "true")
        self.msj_info.setWordWrap(True)

        # -- sh
        self.host = TextRow("host", "localhost")
        self.cpu = TextRow("cpu", "1", tip="multisim -cpu")
        self.maxjob = TextRow("maxjob", "1")
        self.mode = TextRow("mode", "umbrella", tip="multisim -mode")
        self.lic = TextRow("license", "DESMOND_GPGPU:16")
        self.desc = TextRow("description", "")
        for tr in (self.host, self.cpu, self.maxjob, self.mode, self.lic,
                   self.desc):
            tr.editingFinished.connect(self._sh_changed)

        # -- export
        self.outdir = QtWidgets.QLineEdit()
        browse = QtWidgets.QPushButton("…")
        browse.setMaximumWidth(34)
        browse.clicked.connect(self._browse)
        orow = QtWidgets.QHBoxLayout()
        orow.addWidget(QtWidgets.QLabel("folder"))
        orow.addWidget(self.outdir, 1)
        orow.addWidget(browse)
        self.cms_mode = ComboRow("structure", list(CMS_MODES.keys()),
                                 "hard-link the .cms",
                                 tip="How the 50 MB .cms gets next to the job "
                                     "files.")
        self.wr_pot = QtWidgets.QCheckBox(".pot")
        self.wr_msj = QtWidgets.QCheckBox(".msj")
        self.wr_cfg = QtWidgets.QCheckBox(".cfg")
        self.wr_sh = QtWidgets.QCheckBox(".sh")
        for c in (self.wr_pot, self.wr_msj, self.wr_cfg, self.wr_sh):
            c.setChecked(True)
        wrow = QtWidgets.QHBoxLayout()
        wrow.addWidget(QtWidgets.QLabel("write"))
        for c in (self.wr_pot, self.wr_msj, self.wr_cfg, self.wr_sh):
            wrow.addWidget(c)
        wrow.addStretch(1)
        self.sync_box = QtWidgets.QCheckBox(
            "Rewrite meta_file / cfg_file / JOBNAME so the set is consistent")
        self.sync_box.setChecked(True)
        exp = QtWidgets.QPushButton("Export ready-to-run job set")
        exp.setProperty("accent", "true")
        exp.setMinimumHeight(30)
        exp.clicked.connect(self.exportRequested.emit)

        inner = vbox(
            group("Job", self.jobname),
            group("Desmond configuration  ·  .cfg", self.time_ns,
                  self.temperature, self.cutoff, self.dt, self.ens_class,
                  self.ens_method, self.tau_t, self.tau_p, hline(),
                  self.traj, self.ene, self.ckpt, self.maeff, self.seed,
                  hline(), self.cfg_info),
            group("Multisim stages  ·  .msj", self.stages, self.msj_info),
            group("Launcher  ·  .sh", self.host, self.cpu, self.maxjob,
                  self.mode, self.lic, self.desc),
            group("Export", orow, self.cms_mode, wrow, self.sync_box, exp),
            None)
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(scroll_area(inner))

        for row in (self.time_ns, self.cutoff, self.traj, self.ene, self.ckpt,
                    self.maeff, self.dt, self.tau_t, self.tau_p):
            row.valueChanged.connect(self._cfg_changed)
        self.temperature.valueChanged.connect(self._temperature_changed)
        self.seed.valueChanged.connect(self._cfg_changed)
        self.ens_class.currentChanged.connect(self._cfg_changed)
        self.ens_method.currentChanged.connect(self._cfg_changed)
        self.stages.itemChanged.connect(self._stage_edited)

    # -- handlers
    def _jobname_changed(self, text):
        name = text.strip()
        if not name:
            return
        if name == self.w.job.jobname:
            return
        # Renaming the job renames every cross-reference at once, so the
        # stage chain and the launcher never sit in a broken intermediate
        # state: meta_file, cfg_file and JOBNAME all follow.
        changed = self.w.job.sync_files(name)
        self._refresh_stages()
        if changed:
            self.w.statusBar().showMessage(
                "updated " + ", ".join(changed), 5000)
        self.changed.emit()

    def _cfg_changed(self, *_):
        if self._loading:
            return
        cfg = self.w.job.cfg
        if cfg is None:
            return
        cfg.set_number("time", self.time_ns.value() * 1000.0)
        cfg.set_number("cutoff_radius", self.cutoff.value())
        cfg.set_number("trajectory.interval", self.traj.value())
        cfg.set_number("eneseq.interval", self.ene.value())
        cfg.set_number("checkpt.interval", self.ckpt.value())
        cfg.set_number("maeff_output.interval", self.maeff.value())
        cfg.set_number("ensemble.thermostat.tau", self.tau_t.value())
        cfg.set_number("ensemble.barostat.tau", self.tau_p.value())
        cfg.set_number("randomize_velocity.seed", self.seed.value(),
                       integer=True)
        cfg.set_raw("ensemble.class", self.ens_class.currentText())
        cfg.set_raw("ensemble.method", self.ens_method.currentText())
        dt = self.dt.value() / 1000.0
        cfg.set_timestep(dt, dt, dt * 3.0)
        self.changed.emit()

    def _temperature_changed(self, value):
        if self._loading:
            return
        job = self.w.job
        if job.cfg is not None:
            job.cfg.set_temperature(value)
        job.spec.temperature = value
        self.w.metad.refresh()
        self.changed.emit()

    def _stage_edited(self, item):
        if self._loading or item.column() != 3:
            return
        job = self.w.job
        if job.msj is None:
            return
        r = item.row()
        stages = job.msj.stages
        if r >= len(stages):
            return
        try:
            ps = float(item.text())
        except ValueError:
            return
        job.msj.set_stage_time(stages[r], ps)
        self.changed.emit()

    def _sh_changed(self, *_):
        sh = self.w.job.sh
        if sh is None:
            return
        sh.host = self.host.text()
        sh.cpu = self.cpu.text()
        sh.maxjob = self.maxjob.text()
        sh.mode = self.mode.text()
        sh.lic = self.lic.text()
        sh.description = self.desc.text()
        self.changed.emit()

    def _browse(self):
        d = QtWidgets.QFileDialog.getExistingDirectory(
            self, "Export folder", self.outdir.text() or os.path.expanduser("~"))
        if d:
            self.outdir.setText(d)

    # -- api
    def export_options(self):
        return dict(
            outdir=self.outdir.text().strip(),
            jobname=self.jobname.text().strip(),
            cms_mode=CMS_MODES.get(self.cms_mode.currentText(), CMS_COPY),
            write=(self.wr_pot.isChecked(), self.wr_msj.isChecked(),
                   self.wr_cfg.isChecked(), self.wr_sh.isChecked()),
            sync=self.sync_box.isChecked())

    def refresh(self):
        job = self.w.job
        self._loading = True
        self.jobname.setText(job.jobname)
        if (not self.outdir.text()
                or self.outdir.text() == getattr(self, "_default_export_dir", None)):
            base = (getattr(job.paths, "archive_path", "")
                    or job.paths.pot or job.paths.cms or job.paths.cfg)
            if base:
                self._default_export_dir = os.path.join(
                    os.path.dirname(os.path.abspath(base)), job.jobname + "_export")
                self.outdir.setText(self._default_export_dir)
        cfg = job.cfg
        if cfg is not None:
            t = cfg.number("time")
            if t:
                self.time_ns.setValue(t / 1000.0)
            T = cfg.temperature()
            if T:
                self.temperature.setValue(T)
            for path, row in (("cutoff_radius", self.cutoff),
                              ("trajectory.interval", self.traj),
                              ("eneseq.interval", self.ene),
                              ("checkpt.interval", self.ckpt),
                              ("maeff_output.interval", self.maeff),
                              ("ensemble.thermostat.tau", self.tau_t),
                              ("ensemble.barostat.tau", self.tau_p)):
                v = cfg.number(path)
                if v is not None:
                    row.setValue(v)
            ts = cfg.timestep()
            if ts:
                self.dt.setValue(ts[0] * 1000.0)
            self.ens_class.setCurrentText(str(cfg.value("ensemble.class",
                                                        "NPT")))
            self.ens_method.setCurrentText(str(cfg.value("ensemble.method",
                                                         "MTK")))
            s = cfg.number("randomize_velocity.seed")
            if s:
                self.seed.setValue(int(s))
        sh = job.sh
        if sh is not None:
            self.host.setText(sh.host)
            self.cpu.setText(sh.cpu)
            self.maxjob.setText(sh.maxjob)
            self.mode.setText(sh.mode)
            self.lic.setText(sh.lic)
            self.desc.setText(sh.description)
        self._refresh_stages()
        self._loading = False
        self.refresh_readouts()

    def _refresh_stages(self):
        job = self.w.job
        self.stages.setRowCount(0)
        if job.msj is None:
            return
        stages = job.msj.stages
        self.stages.setRowCount(len(stages))
        prod = job.msj.production
        for r, s in enumerate(stages):
            for c, text in ((0, str(r + 1)), (1, s.name),
                            (2, s.title or "-")):
                it = QtWidgets.QTableWidgetItem(text)
                it.setFlags(it.flags() & ~QtCore.Qt.ItemIsEditable)
                if s is prod:
                    it.setForeground(QtGui.QColor(theme.ACCENT))
                self.stages.setItem(r, c, it)
            it = QtWidgets.QTableWidgetItem(
                "" if s.time_ps is None else f"{s.time_ps:g}")
            if s is prod:
                it.setForeground(QtGui.QColor(theme.ACCENT))
            self.stages.setItem(r, 3, it)
        if prod is not None:
            self.msj_info.setText(
                f"Production stage: <b>{prod.title}</b><br>"
                f"meta = {prod.meta_mode or '—'} · meta_file = "
                f"{os.path.basename(prod.meta_file) or '—'} · cfg_file = "
                f"{os.path.basename(prod.cfg_file) or '—'}<br>"
                f"Pre-production: "
                f"{sum(s.time_ps or 0 for s in stages if s is not prod):g} ps "
                f"over {len([s for s in stages if s.name == 'simulate']) - 1} "
                "stages")

    def refresh_readouts(self):
        job = self.w.job
        sp = job.spec
        t = job.production_ps or 0.0
        cfg = job.cfg
        ti = cfg.number("trajectory.interval") if cfg else None
        self.cfg_info.set("frames", f"{t / ti:,.0f}" if ti else "-")
        self.cfg_info.set("cvrec", f"{t / sp.cv_interval:,.0f}"
                          if sp.cv_interval > 0 else "-")
        self.cfg_info.set("hills", f"{sp.hills_for_time(t):,}")
        ts = cfg.timestep() if cfg else []
        if ts and ts[0] > 0:
            self.cfg_info.set("steps", f"{t / ts[0]:,.0f}")
        else:
            self.cfg_info.set("steps", "-")


# ==========================================================================
class ValidatePanel(QtWidgets.QWidget):
    """The consistency report plus the export-time verification."""

    recheckRequested = QtCore.pyqtSignal()
    verifyRequested = QtCore.pyqtSignal()

    def __init__(self, window, parent=None):
        super().__init__(parent)
        self.w = window
        self.table = IssueTable()
        self.summary = QtWidgets.QLabel("-")
        self.summary.setWordWrap(True)
        recheck = QtWidgets.QPushButton("Re-check everything")
        recheck.clicked.connect(self.recheckRequested.emit)
        verify = QtWidgets.QPushButton("Verify potential numerically")
        verify.setProperty("accent", "true")
        verify.setToolTip("Write the potential to memory, re-read it with an "
                          "independent M-expression evaluator and compare "
                          "every CV and energy against this interface.")
        verify.clicked.connect(self.verifyRequested.emit)
        row = QtWidgets.QHBoxLayout()
        row.addWidget(recheck)
        row.addWidget(verify)
        row.addStretch(1)
        self.verify_out = QtWidgets.QPlainTextEdit()
        self.verify_out.setReadOnly(True)
        self.verify_out.setMaximumHeight(190)
        self.verify_out.setFont(QtGui.QFont("DejaVu Sans Mono", 9))
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(8, 6, 8, 6)
        lay.setSpacing(6)
        lay.addWidget(self.summary)
        lay.addLayout(row)
        lay.addWidget(self.table, 1)
        lay.addWidget(self.verify_out)

    def set_issues(self, issues):
        self.table.set_issues(issues)
        n_err = sum(1 for i in issues if i.level == "error")
        n_warn = sum(1 for i in issues if i.level == "warning")
        if n_err:
            self.summary.setText(
                f"<span style='color:{theme.BAD}'><b>{n_err} error(s)</b></span>"
                f" and {n_warn} warning(s) — the job is not ready to run.")
        elif n_warn:
            self.summary.setText(
                f"<span style='color:{theme.WARN}'>{n_warn} warning(s)</span>"
                " — review before submitting.")
        else:
            self.summary.setText(
                f"<span style='color:{theme.GOOD}'>No problems found.</span> "
                "The potential, the stage chain and the launcher agree.")

    def set_verification(self, info: dict):
        if not info:
            self.verify_out.setPlainText("")
            return
        lines = []
        if "error" in info:
            lines.append("FAILED: " + str(info["error"]))
        else:
            ok = info.get("ok")
            lines.append(("PASS" if ok else "MISMATCH") +
                         "  — the exported file re-evaluates to:")
            for k, exp, got, d in info.get("rows", []):
                lines.append(f"  {k:<11s} model {exp:16.9f}   file "
                             f"{got:16.9f}   Δ {d:.2e}")
            lines.append(f"  worst scalar Δ {info.get('worst', 0):.3e} "
                         f"({info.get('worst_rel', 0):.1e} relative), "
                         f"field Δ {info.get('field_error', 0):.3e} "
                         f"({info.get('field_error_rel', 0):.1e} relative) "
                         f"over {info.get('n_probe', 0)} probe positions; "
                         f"tolerance {info.get('tolerance', 0):.0e} relative")
            dec = info.get("declares", {})
            if dec:
                lines.append("  declare_meta: " + ", ".join(
                    f"{k}={v}" for k, v in dec.get("declare_meta", {}).items()))
        self.verify_out.setPlainText("\n".join(lines))


# ==========================================================================
class PotHighlighter(QtGui.QSyntaxHighlighter):
    def __init__(self, doc):
        super().__init__(doc)
        def fmt(color, bold=False, italic=False):
            f = QtGui.QTextCharFormat()
            f.setForeground(QtGui.QColor(color))
            if bold:
                f.setFontWeight(QtGui.QFont.Bold)
            f.setFontItalic(italic)
            return f
        self.f_comment = fmt("#5d6a85", italic=True)
        self.f_num = fmt("#e8b64c")
        self.f_str = fmt("#7fd08a")
        self.f_fn = fmt("#4da3ff", bold=True)
        self.f_kw = fmt("#c586ff", bold=True)
        self.f_var = fmt("#e6e9f0")
        self.rules = [
            (QtCore.QRegExp(r"\b(declare_meta|declare_output|atomsel|"
                            r"center_of_mass|min_image|norm2|norm|dot|sqrt|"
                            r"exp|array|meta|print)\b"), self.f_fn),
            (QtCore.QRegExp(r"\b(if|then|else)\b"), self.f_kw),
            (QtCore.QRegExp(r"\"[^\"]*\""), self.f_str),
            (QtCore.QRegExp(r"\b[-+]?\d+\.?\d*([eE][-+]?\d+)?\b"), self.f_num),
        ]

    def highlightBlock(self, text):
        for rx, f in self.rules:
            i = rx.indexIn(text)
            while i >= 0:
                length = rx.matchedLength()
                self.setFormat(i, length, f)
                i = rx.indexIn(text, i + max(1, length))
        h = text.find("#")
        if h >= 0:
            self.setFormat(h, len(text) - h, self.f_comment)


class PotentialPanel(QtWidgets.QWidget):
    """Live preview of the potential file, with a diff against the import."""

    def __init__(self, window, parent=None):
        super().__init__(parent)
        self.w = window
        self.view = QtWidgets.QPlainTextEdit()
        self.view.setReadOnly(True)
        mono = QtGui.QFont("DejaVu Sans Mono", 9)
        self.view.setFont(mono)
        self.view.setLineWrapMode(QtWidgets.QPlainTextEdit.NoWrap)
        self.hl = PotHighlighter(self.view.document())
        self.diff = QtWidgets.QPlainTextEdit()
        self.diff.setReadOnly(True)
        self.diff.setFont(mono)
        self.diff.setLineWrapMode(QtWidgets.QPlainTextEdit.NoWrap)
        self.tabs = QtWidgets.QTabWidget()
        self.tabs.addTab(self.view, "generated .pot")
        self.tabs.addTab(self.diff, "diff vs imported")
        copy = QtWidgets.QPushButton("Copy")
        copy.clicked.connect(self._copy)
        save = QtWidgets.QPushButton("Save .pot as…")
        save.clicked.connect(self._save)
        self.status = QtWidgets.QLabel("-")
        self.status.setProperty("dim", "true")
        row = QtWidgets.QHBoxLayout()
        row.addWidget(copy)
        row.addWidget(save)
        row.addWidget(self.status, 1)
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(8, 6, 8, 6)
        lay.addLayout(row)
        lay.addWidget(self.tabs, 1)

    def _copy(self):
        QtWidgets.QApplication.clipboard().setText(self.view.toPlainText())

    def _save(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Save potential", self.w.job.jobname + ".pot",
            "Desmond potential (*.pot)")
        if path:
            from ..core.safety import atomic_write
            atomic_write(path, self.w.job.pot_text().encode("utf-8"))
            self.w.statusBar().showMessage(f"Wrote {path}", 5000)

    def refresh(self):
        job = self.w.job
        try:
            text = job.pot_text()
        except Exception as exc:
            self.view.setPlainText(f"# could not render: {exc}")
            return
        pos = self.view.verticalScrollBar().value()
        self.view.setPlainText(text)
        self.view.verticalScrollBar().setValue(pos)
        src = job.spec.source_text
        if src:
            d = list(difflib.unified_diff(
                src.splitlines(), text.splitlines(),
                os.path.basename(job.spec.source_path or "imported.pot"),
                job.jobname + ".pot", lineterm="", n=2))
            self.diff.setPlainText("\n".join(d) if d else
                                   "identical to the imported potential")
            self._colour_diff()
            n = sum(1 for x in d if x.startswith(("+", "-"))
                    and not x.startswith(("+++", "---")))
            self.status.setText(
                f"{len(text.splitlines())} lines · "
                + ("no changes vs the imported file" if not d
                   else f"{n} changed line(s) vs the imported file"))
        else:
            self.diff.setPlainText("no imported potential to compare against")
            self.status.setText(f"{len(text.splitlines())} lines")

    def _colour_diff(self):
        doc = self.diff.document()
        cur = QtGui.QTextCursor(doc)
        block = doc.begin()
        while block.isValid():
            text = block.text()
            colour = None
            if text.startswith("+++") or text.startswith("---"):
                colour = theme.FG1
            elif text.startswith("+"):
                colour = theme.GOOD
            elif text.startswith("-"):
                colour = theme.BAD
            elif text.startswith("@@"):
                colour = theme.ACCENT
            if colour:
                cur.setPosition(block.position())
                cur.setPosition(block.position() + len(text),
                                QtGui.QTextCursor.KeepAnchor)
                f = QtGui.QTextCharFormat()
                f.setForeground(QtGui.QColor(colour))
                cur.setCharFormat(f)
            block = block.next()


# ==========================================================================
class DisplayPanel(QtWidgets.QWidget):
    """Representation, colouring and the funnel display layers."""

    changed = QtCore.pyqtSignal()          # structure representation
    funnelChanged = QtCore.pyqtSignal()    # funnel layers only

    GROUP_LABELS = {"protein": "Protein", "ligand": "Ligand",
                    "cofactor": "Cofactor / hetero", "ions": "Ions",
                    "water": "Water"}

    def __init__(self, window, parent=None):
        super().__init__(parent)
        self.w = window
        self._loading = False
        self.rows: dict[str, dict] = {}

        gl = QtWidgets.QGridLayout()
        gl.setHorizontalSpacing(6)
        gl.setVerticalSpacing(3)
        for c, head in enumerate(("group", "representation", "colour",
                                  "opacity")):
            lbl = QtWidgets.QLabel(head)
            lbl.setProperty("role", "head")
            gl.addWidget(lbl, 0, c)
        for r, g in enumerate(GROUPS, start=1):
            name = QtWidgets.QLabel(self.GROUP_LABELS[g])
            rep = QtWidgets.QComboBox()
            rep.addItems(REPRESENTATIONS)
            col = QtWidgets.QComboBox()
            col.addItems(COLOR_MODES)
            op = QtWidgets.QSlider(QtCore.Qt.Horizontal)
            op.setRange(5, 100)
            op.setMaximumWidth(90)
            gl.addWidget(name, r, 0)
            gl.addWidget(rep, r, 1)
            gl.addWidget(col, r, 2)
            gl.addWidget(op, r, 3)
            self.rows[g] = {"rep": rep, "col": col, "op": op}
            rep.currentTextChanged.connect(
                lambda t, gg=g: self._style_changed(gg))
            col.currentTextChanged.connect(
                lambda t, gg=g: self._style_changed(gg))
            op.valueChanged.connect(lambda v, gg=g: self._style_changed(gg))

        self.surf_res = ParamRow("surface grid", 0.8, 0.35, 3.0, 0.05, 2, "Å",
                                 tip="Grid spacing of the molecular-surface "
                                     "isosurface; smaller is finer and "
                                     "slower.")
        self.surf_probe = ParamRow("surface probe", 1.2, 0.0, 3.0, 0.1, 2, "Å",
                                   tip="Radius added to every van der Waals "
                                       "radius before contouring.")
        for row in (self.surf_res, self.surf_probe):
            row.valueChanged.connect(self._surface_changed)
        self.show_box = QtWidgets.QCheckBox("Periodic solvent box")
        self.show_box.setChecked(True)
        self.show_sc = QtWidgets.QCheckBox("SITE / CORE atom markers")
        self.show_sc.setChecked(True)
        self.show_lbl = QtWidgets.QCheckBox("Labels")
        self.show_lbl.setChecked(True)
        self.label_sc = QtWidgets.QCheckBox("Label SITE / CORE residues")
        self.peel = QtWidgets.QCheckBox("High-quality transparency")
        self.peel.setToolTip(
            "Depth peeling orders the nested transparent shells correctly. "
            "It needs an alpha-capable GL context; if the funnel disappears, "
            "turn it off.")
        self.water_funnel = QtWidgets.QCheckBox("Water only inside the funnel")
        self.water_funnel.setChecked(True)
        self.ortho = QtWidgets.QCheckBox("Orthographic camera")
        self.bar = QtWidgets.QCheckBox("Colour bar")
        self.bar.setChecked(True)
        for c in (self.show_box, self.show_sc, self.show_lbl, self.label_sc,
                  self.water_funnel, self.ortho, self.bar):
            c.toggled.connect(self._scene_changed)
        self.peel.toggled.connect(self._peel_changed)

        # -- funnel layers
        self.preset = ComboRow("preset", ["Shape only", "Shells (default)",
                                          "Cross-section", "Volume glow",
                                          "Everything"], "Shells (default)")
        self.preset.currentChanged.connect(self._apply_preset)
        self.f_boundary = QtWidgets.QCheckBox("Wall surface (V = 0)")
        self.f_rings = QtWidgets.QCheckBox("Wireframe rings")
        self.f_shells = QtWidgets.QCheckBox("Iso-potential shells")
        self.f_section = QtWidgets.QCheckBox("Cross-section plane")
        self.f_volume = QtWidgets.QCheckBox("Volume glow")
        self.f_caps = QtWidgets.QCheckBox("Axial end walls")
        self.f_axis = QtWidgets.QCheckBox("Axis")
        self.f_ruler = QtWidgets.QCheckBox("Å ruler")
        self.f_labels = QtWidgets.QCheckBox("Dimension labels")
        self.f_com = QtWidgets.QCheckBox("Centre-of-mass markers")
        self.f_handles = QtWidgets.QCheckBox("Drag handles")
        self.f_stiff = QtWidgets.QCheckBox("Tint the wall by stiffness")
        self.f_terms = QtWidgets.QCheckBox("Shape terms")
        self.f_terms.setChecked(True)
        self.f_term_shells = QtWidgets.QCheckBox("Shape-term shells")
        self.f_term_shells.setChecked(True)
        self.f_total = QtWidgets.QCheckBox("Combined field iso-surfaces")
        self.f_total.setToolTip(
            "Marching cubes on the sum of the funnel and every term - the "
            "truest picture of the shape the ligand actually feels.")
        checks = [self.f_boundary, self.f_rings, self.f_shells, self.f_section,
                  self.f_volume, self.f_caps, self.f_axis, self.f_ruler,
                  self.f_labels, self.f_com, self.f_handles, self.f_stiff,
                  self.f_terms, self.f_term_shells, self.f_total]
        for c in checks:
            c.toggled.connect(self._funnel_changed)
        fgrid = QtWidgets.QGridLayout()
        for i, c in enumerate(checks):
            fgrid.addWidget(c, i // 2, i % 2)

        self.scale = ComboRow("colour scale", list(theme.COLOR_SCALES.keys()),
                              theme.DEFAULT_SCALE)
        self.vmax = ParamRow("scale max", 20.0, 1.0, 2000.0, 1.0, 2,
                             "kcal/mol",
                             tip="Energy that maps to full red. With a stiff "
                                 "wall the rise is steep, so use the button "
                                 "to scale it to a distance instead.")
        self.auto_vmax = QtWidgets.QPushButton("scale max = wall energy 2 Å out")
        self.auto_vmax.setToolTip("Sets the colour scale so full red means "
                                  "the ligand is 2 Å outside the wall.")
        self.auto_vmax.clicked.connect(self._auto_vmax)
        self.section_pad = ParamRow("section width", 6.0, 1.0, 40.0, 1.0, 1,
                                    "Å",
                                    tip="How far beyond the wall the "
                                        "cross-section plane extends.")
        self.section_face = QtWidgets.QPushButton("turn section towards camera")
        self.section_face.setToolTip("The cross-section plane contains the "
                                     "funnel axis; this rotates it so you are "
                                     "looking straight at it.")
        self.section_face.clicked.connect(self._face_section)
        self.shell_mode = ComboRow("shells at", ["fixed distances",
                                                 "fixed energies"],
                                   "fixed distances")
        self.shell_values = TextRow("shell list", "0.75, 1.5, 2.25",
                                    tip="Å for fixed distances, kcal/mol for "
                                        "fixed energies.")
        self.op_boundary = ParamRow("wall opacity", 0.13, 0.0, 1.0, 0.02, 2, "",
                                    slider=True)
        self.op_shell = ParamRow("shell opacity", 0.11, 0.0, 1.0, 0.02, 2, "")
        self.op_section = ParamRow("section opacity", 0.55, 0.0, 1.0, 0.05, 2,
                                   "")
        self.op_volume = ParamRow("glow opacity", 0.35, 0.0, 1.0, 0.05, 2, "")
        self.op_terms = ParamRow("term opacity", 0.15, 0.0, 1.0, 0.02, 2, "")
        self.total_levels = TextRow("field levels", "1, 5, 20",
                                    tip="Energies (kcal/mol) for the combined "
                                        "field iso-surfaces.")
        self.field_grid = IntRow("field grid", 64, 24, 128,
                                 tip="Samples per axis for the combined field "
                                     "and for expression terms.")
        self.total_levels.editingFinished.connect(self._funnel_changed)
        self.field_grid.valueChanged.connect(self._funnel_changed)
        self.scale.currentChanged.connect(self._funnel_changed)
        self.shell_mode.currentChanged.connect(self._funnel_changed)
        self.shell_values.editingFinished.connect(self._funnel_changed)
        for row in (self.vmax, self.op_boundary, self.op_shell,
                    self.op_section, self.op_volume, self.section_pad,
                    self.op_terms):
            row.valueChanged.connect(self._funnel_changed)

        cam = QtWidgets.QHBoxLayout()
        for text, slot in (("Down axis", self.w_view_axis),
                           ("Side", self.w_view_side),
                           ("Fit funnel", self.w_fit_funnel),
                           ("Fit all", self.w_fit_all)):
            b = QtWidgets.QPushButton(text)
            b.clicked.connect(slot)
            cam.addWidget(b)

        inner = vbox(
            group("Molecular representations", gl, self.surf_res,
                  self.surf_probe),
            group("Scene", self.show_box, self.show_sc, self.show_lbl,
                  self.label_sc, self.water_funnel, self.ortho, self.bar,
                  self.peel),
            group("Funnel layers", self.preset, fgrid),
            group("Potential colours", self.scale, self.vmax, self.auto_vmax,
                  self.shell_mode, self.shell_values, self.section_pad,
                  self.section_face,
                  self.op_boundary, self.op_shell, self.op_section,
                  self.op_volume, self.op_terms, hline(),
                  self.total_levels, self.field_grid),
            group("Camera", cam),
            None)
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(scroll_area(inner))
        self._apply_preset("Shells (default)")

    # -- camera helpers
    def w_view_axis(self):
        self.w.viewer.view_funnel_axis()

    def w_view_side(self):
        self.w.viewer.view_funnel_side()

    def w_fit_funnel(self):
        self.w.viewer.fit_funnel()

    def w_fit_all(self):
        self.w.viewer.fit_all()

    # -- handlers
    def _style_changed(self, g):
        if self._loading:
            return
        st = self.w.viewer.styles[g]
        row = self.rows[g]
        st.representation = row["rep"].currentText()
        st.color_mode = row["col"].currentText()
        st.opacity = row["op"].value() / 100.0
        self.changed.emit()

    def _surface_changed(self, *_):
        if self._loading:
            return
        for g in GROUPS:
            st = self.w.viewer.styles[g]
            st.surface_resolution = self.surf_res.value()
            st.surface_probe = self.surf_probe.value()
        if any(self.w.viewer.styles[g].representation == "Molecular surface"
               for g in GROUPS):
            self.changed.emit()

    def _scene_changed(self, *_):
        if self._loading:
            return
        o = self.w.viewer.options
        o.show_box = self.show_box.isChecked()
        o.show_site_core = self.show_sc.isChecked()
        o.show_labels = self.show_lbl.isChecked()
        o.label_site_core = self.label_sc.isChecked()
        o.water_within_funnel = self.water_funnel.isChecked()
        o.scalar_bar = self.bar.isChecked()
        self.w.viewer.set_orthographic(self.ortho.isChecked())
        self.changed.emit()

    def _peel_changed(self, on):
        if self._loading:
            return
        available = self.w.viewer.set_depth_peeling(on)
        if on and not available:
            self.w.statusBar().showMessage(
                "This GL context has no alpha planes; depth peeling stays off.",
                6000)

    def _funnel_changed(self, *_):
        if self._loading:
            return
        s = self.w.viewer.funnel.style
        s.show_boundary = self.f_boundary.isChecked()
        s.wireframe_rings = self.f_rings.isChecked()
        s.show_shells = self.f_shells.isChecked()
        s.show_section = self.f_section.isChecked()
        s.show_volume = self.f_volume.isChecked()
        s.show_caps = self.f_caps.isChecked()
        s.show_axis = self.f_axis.isChecked()
        s.show_ruler = self.f_ruler.isChecked()
        s.show_labels = self.f_labels.isChecked()
        s.show_com = self.f_com.isChecked()
        s.show_handles = self.f_handles.isChecked()
        s.boundary_by_stiffness = self.f_stiff.isChecked()
        s.show_terms = self.f_terms.isChecked()
        s.show_term_shells = self.f_term_shells.isChecked()
        s.show_total_field = self.f_total.isChecked()
        s.term_opacity = self.op_terms.value()
        s.field_grid = int(self.field_grid.value())
        levels = []
        for part in self.total_levels.text().replace(";", ",").split(","):
            part = part.strip()
            if part:
                try:
                    levels.append(float(part))
                except ValueError:
                    pass
        if levels:
            s.total_levels = tuple(levels)
        s.scale_name = self.scale.currentText()
        s.v_max = self.vmax.value()
        s.boundary_opacity = self.op_boundary.value()
        s.shell_opacity = self.op_shell.value()
        s.section_opacity = self.op_section.value()
        s.section_pad = self.section_pad.value()
        s.volume_opacity = self.op_volume.value()
        s.shell_mode = ("energy" if self.shell_mode.currentText().startswith(
            "fixed energies") else "distance")
        vals = []
        for part in self.shell_values.text().replace(";", ",").split(","):
            part = part.strip()
            if not part:
                continue
            try:
                vals.append(float(part))
            except ValueError:
                pass
        if vals:
            if s.shell_mode == "energy":
                s.shell_levels = tuple(vals)
            else:
                s.shell_offsets = tuple(vals)
        self.funnelChanged.emit()

    def _face_section(self):
        self.w.viewer.face_section_to_camera()
        if not self.f_section.isChecked():
            self.f_section.setChecked(True)
        else:
            self.w.viewer.rebuild_funnel()
            self.w.viewer.render()

    def _auto_vmax(self):
        sp = self.w.job.spec
        self.vmax.setValue(0.5 * max(sp.k_rad, 1e-6) * 4.0, silent=False)

    def _apply_preset(self, name):
        self._loading = True
        conf = {
            "Shape only": dict(b=1, r=1, s=0, sec=0, vol=0),
            "Shells (default)": dict(b=1, r=1, s=1, sec=0, vol=0),
            "Cross-section": dict(b=1, r=1, s=0, sec=1, vol=0),
            "Volume glow": dict(b=1, r=0, s=0, sec=0, vol=1),
            "Everything": dict(b=1, r=1, s=1, sec=1, vol=1),
        }.get(name)
        if conf and conf["sec"]:
            self.w.viewer.face_section_to_camera()
        if conf:
            self.f_boundary.setChecked(bool(conf["b"]))
            self.f_rings.setChecked(bool(conf["r"]))
            self.f_shells.setChecked(bool(conf["s"]))
            self.f_section.setChecked(bool(conf["sec"]))
            self.f_volume.setChecked(bool(conf["vol"]))
        for c, v in ((self.f_caps, True), (self.f_axis, True),
                     (self.f_ruler, True), (self.f_labels, True),
                     (self.f_com, True), (self.f_handles, True)):
            if not c.isChecked() and v and name != "Shape only":
                c.setChecked(v)
        self._loading = False
        self._funnel_changed()

    def refresh(self):
        self._loading = True
        self.peel.setChecked(bool(getattr(self.w.viewer, "options").depth_peeling
                                  and self.w.viewer.depth_peeling_available))
        for g in GROUPS:
            st = self.w.viewer.styles[g]
            row = self.rows[g]
            row["rep"].setCurrentText(st.representation)
            row["col"].setCurrentText(st.color_mode)
            row["op"].setValue(int(st.opacity * 100))
        self._loading = False
