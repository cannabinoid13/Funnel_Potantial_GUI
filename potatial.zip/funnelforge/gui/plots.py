"""2-D profile plots: funnel outline, potential map, wall cuts, WT bias."""

from __future__ import annotations

import numpy as np
import matplotlib
matplotlib.use("Qt5Agg")
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as Canvas
from matplotlib.figure import Figure
from matplotlib.colors import LinearSegmentedColormap
from PyQt5 import QtWidgets

from . import theme


def _cmap(name: str) -> LinearSegmentedColormap:
    stops = theme.COLOR_SCALES.get(name) or theme.COLOR_SCALES[theme.DEFAULT_SCALE]
    return LinearSegmentedColormap.from_list("ff", [(p, c) for p, c in stops])


def _style_axes(ax, title: str = "", xlabel: str = "", ylabel: str = ""):
    ax.set_facecolor(theme.BG1)
    for spine in ax.spines.values():
        spine.set_color(theme.BG3)
    ax.tick_params(colors=theme.FG1, labelsize=8, length=3)
    ax.grid(True, color=theme.BG3, linewidth=0.6, alpha=0.6)
    ax.set_axisbelow(True)
    if title:
        ax.set_title(title, color=theme.FG0, fontsize=9.5, pad=6)
    if xlabel:
        ax.set_xlabel(xlabel, color=theme.FG1, fontsize=8.5)
    if ylabel:
        ax.set_ylabel(ylabel, color=theme.FG1, fontsize=8.5)


class _Base(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.fig = Figure(figsize=(5, 2.6), dpi=100, facecolor=theme.BG1,
                          layout="constrained")
        self.canvas = Canvas(self.fig)
        self.canvas.setStyleSheet(f"background-color: {theme.BG1};")
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.canvas)


class FunnelProfilePlot(_Base):
    """r_allowed(z) with the solute atom cloud in (z, rho) space."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ax = self.fig.add_subplot(111)
        self._cloud = None

    def refresh(self, model, style, structure=None):
        ax = self.ax
        ax.clear()
        if model is None:
            self.canvas.draw_idle()
            return
        sp = model.spec
        _style_axes(ax, "funnel envelope and solute atoms",
                    "z along the funnel axis  (Å)", "ρ  (Å)")
        if structure is not None:
            if self._cloud is None or self._cloud[0] is not structure:
                mask = structure.mask("heavy") & ~structure.mask("water")
                idx = np.where(mask)[0]
                self._cloud = (structure, idx)
            idx = self._cloud[1]
            z, rho = model.cv(structure.xyz[idx])
            keep = np.ones(len(z), dtype=bool)
            ax.plot(z[keep], rho[keep], ".", ms=1.1, color="#5b6480",
                    alpha=0.55, zorder=1, label="solute heavy atoms")
        cm = _cmap(style.scale_name)
        lo, hi, r_out = model.field_bounds(pad=3.0)
        zs = np.linspace(lo, hi, 320)
        rs = np.linspace(0.0, r_out, 220)
        ZZ, RR = np.meshgrid(zs, rs)
        VV = np.asarray(model.total_field(z=ZZ.ravel(), rho=RR.ravel())
                        ).reshape(ZZ.shape)
        VV = np.where(np.isfinite(VV), VV, 0.0)
        ax.contourf(ZZ, RR, (VV < 1e-9).astype(float), levels=[0.5, 1.5],
                    colors=[cm(0.0)], alpha=0.18, zorder=2)
        ax.contour(ZZ, RR, VV, levels=[1e-6], colors=[cm(0.02)],
                   linewidths=1.8, zorder=4)
        ax.plot([], [], color=cm(0.02), lw=1.8, label="allowed region  V = 0")
        if sp.funnel_enabled:
            zf = np.linspace(sp.z_min, sp.z_max, 300)
            for dr, dz, v in _pairs(model, style):
                t = float(np.clip(v / max(style.v_max, 1e-6), 0, 1))
                ax.plot(zf, sp.r_allowed(zf) + dr, color=cm(t), lw=1.0,
                        alpha=0.9, zorder=3, label=f"V = {v:.1f}")
        skewed = False
        for t in sp.active_terms:
            if t.is_tilted or t.is_off_axis:
                skewed = True
                pts = model.term_surface_points(t, n_z=40, n_theta=24)
                if len(pts):
                    tz, trho = model.cv(pts)
                    ax.plot(tz, trho, ".", ms=1.2, color=tuple(t.color),
                            alpha=0.75, zorder=5, label=t.label or t.var)
                continue
            r = model.term_profile(t, zs)
            if r is None:
                continue
            ax.plot(zs, np.where(np.isfinite(r), r, np.nan),
                    color=tuple(t.color), lw=1.4, zorder=5,
                    label=t.label or t.var)
        if skewed:
            ax.text(0.01, 0.02,
                    "tilted or off-axis shapes are shown as their real "
                    "surface projected onto (z, ρ)",
                    transform=ax.transAxes, color=theme.FG1, fontsize=7)
        marks = []
        if sp.funnel_enabled:
            marks += [(sp.z_min, theme.ACCENT, "z_min"),
                      (sp.z_cc, theme.WARN, "z_cc"),
                      (sp.z_max, theme.BAD, "z_max")]
        for t in sp.active_terms:
            if t.region.enabled:
                marks += [(t.region.z_lo, tuple(t.color), ""),
                          (t.region.z_hi, tuple(t.color), "")]
        for z, c, lbl in marks:
            ax.axvline(z, color=c, lw=1.0, ls="--", alpha=0.8)
            if lbl:
                ax.text(z, ax.get_ylim()[1], f" {lbl}", color=c, fontsize=7.5,
                        va="top", rotation=90)
        z0, rho0 = model.cv_of_ligand()
        ax.plot([z0], [rho0], "o", ms=8, mfc=theme.LIGAND, mec="white",
                mew=1.2, zorder=6, label="ligand now")
        ax.set_xlim(lo, hi)
        ax.set_ylim(0, r_out)
        leg = ax.legend(loc="upper right", fontsize=7, frameon=True,
                        facecolor=theme.BG2, edgecolor=theme.BG3,
                        labelcolor=theme.FG1, ncol=2)
        leg.get_frame().set_alpha(0.9)
        self.canvas.draw_idle()


class PotentialMapPlot(_Base):
    """Filled map of the wall potential in the (z, rho) plane.

    Zero is fully transparent, so the flat-bottom region reads as empty and
    only the wall itself is coloured - the same encoding as the 3-D view.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ax = self.fig.add_subplot(111)
        self.cbar = None

    def refresh(self, model, style):
        self.fig.clear()
        ax = self.fig.add_subplot(111)
        self.ax = ax
        if model is None:
            self.canvas.draw_idle()
            return
        sp = model.spec
        title = "restraint  V(z, ρ)   ·   flat bottom is empty"
        if sp.active_terms:
            title += f"   ·   funnel + {len(sp.active_terms)} term(s)"
        if any(t.is_tilted or t.is_off_axis for t in sp.active_terms):
            title += "   ·   section through e1"
        _style_axes(ax, title, "z  (Å)", "ρ  (Å)")
        pad = float(getattr(style, "section_pad", 6.0))
        zs = np.linspace(sp.z_min - pad, sp.z_max + pad, 460)
        rs = np.linspace(0, sp.r_base() + pad, 300)
        ZZ, RR = np.meshgrid(zs, rs)
        V = np.asarray(model.total_field(z=ZZ.ravel(), rho=RR.ravel())
                       ).reshape(ZZ.shape)
        V = np.where(np.isfinite(V), V, 0.0)
        vmax = max(style.v_max, 1e-9)
        t = np.clip(V / vmax, 0.0, 1.0)
        rgb = theme.scale_rgb(style.scale_name, t)
        alpha = np.where(V / vmax <= 1.0, t ** 0.55,
                         np.exp(-(V / vmax - 1.0) * 1.2))
        rgba = np.dstack([rgb, np.clip(alpha, 0.0, 1.0)])
        ax.imshow(rgba, origin="lower", aspect="auto",
                  extent=[zs[0], zs[-1], rs[0], rs[-1]],
                  interpolation="bilinear")
        levels = [v for v in (0.5, 2, 5, 10, 25, 50, 100)
                  if v < float(V.max())]
        if levels:
            cs = ax.contour(ZZ, RR, V, levels=levels, colors="white",
                            linewidths=0.6, alpha=0.5)
            ax.clabel(cs, inline=True, fontsize=6.5, fmt="%g")
        if sp.funnel_enabled:
            ax.plot(zs, sp.r_allowed(np.clip(zs, sp.z_min, sp.z_max)),
                    color="#9fc6ff", lw=1.5, alpha=0.95, label="funnel wall")
        for t in sp.active_terms:
            r = model.term_profile(t, zs)
            if r is None:
                continue
            ax.plot(zs, np.where(np.isfinite(r), r, np.nan),
                    color=tuple(t.color), lw=1.3, alpha=0.95,
                    label=t.label or t.var)
        if sp.funnel_enabled:
            for z, c in ((sp.z_min, theme.ACCENT), (sp.z_max, theme.BAD),
                         (sp.z_cc, theme.WARN)):
                ax.axvline(z, color=c, lw=0.9, ls="--", alpha=0.7)
        z0, rho0 = model.cv_of_ligand()
        ax.plot([z0], [rho0], "o", ms=7, mfc=theme.LIGAND, mec="white",
                mew=1.1, label="ligand now")
        ax.set_xlim(zs[0], zs[-1])
        ax.set_ylim(rs[0], rs[-1])
        leg = ax.legend(loc="upper right", fontsize=7, frameon=True,
                        facecolor=theme.BG2, edgecolor=theme.BG3,
                        labelcolor=theme.FG1)
        leg.get_frame().set_alpha(0.9)
        sm = matplotlib.cm.ScalarMappable(
            norm=matplotlib.colors.Normalize(0, vmax), cmap=_cmap(style.scale_name))
        cb = self.fig.colorbar(sm, ax=ax, pad=0.02, fraction=0.045)
        cb.set_label("kcal/mol", color=theme.FG1, fontsize=8)
        cb.ax.tick_params(colors=theme.FG1, labelsize=7)
        cb.outline.set_edgecolor(theme.BG3)
        self.canvas.draw_idle()


class WallCutPlot(_Base):
    """Radial and axial cuts through the restraint."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ax1 = self.fig.add_subplot(121)
        self.ax2 = self.fig.add_subplot(122)

    def refresh(self, model, style):
        for ax in (self.ax1, self.ax2):
            ax.clear()
        if model is None:
            self.canvas.draw_idle()
            return
        sp = model.spec
        cm = _cmap(style.scale_name)
        z0, rho0 = model.cv_of_ligand()
        _style_axes(self.ax1, f"radial cut of the whole restraint at "
                    f"z = {z0:.2f} Å", "ρ  (Å)", "V  (kcal/mol)")
        _lo, _hi, r_out = model.field_bounds(pad=3.0)
        rs = np.linspace(0, r_out, 400)
        v = np.asarray(model.total_field(z=np.full_like(rs, z0), rho=rs))
        v = np.where(np.isfinite(v), v, 0.0)
        self.ax1.plot(rs, v, color=cm(0.75), lw=2.0)
        if sp.funnel_enabled:
            self.ax1.axvline(float(sp.r_allowed(z0)), color=cm(0.02), lw=1.2,
                             ls="--")
        self.ax1.axvline(rho0, color=theme.LIGAND, lw=1.2)
        self.ax1.text(rho0, self.ax1.get_ylim()[1] * 0.92, " ligand",
                      color=theme.LIGAND, fontsize=7.5)
        self.ax1.set_ylim(0, style.v_max * 1.15)

        _style_axes(self.ax2, "axial cut on the axis", "z  (Å)",
                    "V  (kcal/mol)")
        lo, hi, _r = model.field_bounds(pad=6.0)
        zs = np.linspace(lo, hi, 500)
        vz = np.asarray(model.total_field(z=zs, rho=np.zeros_like(zs)))
        self.ax2.plot(zs, np.where(np.isfinite(vz), vz, 0.0),
                      color=cm(0.75), lw=2.0)
        if sp.funnel_enabled:
            for z, c in ((sp.z_min, theme.ACCENT), (sp.z_max, theme.BAD)):
                self.ax2.axvline(z, color=c, lw=1.1, ls="--")
        self.ax2.axvline(z0, color=theme.LIGAND, lw=1.2)
        self.ax2.set_ylim(0, style.v_max * 1.15)
        self.canvas.draw_idle()


class WellTemperedPlot(_Base):
    """How the hill height decays as bias accumulates."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ax1 = self.fig.add_subplot(121)
        self.ax2 = self.fig.add_subplot(122)

    def refresh(self, model, style, production_ps=None):
        for ax in (self.ax1, self.ax2):
            ax.clear()
        if model is None:
            self.canvas.draw_idle()
            return
        sp = model.spec
        cm = _cmap(style.scale_name)
        _style_axes(self.ax1, "well-tempered hill scaling",
                    "accumulated bias V  (kcal/mol)", "hill height  (kcal/mol)")
        vmax = max(4.0 * sp.ktemp, 1.0)
        v = np.linspace(0, vmax, 300)
        self.ax1.plot(v, sp.h0 * np.exp(-v / max(sp.ktemp, 1e-9)),
                      color=cm(0.7), lw=2.0)
        self.ax1.axvline(sp.ktemp, color=theme.FG2, ls="--", lw=1.0)
        self.ax1.text(sp.ktemp, sp.h0 * 0.75, " kTemp", color=theme.FG1,
                      fontsize=7.5)
        self.ax1.set_ylim(0, sp.h0 * 1.1)

        _style_axes(self.ax2, "kernel width on the CV range",
                    "z  (Å)", "kernel")
        zs = np.linspace(sp.z_min, sp.z_max, 600)
        n = 9
        for k, zc in enumerate(np.linspace(sp.z_min, sp.z_max, n)):
            g = np.exp(-0.5 * ((zs - zc) / max(sp.sigma_z, 1e-6)) ** 2)
            self.ax2.plot(zs, g, color=cm(k / max(1, n - 1)), lw=1.2,
                          alpha=0.85)
        self.ax2.set_ylim(0, 1.15)
        self.ax2.text(0.02, 0.92,
                      f"σ = {sp.sigma_z:g} Å over {sp.z_max - sp.z_min:g} Å "
                      f"({(sp.z_max - sp.z_min) / max(sp.sigma_z, 1e-9):.0f} σ)",
                      transform=self.ax2.transAxes, color=theme.FG1,
                      fontsize=7.5)
        self.canvas.draw_idle()


def _pairs(model, style):
    try:
        sp = model.spec
        out = []
        if style.shell_mode == "energy":
            for v in sorted(style.shell_levels):
                if v > 0:
                    out.append((sp.radial_offset_for(v),
                                sp.axial_offset_for(v), float(v)))
        else:
            for dr in sorted(style.shell_offsets):
                if dr > 0:
                    v = 0.5 * sp.k_rad * dr * dr
                    out.append((float(dr), sp.axial_offset_for(v), float(v)))
        return out
    except Exception:
        return []


class ProfileDock(QtWidgets.QTabWidget):
    """All four plots, refreshed lazily so only the visible one costs time."""

    def __init__(self, window, parent=None):
        super().__init__(parent)
        self.w = window
        self.profile = FunnelProfilePlot()
        self.map = PotentialMapPlot()
        self.cuts = WallCutPlot()
        self.wt = WellTemperedPlot()
        self.addTab(self.profile, "Funnel profile")
        self.addTab(self.map, "Potential map")
        self.addTab(self.cuts, "Wall cuts")
        self.addTab(self.wt, "Well-tempered")
        self._dirty = {0: True, 1: True, 2: True, 3: True}
        self.currentChanged.connect(lambda i: self.refresh())

    def invalidate(self):
        self._dirty = {k: True for k in self._dirty}

    def refresh(self):
        i = self.currentIndex()
        if not self._dirty.get(i, True):
            return
        model = self.w.job.model
        style = self.w.viewer.funnel.style
        if i == 0:
            self.profile.refresh(model, style, self.w.job.structure)
        elif i == 1:
            self.map.refresh(model, style)
        elif i == 2:
            self.cuts.refresh(model, style)
        else:
            self.wt.refresh(model, style, self.w.job.production_ps)
        self._dirty[i] = False
