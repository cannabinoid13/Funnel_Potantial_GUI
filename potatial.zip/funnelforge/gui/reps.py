"""Molecular representations built as VTK actors.

Everything is assembled from numpy arrays so a 60 000-atom solvated system can
be re-styled without touching the parser.  Representations available per group:
cartoon tube, ribbon, backbone trace, licorice, ball-and-stick, van-der-Waals
spheres, a fast Gaussian surface, and points.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import vtk
from vtk.util import numpy_support as nps

from ..core import elements
from . import theme

REPRESENTATIONS = ["Cartoon (tube)", "Ribbon", "Backbone trace", "Licorice",
                   "Ball & stick", "Spheres (VdW)", "Molecular surface",
                   "Points", "Hidden"]
COLOR_MODES = ["Chain", "Element", "Secondary structure", "Residue type",
               "B-factor", "Funnel z", "Uniform"]


# --------------------------------------------------------------------------
# numpy -> vtk helpers
# --------------------------------------------------------------------------
def _points(xyz: np.ndarray) -> vtk.vtkPoints:
    pts = vtk.vtkPoints()
    arr = nps.numpy_to_vtk(np.ascontiguousarray(xyz, dtype=np.float64),
                           deep=True)
    pts.SetData(arr)
    return pts


def _colors(rgb: np.ndarray, name: str = "Colors") -> vtk.vtkUnsignedCharArray:
    c = np.clip(np.asarray(rgb) * 255.0, 0, 255).astype(np.uint8)
    arr = nps.numpy_to_vtk(np.ascontiguousarray(c), deep=True,
                           array_type=vtk.VTK_UNSIGNED_CHAR)
    arr.SetName(name)
    return arr


def _scalars(values: np.ndarray, name: str) -> vtk.vtkDoubleArray:
    arr = nps.numpy_to_vtk(np.ascontiguousarray(values, dtype=np.float64),
                           deep=True)
    arr.SetName(name)
    return arr


def point_polydata(xyz: np.ndarray, rgb: np.ndarray | None = None,
                   radii: np.ndarray | None = None) -> vtk.vtkPolyData:
    pd = vtk.vtkPolyData()
    pd.SetPoints(_points(xyz))
    verts = vtk.vtkCellArray()
    n = len(xyz)
    ids = np.empty(2 * n, dtype=np.int64)
    ids[0::2] = 1
    ids[1::2] = np.arange(n)
    ca = nps.numpy_to_vtkIdTypeArray(ids, deep=True)
    verts.SetCells(n, ca)
    pd.SetVerts(verts)
    if rgb is not None:
        pd.GetPointData().SetScalars(_colors(rgb))
    if radii is not None:
        pd.GetPointData().AddArray(_scalars(radii, "radius"))
    return pd


def line_polydata(xyz: np.ndarray, segments: np.ndarray,
                  rgb: np.ndarray | None = None) -> vtk.vtkPolyData:
    """``segments`` is an (M, 2) index array into ``xyz``."""
    pd = vtk.vtkPolyData()
    pd.SetPoints(_points(xyz))
    lines = vtk.vtkCellArray()
    m = len(segments)
    ids = np.empty(3 * m, dtype=np.int64)
    ids[0::3] = 2
    ids[1::3] = segments[:, 0]
    ids[2::3] = segments[:, 1]
    lines.SetCells(m, nps.numpy_to_vtkIdTypeArray(ids, deep=True))
    pd.SetLines(lines)
    if rgb is not None:
        pd.GetPointData().SetScalars(_colors(rgb))
    return pd


def polyline_polydata(chunks: list[np.ndarray],
                      colors: list[np.ndarray] | None = None) -> vtk.vtkPolyData:
    pts, cells, cols = [], [], []
    off = 0
    for k, ch in enumerate(chunks):
        n = len(ch)
        if n < 2:
            off += n
            pts.append(ch)
            if colors is not None:
                cols.append(colors[k])
            continue
        pts.append(ch)
        cells.append((n, np.arange(off, off + n)))
        if colors is not None:
            cols.append(colors[k])
        off += n
    if not pts:
        return vtk.vtkPolyData()
    allpts = np.vstack(pts)
    pd = vtk.vtkPolyData()
    pd.SetPoints(_points(allpts))
    ca = vtk.vtkCellArray()
    flat = []
    for n, idx in cells:
        flat.append(np.concatenate(([n], idx)))
    if flat:
        ids = np.concatenate(flat).astype(np.int64)
        ca.SetCells(len(cells), nps.numpy_to_vtkIdTypeArray(ids, deep=True))
    pd.SetLines(ca)
    if colors is not None and cols:
        pd.GetPointData().SetScalars(_colors(np.vstack(cols)))
    return pd


def triangle_polydata(pts: np.ndarray, faces: np.ndarray) -> vtk.vtkPolyData:
    pd = vtk.vtkPolyData()
    pd.SetPoints(_points(pts))
    ca = vtk.vtkCellArray()
    m = len(faces)
    ids = np.empty(4 * m, dtype=np.int64)
    ids[0::4] = 3
    ids[1::4] = faces[:, 0]
    ids[2::4] = faces[:, 1]
    ids[3::4] = faces[:, 2]
    ca.SetCells(m, nps.numpy_to_vtkIdTypeArray(ids, deep=True))
    pd.SetPolys(ca)
    return pd


# --------------------------------------------------------------------------
# colouring
# --------------------------------------------------------------------------
def atom_colors(st, idx: np.ndarray, mode: str, model=None,
                uniform=(0.65, 0.70, 0.80)) -> np.ndarray:
    n = len(idx)
    if n == 0:
        return np.zeros((0, 3))
    if mode == "Element":
        out = np.empty((n, 3))
        cache: dict[int, tuple] = {}
        for k, i in enumerate(idx):
            z = int(st.anum[i])
            c = cache.get(z)
            if c is None:
                c = elements.color(z)
                cache[z] = c
            out[k] = c
        return out
    if mode == "Chain":
        chains = st.chains()
        lookup = {c: theme.CHAIN_COLORS[k % len(theme.CHAIN_COLORS)]
                  for k, c in enumerate(chains)}
        return np.array([lookup.get(str(st.chain[i]), uniform) for i in idx])
    if mode == "Secondary structure":
        return np.array([theme.SS_COLORS.get(int(st.ss[i]),
                                             theme.SS_COLORS[0]) for i in idx])
    if mode == "Residue type":
        return np.array([elements.RESIDUE_CLASS_COLOR[
            elements.residue_class(str(st.resname[i]))] for i in idx])
    if mode == "B-factor":
        b = st.bfactor[idx].astype(float)
        lo, hi = np.percentile(b, 2), np.percentile(b, 98)
        t = np.clip((b - lo) / (hi - lo + 1e-9), 0, 1)
        return theme.scale_rgb("Blue → Red", t)
    if mode == "Funnel z" and model is not None:
        z, _ = model.cv(st.xyz[idx])
        sp = model.spec
        t = np.clip((z - sp.z_min) / max(1e-6, sp.z_max - sp.z_min), 0, 1)
        return theme.scale_rgb("Blue → Cyan → Red", t)
    return np.tile(np.asarray(uniform, dtype=float), (n, 1))


# --------------------------------------------------------------------------
# representation builder
# --------------------------------------------------------------------------
@dataclass
class RepStyle:
    representation: str = "Cartoon (tube)"
    color_mode: str = "Chain"
    opacity: float = 1.0
    scale: float = 1.0
    uniform: tuple = (0.65, 0.70, 0.80)
    show_hydrogens: bool = False
    smooth: bool = True
    surface_resolution: float = 0.8      # grid spacing, A
    surface_probe: float = 1.2           # probe radius added to the vdW radii
    surface_max_points: int = 1_600_000
    specular: float = 0.35


class RepBuilder:
    """Turns (structure, atom mask, style) into a list of VTK actors."""

    def __init__(self, structure, model=None):
        self.st = structure
        self.model = model

    # -- public
    def build(self, mask: np.ndarray, style: RepStyle) -> list[vtk.vtkActor]:
        st = self.st
        if mask is None or not mask.any() or style.representation == "Hidden":
            return []
        if not style.show_hydrogens:
            mask = mask & (st.anum != 1)
            if not mask.any():
                return []
        idx = np.where(mask)[0]
        rep = style.representation
        if rep == "Points":
            return [self._points(idx, style)]
        if rep == "Spheres (VdW)":
            return [self._spheres(idx, style, scale=1.0)]
        if rep == "Ball & stick":
            return [self._spheres(idx, style, scale=0.28 * style.scale),
                    self._bonds(idx, style, radius=0.13 * style.scale)]
        if rep == "Licorice":
            return [self._spheres(idx, style, scale=0.16 * style.scale),
                    self._bonds(idx, style, radius=0.16 * style.scale)]
        if rep == "Backbone trace":
            return [self._trace(idx, style, radius=0.0)]
        if rep == "Cartoon (tube)":
            actors = [self._trace(idx, style, radius=0.42 * style.scale)]
            extra = self._nonpolymer_fallback(idx, style)
            return [a for a in actors + extra if a is not None]
        if rep == "Ribbon":
            actors = [self._trace(idx, style, radius=0.0, ribbon=True)]
            extra = self._nonpolymer_fallback(idx, style)
            return [a for a in actors + extra if a is not None]
        if rep == "Molecular surface":
            a = self._surface(idx, style)
            return [a] if a is not None else []
        return [self._spheres(idx, style, scale=0.3)]

    # -- pieces
    def _points(self, idx, style) -> vtk.vtkActor:
        st = self.st
        rgb = atom_colors(st, idx, style.color_mode, self.model, style.uniform)
        pd = point_polydata(st.xyz[idx], rgb)
        mp = vtk.vtkPolyDataMapper()
        mp.SetInputData(pd)
        mp.SetColorModeToDirectScalars()
        ac = vtk.vtkActor()
        ac.SetMapper(mp)
        ac.GetProperty().SetPointSize(max(1.0, 2.2 * style.scale))
        ac.GetProperty().SetOpacity(style.opacity)
        ac.GetProperty().SetRenderPointsAsSpheres(True)
        return ac

    def _spheres(self, idx, style, scale: float = 1.0) -> vtk.vtkActor:
        st = self.st
        rgb = atom_colors(st, idx, style.color_mode, self.model, style.uniform)
        radii = np.array([elements.vdw_radius(int(z)) for z in st.anum[idx]])
        radii = radii * scale if scale != 1.0 else radii * style.scale
        pd = point_polydata(st.xyz[idx], rgb, radii)
        src = vtk.vtkSphereSource()
        src.SetRadius(1.0)
        res = 16 if len(idx) < 20000 else 8
        src.SetThetaResolution(res)
        src.SetPhiResolution(res)
        mp = vtk.vtkGlyph3DMapper()
        mp.SetInputData(pd)
        mp.SetSourceConnection(src.GetOutputPort())
        mp.SetScaleArray("radius")
        mp.SetScaleModeToScaleByMagnitude()
        mp.SetScalarModeToUsePointData()
        mp.SetColorModeToDirectScalars()
        mp.SetStatic(True)
        ac = vtk.vtkActor()
        ac.SetMapper(mp)
        p = ac.GetProperty()
        p.SetOpacity(style.opacity)
        p.SetSpecular(style.specular)
        p.SetSpecularPower(28)
        p.SetAmbient(0.22)
        p.SetDiffuse(0.85)
        return ac

    def _bonds(self, idx, style, radius: float = 0.15) -> vtk.vtkActor | None:
        st = self.st
        if len(st.bonds) == 0:
            return None
        keep = np.zeros(st.n_atoms, dtype=bool)
        keep[idx] = True
        b = st.bonds
        sel = keep[b[:, 0]] & keep[b[:, 1]]
        bonds = b[sel]
        if len(bonds) == 0:
            return None
        rgb_all = np.zeros((st.n_atoms, 3))
        rgb_all[idx] = atom_colors(st, idx, style.color_mode, self.model,
                                   style.uniform)
        a, c = bonds[:, 0], bonds[:, 1]
        pa, pc = st.xyz[a], st.xyz[c]
        pm = 0.5 * (pa + pc)
        # split every bond at its midpoint so each half keeps its atom colour
        pts = np.vstack([pa, pm, pc])
        n = len(bonds)
        seg = np.vstack([np.column_stack([np.arange(n), np.arange(n, 2 * n)]),
                         np.column_stack([np.arange(n, 2 * n),
                                          np.arange(2 * n, 3 * n)])])
        cols = np.vstack([rgb_all[a], 0.5 * (rgb_all[a] + rgb_all[c]),
                          rgb_all[c]])
        pd = line_polydata(pts, seg, cols)
        tube = vtk.vtkTubeFilter()
        tube.SetInputData(pd)
        tube.SetRadius(radius)
        tube.SetNumberOfSides(8 if n < 20000 else 5)
        tube.CappingOn()
        tube.Update()
        mp = vtk.vtkPolyDataMapper()
        mp.SetInputConnection(tube.GetOutputPort())
        mp.SetColorModeToDirectScalars()
        ac = vtk.vtkActor()
        ac.SetMapper(mp)
        p = ac.GetProperty()
        p.SetOpacity(style.opacity)
        p.SetSpecular(style.specular)
        p.SetSpecularPower(24)
        p.SetAmbient(0.2)
        return ac

    def _nonpolymer_fallback(self, idx, style) -> list[vtk.vtkActor]:
        """Cartoon modes still need sticks for anything without a CA trace."""
        st = self.st
        mask = np.zeros(st.n_atoms, dtype=bool)
        mask[idx] = True
        poly = mask & st.mask("protein")
        rest = mask & ~poly
        if not rest.any():
            return []
        sub = np.where(rest)[0]
        out = [self._spheres(sub, style, scale=0.20 * style.scale)]
        b = self._bonds(sub, style, radius=0.14 * style.scale)
        if b is not None:
            out.append(b)
        return out

    def _ca_chunks(self, idx) -> tuple[list[np.ndarray], list[np.ndarray]]:
        """Contiguous CA polylines with per-point colours."""
        st = self.st
        mask = np.zeros(st.n_atoms, dtype=bool)
        mask[idx] = True
        chunks, colors = [], []
        cur_pts: list[np.ndarray] = []
        cur_idx: list[int] = []
        last_res = None
        for res in st.residues:
            if res.resname.strip().upper() not in elements.AA3:
                continue
            ca = None
            for i in range(res.first, res.last):
                if st.atomname[i] == "CA" and mask[i]:
                    ca = i
                    break
            if ca is None:
                if len(cur_idx) > 1:
                    chunks.append(np.array(cur_pts))
                    cur_idx_arr = np.array(cur_idx)
                    colors.append(cur_idx_arr)
                cur_pts, cur_idx, last_res = [], [], None
                continue
            broken = (last_res is not None and
                      (res.chain != last_res.chain or
                       np.linalg.norm(st.xyz[ca] - cur_pts[-1]) > 4.6))
            if broken and len(cur_idx) > 1:
                chunks.append(np.array(cur_pts))
                colors.append(np.array(cur_idx))
                cur_pts, cur_idx = [], []
            elif broken:
                cur_pts, cur_idx = [], []
            cur_pts.append(st.xyz[ca])
            cur_idx.append(ca)
            last_res = res
        if len(cur_idx) > 1:
            chunks.append(np.array(cur_pts))
            colors.append(np.array(cur_idx))
        return chunks, colors

    def _trace(self, idx, style, radius: float = 0.4,
               ribbon: bool = False) -> vtk.vtkActor | None:
        st = self.st
        chunks, idx_chunks = self._ca_chunks(idx)
        if not chunks:
            return None
        cols = [atom_colors(st, ic, style.color_mode, self.model, style.uniform)
                for ic in idx_chunks]
        pd = polyline_polydata(chunks, cols)
        src = pd
        if style.smooth:
            spline = vtk.vtkSplineFilter()
            spline.SetInputData(pd)
            spline.SetSubdivideToLength()
            spline.SetLength(0.55)
            spline.Update()
            src = spline.GetOutput()
        if ribbon:
            rib = vtk.vtkRibbonFilter()
            rib.SetInputData(src)
            rib.SetWidth(1.05 * style.scale)
            rib.SetAngle(0)
            rib.UseDefaultNormalOn()
            rib.SetDefaultNormal(0, 0, 1)
            rib.Update()
            out_port = rib.GetOutputPort()
            mp = vtk.vtkPolyDataMapper()
            mp.SetInputConnection(out_port)
        elif radius <= 0:
            mp = vtk.vtkPolyDataMapper()
            mp.SetInputData(src)
        else:
            tube = vtk.vtkTubeFilter()
            tube.SetInputData(src)
            tube.SetRadius(radius)
            tube.SetNumberOfSides(12)
            tube.CappingOn()
            tube.Update()
            mp = vtk.vtkPolyDataMapper()
            mp.SetInputConnection(tube.GetOutputPort())
        mp.SetColorModeToDirectScalars()
        ac = vtk.vtkActor()
        ac.SetMapper(mp)
        p = ac.GetProperty()
        p.SetOpacity(style.opacity)
        p.SetLineWidth(2.2)
        p.SetRenderLinesAsTubes(True)
        p.SetSpecular(style.specular)
        p.SetSpecularPower(24)
        p.SetAmbient(0.22)
        p.SetDiffuse(0.85)
        return ac

    def _surface(self, idx, style) -> vtk.vtkActor | None:
        """van-der-Waals-plus-probe surface from a nearest-atom distance field.

        The cost is set by the grid, not the atom count, so this stays usable
        for a whole solvated system; the grid spacing is relaxed automatically
        if the box is large.
        """
        st = self.st
        if len(idx) == 0:
            return None
        try:
            from scipy.spatial import cKDTree
        except ImportError:
            return self._spheres(idx, style, scale=1.0)
        xyz = st.xyz[idx]
        radii = np.array([elements.vdw_radius(int(z)) for z in st.anum[idx]])
        probe = float(style.surface_probe)
        pad = radii.max() + probe + 1.0
        lo = xyz.min(axis=0) - pad
        hi = xyz.max(axis=0) + pad
        h = float(np.clip(style.surface_resolution, 0.35, 3.0))
        dims = np.maximum(8, np.ceil((hi - lo) / h).astype(int) + 1)
        while int(np.prod(dims)) > style.surface_max_points:
            h *= 1.25
            dims = np.maximum(8, np.ceil((hi - lo) / h).astype(int) + 1)
        axes = [lo[k] + np.arange(dims[k]) * h for k in range(3)]
        gx, gy, gz = np.meshgrid(*axes, indexing="ij")
        grid = np.column_stack([gx.ravel(), gy.ravel(), gz.ravel()])
        tree = cKDTree(xyz)
        dist, near = tree.query(grid, k=1,
                                distance_upper_bound=float(pad + 2.0))
        near = np.clip(near, 0, len(xyz) - 1)
        field = (radii[near] + probe) - np.where(np.isfinite(dist), dist,
                                                1e3)
        img = vtk.vtkImageData()
        img.SetDimensions(int(dims[0]), int(dims[1]), int(dims[2]))
        img.SetOrigin(*[float(x) for x in lo])
        img.SetSpacing(h, h, h)
        arr = nps.numpy_to_vtk(np.ascontiguousarray(
            field.reshape(tuple(dims)).ravel(order="F"), dtype=np.float32),
            deep=True)
        arr.SetName("field")
        img.GetPointData().SetScalars(arr)
        surf = vtk.vtkFlyingEdges3D()
        surf.SetInputData(img)
        surf.SetValue(0, 0.0)
        surf.ComputeNormalsOn()
        smooth = vtk.vtkWindowedSincPolyDataFilter()
        smooth.SetInputConnection(surf.GetOutputPort())
        smooth.SetNumberOfIterations(15)
        smooth.BoundarySmoothingOff()
        smooth.FeatureEdgeSmoothingOff()
        smooth.NonManifoldSmoothingOn()
        smooth.NormalizeCoordinatesOn()
        smooth.Update()
        out = smooth.GetOutput()
        if out.GetNumberOfPoints() == 0:
            return None
        normals = vtk.vtkPolyDataNormals()
        normals.SetInputData(out)
        normals.SplittingOff()
        normals.ConsistencyOn()
        normals.Update()
        out = normals.GetOutput()
        verts = nps.vtk_to_numpy(out.GetPoints().GetData())
        _, nn = tree.query(verts, k=1)
        nn = np.clip(nn, 0, len(xyz) - 1)
        rgb_atoms = atom_colors(st, idx, style.color_mode, self.model,
                                style.uniform)
        out.GetPointData().SetScalars(_colors(rgb_atoms[nn]))
        mp = vtk.vtkPolyDataMapper()
        mp.SetInputData(out)
        mp.SetColorModeToDirectScalars()
        ac = vtk.vtkActor()
        ac.SetMapper(mp)
        p = ac.GetProperty()
        p.SetOpacity(style.opacity)
        p.SetSpecular(0.28)
        p.SetSpecularPower(30)
        p.SetAmbient(0.24)
        p.SetDiffuse(0.8)
        return ac


# --------------------------------------------------------------------------
# simple geometry actors
# --------------------------------------------------------------------------
def box_actor(box: np.ndarray, color=(0.35, 0.42, 0.58),
              width: float = 1.4, center=None) -> vtk.vtkActor:
    """Wireframe of the periodic cell.

    Desmond writes coordinates in a cell centred on the origin; ``center``
    overrides that for files that use a different convention.
    """
    a, b, c = box[0], box[1], box[2]
    origin = np.zeros(3) if center is None else np.asarray(center, dtype=float)
    corners = []
    for i in (-0.5, 0.5):
        for j in (-0.5, 0.5):
            for k in (-0.5, 0.5):
                corners.append(origin + i * a + j * b + k * c)
    corners = np.array(corners)
    edges = [(0, 1), (0, 2), (0, 4), (1, 3), (1, 5), (2, 3), (2, 6),
             (3, 7), (4, 5), (4, 6), (5, 7), (6, 7)]
    pd = line_polydata(corners, np.array(edges))
    mp = vtk.vtkPolyDataMapper()
    mp.SetInputData(pd)
    ac = vtk.vtkActor()
    ac.SetMapper(mp)
    p = ac.GetProperty()
    p.SetColor(*color)
    p.SetLineWidth(width)
    p.SetOpacity(0.85)
    p.LightingOff()
    return ac


def sphere_actor(center, radius: float, color, opacity: float = 1.0,
                 res: int = 24) -> vtk.vtkActor:
    src = vtk.vtkSphereSource()
    src.SetCenter(*[float(x) for x in center])
    src.SetRadius(float(radius))
    src.SetThetaResolution(res)
    src.SetPhiResolution(res)
    mp = vtk.vtkPolyDataMapper()
    mp.SetInputConnection(src.GetOutputPort())
    ac = vtk.vtkActor()
    ac.SetMapper(mp)
    p = ac.GetProperty()
    p.SetColor(*color)
    p.SetOpacity(opacity)
    p.SetSpecular(0.5)
    p.SetSpecularPower(40)
    ac._source = src
    return ac


def line_actor(p0, p1, color, width: float = 2.0, dashed: bool = False,
               opacity: float = 1.0) -> vtk.vtkActor:
    pd = line_polydata(np.array([p0, p1], dtype=float), np.array([[0, 1]]))
    mp = vtk.vtkPolyDataMapper()
    mp.SetInputData(pd)
    ac = vtk.vtkActor()
    ac.SetMapper(mp)
    p = ac.GetProperty()
    p.SetColor(*color)
    p.SetLineWidth(width)
    p.SetOpacity(opacity)
    p.LightingOff()
    if dashed:
        p.SetLineStipplePattern(0xF0F0)
        p.SetLineStippleRepeatFactor(2)
    return ac


def caption_actor(text: str, position, color=(1, 1, 1), size: int = 13,
                  bold: bool = False) -> vtk.vtkBillboardTextActor3D:
    ac = vtk.vtkBillboardTextActor3D()
    ac.SetInput(text)
    ac.SetPosition(*[float(x) for x in position])
    tp = ac.GetTextProperty()
    tp.SetFontSize(size)
    tp.SetColor(*color)
    tp.SetBold(bold)
    tp.SetJustificationToCentered()
    tp.SetVerticalJustificationToBottom()
    tp.SetShadow(True)
    return ac
