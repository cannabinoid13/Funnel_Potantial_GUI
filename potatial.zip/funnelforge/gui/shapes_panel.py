"""The Shapes tab: give the potential any form you like.

Two ways to describe a shape, as separate input paths:

* **Lathe** - you type a profile ``r(z)`` and it is turned around the funnel
  axis into a solid.  The solvent-facing end is closed for you.
* **Expression** - you type the complete energy expression and the potential is
  exactly that, with nothing added.

Plus two primitives (sphere, axial slab) and, on every term, an optional
region so different stretches of the axis can carry different potentials.
"""

from __future__ import annotations

import numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets

import matplotlib
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as Canvas
from matplotlib.figure import Figure

from ..core.terms import (Term, make_term, KINDS, KIND_LABELS, MODES, CAPS,
                          PROFILE_PRESETS, expression_variables, emit_term,
                          EmitCtx)
from ..core.mexpr import (check_expression, functions_reference, MExprError,
                          NOT_IN_DESMOND)
from ..core.asl import parse_selection, SelectionError, describe_indices
from . import theme
from .widgets import (ParamRow, IntRow, TextRow, ComboRow, Readout, group,
                      vbox, hline, scroll_area)


class ProfilePreview(QtWidgets.QWidget):
    """The lathe view: profile on top, the revolved silhouette mirrored."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.fig = Figure(figsize=(4, 1.9), dpi=100, facecolor=theme.BG1,
                          layout="constrained")
        self.canvas = Canvas(self.fig)
        self.ax = self.fig.add_subplot(111)
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.canvas)
        self.setMinimumHeight(150)

    def refresh(self, model, term: Term):
        ax = self.ax
        ax.clear()
        ax.set_facecolor(theme.BG1)
        for sp in ax.spines.values():
            sp.set_color(theme.BG3)
        ax.tick_params(colors=theme.FG1, labelsize=7, length=3)
        ax.grid(True, color=theme.BG3, linewidth=0.5, alpha=0.6)
        ax.set_xlabel("z  (Å)", color=theme.FG1, fontsize=7.5)
        ax.set_ylabel("r  (Å)", color=theme.FG1, fontsize=7.5)
        if model is None:
            self.canvas.draw_idle()
            return
        zs = np.linspace(term.z_lo, term.z_hi, 300)
        try:
            r = model.term_profile(term, zs)
        except Exception:
            r = None
        if r is None or not np.any(np.isfinite(r)):
            ax.text(0.5, 0.5, "the profile does not evaluate",
                    transform=ax.transAxes, ha="center", color=theme.BAD,
                    fontsize=8)
            self.canvas.draw_idle()
            return
        r = np.where(np.isfinite(r), r, np.nan)
        col = tuple(term.color)
        ax.fill_between(zs, -r, r, color=col, alpha=0.22, label="solid of "
                        "revolution")
        ax.plot(zs, r, color=col, lw=1.6)
        ax.plot(zs, -r, color=col, lw=1.6, alpha=0.6)
        ax.axhline(0, color=theme.FG2, lw=0.8, ls=":")
        if term.cap in ("solvent", "both"):
            rr = float(np.nan_to_num(r[-1]))
            ax.plot([term.z_hi, term.z_hi], [-rr, rr], color=theme.BAD,
                    lw=2.0, label="closed end")
        if term.cap in ("pocket", "both"):
            rr = float(np.nan_to_num(r[0]))
            ax.plot([term.z_lo, term.z_lo], [-rr, rr], color=theme.ACCENT,
                    lw=2.0)
        if term.region.enabled:
            ax.axvspan(term.region.z_lo, term.region.z_hi, color=theme.WARN,
                       alpha=0.10, label="active region")
        try:
            z0, rho0 = model.cv_of_ligand()
            ax.plot([z0], [rho0], "o", ms=6, mfc=theme.LIGAND, mec="white",
                    mew=1.0, label="ligand")
        except Exception:
            pass
        leg = ax.legend(loc="upper right", fontsize=6.5, frameon=True,
                        facecolor=theme.BG2, edgecolor=theme.BG3,
                        labelcolor=theme.FG1)
        leg.get_frame().set_alpha(0.85)
        self.canvas.draw_idle()


class PalettePopup(QtWidgets.QDialog):
    """Insertable variables and the authoritative Desmond function list."""

    def __init__(self, spec, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Desmond M-expression reference")
        self.resize(720, 560)
        self.chosen = ""
        lay = QtWidgets.QVBoxLayout(self)
        tabs = QtWidgets.QTabWidget()
        lay.addWidget(tabs)

        var_tree = QtWidgets.QTreeWidget()
        var_tree.setHeaderLabels(["variable", "meaning"])
        var_tree.setColumnWidth(0, 130)
        for name, doc in expression_variables(spec):
            QtWidgets.QTreeWidgetItem(var_tree, [name, doc])
        tabs.addTab(var_tree, "variables")

        fn_tree = QtWidgets.QTreeWidget()
        fn_tree.setHeaderLabels(["function", "what it does"])
        fn_tree.setColumnWidth(0, 190)
        for sig, doc in functions_reference():
            QtWidgets.QTreeWidgetItem(fn_tree, [sig, doc])
        tabs.addTab(fn_tree, "functions Desmond has")

        no_tree = QtWidgets.QTreeWidget()
        no_tree.setHeaderLabels(["not available", "write this instead"])
        no_tree.setColumnWidth(0, 130)
        for name, fix in sorted(NOT_IN_DESMOND.items()):
            QtWidgets.QTreeWidgetItem(no_tree, [name + "()", fix])
        tabs.addTab(no_tree, "functions it does not")

        notes = QtWidgets.QTextBrowser()
        notes.setHtml("""
<h3>Rules that bite</h3>
<ul>
<li><code>^</code> raises to an <b>integer</b> power only. For anything else
use <code>pow(base, exponent)</code>, and note that <code>pow</code> needs a
<b>positive base</b>.</li>
<li><code>if c then a else b</code> takes the <b>positive</b> branch when
<code>c &gt; 0</code>. That is how a one-sided wall is written:
<code>if rho-R then rho-R else 0.0</code>.</li>
<li>There is no <code>abs</code>, <code>min</code> or <code>max</code>. Use
<code>x*sign(x)</code>, or the smooth <code>gibbs_min(T, array(a,b))</code> and
<code>gibbs_max(T, array(a,b))</code>.</li>
<li>Every value is an array; a scalar is an array of length 1 and a vector is
an array of length 3. <code>*</code> is element-wise, so use
<code>dot(a,b)</code> for an inner product.</li>
<li>Subtraction does <b>not</b> apply the minimum image. Distances between
distant groups go through <code>min_image(...)</code>.</li>
<li>Write <code>0.0-(x^2)</code> rather than <code>-x^2</code> so no reader has
to guess the precedence.</li>
<li>Your expression must evaluate to a single number: the energy in kcal/mol.
It should be zero where you want no force.</li>
</ul>""")
        tabs.addTab(notes, "how to write it")

        row = QtWidgets.QHBoxLayout()
        insert = QtWidgets.QPushButton("Insert selected")
        insert.setProperty("accent", "true")
        close = QtWidgets.QPushButton("Close")
        row.addStretch(1)
        row.addWidget(insert)
        row.addWidget(close)
        lay.addLayout(row)
        close.clicked.connect(self.reject)

        def take():
            for tree in (var_tree, fn_tree):
                it = tree.currentItem()
                if it is not None and tree.hasFocus():
                    self.chosen = it.text(0)
                    self.accept()
                    return
            it = var_tree.currentItem()
            if it is not None:
                self.chosen = it.text(0)
                self.accept()
        insert.clicked.connect(take)
        var_tree.itemDoubleClicked.connect(
            lambda it, c: (setattr(self, "chosen", it.text(0)), self.accept()))
        fn_tree.itemDoubleClicked.connect(
            lambda it, c: (setattr(self, "chosen", it.text(0)), self.accept()))


class ShapesPanel(QtWidgets.QWidget):
    """Term list plus the per-kind editors."""

    changed = QtCore.pyqtSignal()

    def __init__(self, window, parent=None):
        super().__init__(parent)
        self.w = window
        self._loading = False
        self._current: Term | None = None

        # ---------------- built-in funnel switch
        self.use_funnel = QtWidgets.QCheckBox(
            "Use the built-in funnel (cone + cylinder + axial walls)")
        self.use_funnel.setChecked(True)
        self.use_funnel.setToolTip(
            "Turn this off to build the restraint purely out of the terms "
            "below. The metadynamics CV stays the axial coordinate z either "
            "way.")
        self.use_funnel.toggled.connect(self._funnel_toggled)
        self.add_funnel_btn = QtWidgets.QPushButton(
            "Add a funnel and fit it to the pocket")
        self.add_funnel_btn.setProperty("accent", "true")
        self.add_funnel_btn.setToolTip(
            "An imported job with no .pot has no funnel; this creates one, "
            "fitted to the solvent-accessible channel out of the pocket. "
            "Every number stays editable afterwards.")
        self.add_funnel_btn.clicked.connect(self.add_funnel)
        self.funnel_status = QtWidgets.QLabel("-")
        self.funnel_status.setWordWrap(True)
        self.funnel_status.setProperty("dim", "true")
        self.f_z_cc = ParamRow("z_cc", 0.0, -200, 200, 0.25, 4, "Å")
        self.f_r_cyl = ParamRow("r_cyl", 0.0, 0.0, 60, 0.1, 4, "Å")
        self.f_cone = ParamRow("cone angle", 0.0, 0.0, 80, 0.25, 4, "°")
        self.f_slope = ParamRow("cone slope", 0.0, 0.0, 6, 0.01, 6, "",
                                slider=False)
        self.f_z_min = ParamRow("z_min", 0.0, -200, 200, 0.25, 4, "Å")
        self.f_z_max = ParamRow("z_max", 0.0, -200, 200, 0.25, 4, "Å")
        self.f_k_rad = ParamRow("k_rad", 25.0, 0.0, 2000, 1.0, 4, "")
        self.f_k_z = ParamRow("k_z", 50.0, 0.0, 2000, 1.0, 4, "")
        self.f_origin = ParamRow("origin", 0.0, -200, 200, 0.05, 6, "Å")
        self.f_lat1 = ParamRow("origin e1", 0.0, -80, 80, 0.05, 6, "Å",
                               tip="Slides the whole funnel across the axis. "
                                   "Needs a frame reference group.")
        self.f_lat2 = ParamRow("origin e2", 0.0, -80, 80, 0.05, 6, "Å")
        self.f_tilt = ParamRow("axis tilt", 0.0, 0.0, 60.0, 0.25, 4, "°",
                               tip="Turns the biased coordinate away from the "
                                   "CORE→SITE direction. Needs a frame "
                                   "reference group.")
        self.f_azim = ParamRow("tilt towards", 0.0, -180.0, 180.0, 1.0, 4, "°")
        for row in (self.f_z_cc, self.f_r_cyl, self.f_z_min, self.f_z_max,
                    self.f_k_rad, self.f_k_z):
            row.valueChanged.connect(self._push_funnel)
        self.f_cone.valueChanged.connect(self._funnel_angle)
        self.f_slope.valueChanged.connect(self._funnel_slope)
        self.f_origin.valueChanged.connect(self._funnel_origin)
        self.f_lat1.valueChanged.connect(self._push_funnel)
        self.f_lat2.valueChanged.connect(self._push_funnel)
        self.f_tilt.valueChanged.connect(self._push_funnel)
        self.f_azim.valueChanged.connect(self._push_funnel)
        self.funnel_rows = QtWidgets.QWidget()
        frl = QtWidgets.QVBoxLayout(self.funnel_rows)
        frl.setContentsMargins(0, 0, 0, 0)
        frl.setSpacing(3)
        for wdg in (self.f_z_min, self.f_z_cc, self.f_z_max, self.f_r_cyl,
                    self.f_cone, self.f_slope, self.f_k_rad, self.f_k_z,
                    self.f_origin, self.f_lat1, self.f_lat2, self.f_tilt,
                    self.f_azim):
            frl.addWidget(wdg)

        # ---------------- body-fixed frame reference
        self.fref_info = QtWidgets.QLabel("-")
        self.fref_info.setWordWrap(True)
        self.fref_expr = QtWidgets.QLineEdit()
        self.fref_expr.setPlaceholderText("chain A and resnum 133 and backbone")
        fref_apply = QtWidgets.QPushButton("Apply")
        fref_apply.clicked.connect(self._apply_fref)
        fref_auto = QtWidgets.QPushButton("Pick automatically")
        fref_auto.setProperty("accent", "true")
        fref_auto.clicked.connect(self._auto_fref)
        fref_clear = QtWidgets.QPushButton("Clear")
        fref_clear.clicked.connect(self._clear_fref)
        frow = QtWidgets.QHBoxLayout()
        frow.addWidget(self.fref_expr, 1)
        frow.addWidget(fref_apply)
        frow2 = QtWidgets.QHBoxLayout()
        frow2.addWidget(fref_auto)
        frow2.addWidget(fref_clear)
        frow2.addStretch(1)

        # ---------------- term table
        self.table = QtWidgets.QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["", "term", "kind", "acts on", "k", "V₀"])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QtWidgets.QTableWidget.SelectRows)
        self.table.setSelectionMode(QtWidgets.QTableWidget.SingleSelection)
        self.table.horizontalHeader().setSectionResizeMode(
            1, QtWidgets.QHeaderView.Stretch)
        self.table.setColumnWidth(0, 26)
        self.table.setColumnWidth(2, 74)
        self.table.setColumnWidth(3, 74)
        self.table.setColumnWidth(4, 58)
        self.table.setColumnWidth(5, 62)
        self.table.setMinimumHeight(150)
        self.table.itemSelectionChanged.connect(self._selection_changed)
        self.table.itemChanged.connect(self._table_edited)

        add_btn = QtWidgets.QToolButton()
        add_btn.setText("Add  ▾")
        add_btn.setPopupMode(QtWidgets.QToolButton.InstantPopup)
        menu = QtWidgets.QMenu(add_btn)
        for kind in KINDS:
            act = menu.addAction(KIND_LABELS[kind])
            act.triggered.connect(lambda checked=False, k=kind: self._add(k))
        add_btn.setMenu(menu)
        dup = QtWidgets.QPushButton("Duplicate")
        rem = QtWidgets.QPushButton("Remove")
        up = QtWidgets.QPushButton("↑")
        down = QtWidgets.QPushButton("↓")
        up.setMaximumWidth(32)
        down.setMaximumWidth(32)
        dup.clicked.connect(self._duplicate)
        rem.clicked.connect(self._remove)
        up.clicked.connect(lambda: self._move(-1))
        down.clicked.connect(lambda: self._move(+1))
        bar = QtWidgets.QHBoxLayout()
        for wdg in (add_btn, dup, rem, up, down):
            bar.addWidget(wdg)
        bar.addStretch(1)

        # ---------------- shared editor rows
        self.label = TextRow("name", "", tip="Only used in the interface and "
                                             "as a comment in the .pot.")
        self.label.editingFinished.connect(self._push)
        self.var = TextRow("variable", "", tip="Prefix of the generated "
                                               "M-expression variables.")
        self.var.editingFinished.connect(self._push)
        self.mode = ComboRow("action", ["confine  ·  keep inside",
                                        "exclude  ·  keep outside"],
                             tip="A confining wall grows outside the shape; an "
                                 "excluding wall grows inside it.")
        self.mode.currentChanged.connect(self._push)
        self.k = ParamRow("force k", 25.0, 0.0, 2000.0, 1.0, 4, "",
                          tip="kcal/mol/Å^exponent")
        self.exponent = IntRow("exponent", 2, 1, 8,
                               tip="2 is harmonic; 4 gives a softer start and "
                                   "a harder finish. Desmond's ^ needs an "
                                   "integer.")
        self.offset = ParamRow("slack", 0.0, 0.0, 20.0, 0.1, 3, "Å",
                               tip="Extra distance before the wall engages.")
        self.color_btn = QtWidgets.QPushButton("colour")
        self.color_btn.clicked.connect(self._pick_colour)
        for row in (self.k, self.offset):
            row.valueChanged.connect(self._push)
        self.exponent.valueChanged.connect(self._push)

        self.target = ComboRow("acts on", ["the ligand (biased particle)",
                                            "another atom group"])
        self.target.currentChanged.connect(self._target_changed)
        self.target_expr = QtWidgets.QLineEdit()
        self.target_expr.setPlaceholderText("chain A and resnum 197 and name OH")
        tgt_apply = QtWidgets.QPushButton("Apply")
        tgt_apply.clicked.connect(self._apply_target)
        self.target_info = QtWidgets.QLabel("-")
        self.target_info.setProperty("dim", "true")
        self.target_info.setWordWrap(True)
        trow = QtWidgets.QHBoxLayout()
        trow.addWidget(self.target_expr, 1)
        trow.addWidget(tgt_apply)

        # ---------------- placement (precise, manual)
        self.pos_axial = ParamRow("along axis", 0.0, -200.0, 200.0, 0.1, 4, "Å",
                                  tip="Slides the whole shape along the funnel "
                                      "axis, keeping its size.")
        self.pos_axial.valueChanged.connect(self._push_position)
        self.pos_e1 = ParamRow("across e1", 0.0, -80.0, 80.0, 0.05, 4, "Å",
                               tip="Sideways placement in the body-fixed "
                                   "frame; needs a frame reference group.")
        self.pos_e2 = ParamRow("across e2", 0.0, -80.0, 80.0, 0.05, 4, "Å")
        for row in (self.pos_e1, self.pos_e2):
            row.valueChanged.connect(self._push_position)
        self.tilt = ParamRow("tilt", 0.0, 0.0, 80.0, 0.5, 4, "°",
                             tip="Angle between this shape's own axis and the "
                                 "funnel axis. Needs a frame reference group, "
                                 "because the direction has to be tied to the "
                                 "protein.")
        self.azimuth = ParamRow("tilt towards", 0.0, -180.0, 180.0, 1.0, 4, "°",
                                tip="Which way it leans, measured in the "
                                    "body-fixed (e1, e2) plane.")
        for row in (self.tilt, self.azimuth):
            row.valueChanged.connect(self._push_position)
        self.pos_info = QtWidgets.QLabel("-")
        self.pos_info.setWordWrap(True)
        self.pos_info.setProperty("dim", "true")
        self.handles_here = QtWidgets.QCheckBox(
            "Show drag handles for this shape in the 3-D view")
        self.handles_here.setChecked(True)
        self.handles_here.setToolTip(
            "Handles appear on the selected shape only, so the view stays "
            "readable. Hold Shift, Ctrl or both while dragging for 5x, 20x "
            "and 100x finer control.")
        self.handles_here.toggled.connect(self._handles_toggled)

        # ---------------- how the potential varies
        self.own_levels = QtWidgets.QCheckBox(
            "Use my own contour levels for this shape")
        self.own_levels.setToolTip(
            "Terms can differ wildly in stiffness; give a soft term its own "
            "levels so its gradation is still visible.")
        self.own_levels.toggled.connect(self._push_levels)
        self.level_mode = ComboRow("levels are", ["distances outside the wall",
                                                  "energies"])
        self.level_mode.currentChanged.connect(self._push_levels)
        self.level_values = TextRow("levels", "0.75, 1.5, 2.25",
                                    tip="Å for distances, kcal/mol for "
                                        "energies.")
        self.level_values.editingFinished.connect(self._push_levels)
        self.gradation = Readout([("g05", "0.5 Å out"), ("g10", "1 Å out"),
                                  ("g20", "2 Å out"), ("g30", "3 Å out")])

        # ---------------- lathe editor
        self.preset = ComboRow("preset", ["—"] + [p[0] for p in PROFILE_PRESETS],
                               tip="Ready-made profiles; pick one and edit it.")
        self.preset.currentChanged.connect(self._preset_chosen)
        self.profile = QtWidgets.QLineEdit()
        self.profile.setFont(QtGui.QFont("DejaVu Sans Mono", 9))
        self.profile.setPlaceholderText("r(z), e.g. 4.0+(26.0-z)*0.6")
        self.profile.editingFinished.connect(self._push)
        pal_btn = QtWidgets.QPushButton("reference…")
        pal_btn.clicked.connect(self._palette)
        prow = QtWidgets.QHBoxLayout()
        prow.addWidget(QtWidgets.QLabel("r(z) ="))
        prow.addWidget(self.profile, 1)
        prow.addWidget(pal_btn)
        self.profile_status = QtWidgets.QLabel("")
        self.profile_status.setWordWrap(True)
        self.z_lo = ParamRow("z from", -4.0, -200.0, 200.0, 0.5, 3, "Å")
        self.z_hi = ParamRow("z to", 34.0, -200.0, 200.0, 0.5, 3, "Å")
        for row in (self.z_lo, self.z_hi):
            row.valueChanged.connect(self._push)
        self.cap = ComboRow("close the ends", [
            "solvent side only", "pocket side only", "both ends", "leave open"],
            tip="A dissociating ligand escapes through the solvent-facing end, "
                "so that one is closed by default.")
        self.cap.currentChanged.connect(self._push)
        self.k_cap = ParamRow("end-wall k", 50.0, 0.0, 2000.0, 1.0, 3, "")
        self.k_cap.valueChanged.connect(self._push)
        self.preview = ProfilePreview()

        # ---------------- sphere editor
        self.center_mode = ComboRow("centre", ["a point on the funnel axis",
                                                "the COM of an atom group"])
        self.center_mode.currentChanged.connect(self._push)
        self.center_z = ParamRow("centre z", 0.0, -200.0, 200.0, 0.5, 3, "Å")
        self.center_z.valueChanged.connect(self._push)
        self.radius = ParamRow("radius", 10.0, 0.1, 200.0, 0.5, 3, "Å")
        self.radius.valueChanged.connect(self._push)
        self.center_expr = QtWidgets.QLineEdit()
        self.center_expr.setPlaceholderText("chain A and resnum 197 and name OH")
        cen_apply = QtWidgets.QPushButton("Apply")
        cen_apply.clicked.connect(self._apply_center)
        self.center_info = QtWidgets.QLabel("-")
        self.center_info.setProperty("dim", "true")
        crow = QtWidgets.QHBoxLayout()
        crow.addWidget(self.center_expr, 1)
        crow.addWidget(cen_apply)

        # ---------------- expression editor
        self.expr = QtWidgets.QPlainTextEdit()
        self.expr.setFont(QtGui.QFont("DejaVu Sans Mono", 9))
        self.expr.setMinimumHeight(96)
        self.expr.setPlaceholderText(
            "energy in kcal/mol, e.g.\n"
            "0.5*30.0*(if rho-8.0 then rho-8.0 else 0.0)^2")
        self.expr.textChanged.connect(self._expr_changed)
        self.expr_status = QtWidgets.QLabel("")
        self.expr_status.setWordWrap(True)
        self.expr_status.setTextFormat(QtCore.Qt.RichText)
        expr_pal = QtWidgets.QPushButton("variables and functions…")
        expr_pal.clicked.connect(self._palette)
        expr_examples = QtWidgets.QPushButton("examples…")
        expr_examples.clicked.connect(self._examples)
        erow = QtWidgets.QHBoxLayout()
        erow.addWidget(expr_pal)
        erow.addWidget(expr_examples)
        erow.addStretch(1)

        # ---------------- region
        self.region_on = QtWidgets.QCheckBox(
            "Only act between two points on the axis")
        self.region_on.toggled.connect(self._push)
        self.r_lo = ParamRow("from z", 0.0, -200.0, 200.0, 0.5, 3, "Å")
        self.r_hi = ParamRow("to z", 30.0, -200.0, 200.0, 0.5, 3, "Å")
        self.taper = ParamRow("taper", 2.0, 0.0, 20.0, 0.25, 3, "Å",
                              tip="Width of the smooth switch at each edge. "
                                  "Zero makes a hard gate, which jumps the "
                                  "energy and kicks the integrator.\n\n"
                                  "The window is read on the z of whatever "
                                  "the term acts on, so a term on the ligand "
                                  "is switched by the run's own CV.")
        for row in (self.r_lo, self.r_hi, self.taper):
            row.valueChanged.connect(self._push)
        self.region_note = QtWidgets.QLabel("")
        self.region_note.setWordWrap(True)

        self.readout = Readout([("v0", "V at t = 0"), ("kind", "kind"),
                                ("r_at_lig", "boundary at ligand z"),
                                ("switch", "switch at ligand z")])
        self.code = QtWidgets.QPlainTextEdit()
        self.code.setReadOnly(True)
        self.code.setFont(QtGui.QFont("DejaVu Sans Mono", 8))
        self.code.setMaximumHeight(150)

        # ---------------- assemble the per-kind stack
        self.lathe_box = group("Lathe profile", self.preset, prow,
                               self.profile_status, self.z_lo, self.z_hi,
                               self.cap, self.k_cap, self.preview)
        self.sphere_box = group("Sphere", self.center_mode, self.center_z,
                                crow, self.center_info, self.radius)
        self.expr_box = group("Energy expression", self.expr, erow,
                              self.expr_status)
        self.stack = QtWidgets.QWidget()
        slay = QtWidgets.QVBoxLayout(self.stack)
        slay.setContentsMargins(0, 0, 0, 0)
        slay.setSpacing(4)
        for b in (self.lathe_box, self.sphere_box, self.expr_box):
            slay.addWidget(b)

        self.editor = vbox(
            group("Term", self.label, self.var, self.color_btn),
            group("Placement", self.pos_axial, self.pos_e1, self.pos_e2,
                  hline(), self.tilt, self.azimuth,
                  self.handles_here, self.pos_info),
            group("Strength", self.mode, self.k, self.exponent, self.offset),
            group("Potential gradation", self.gradation, hline(),
                  self.own_levels, self.level_mode, self.level_values),
            group("Target", self.target, trow, self.target_info),
            self.stack,
            group("Region", self.region_on, self.r_lo, self.r_hi, self.taper,
                  self.region_note),
            group("This term right now", self.readout),
            group("Generated M-expression", self.code),
            None)

        inner = vbox(
            group("Built-in funnel", self.use_funnel, self.add_funnel_btn,
                  self.funnel_rows, self.funnel_status),
            group("Body-fixed frame for off-axis placement", self.fref_info,
                  frow, frow2),
            group("Potential terms", self.table, bar),
            self.editor)
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(scroll_area(inner))
        self._set_editor_enabled(False)

    # ------------------------------------------------------------------
    @property
    def terms(self) -> list:
        return self.w.job.spec.terms

    def _funnel_toggled(self, on: bool):
        if self._loading:
            return
        sp = self.w.job.spec
        model = self.w.job.model
        if on and model is not None and model.funnel_is_degenerate():
            self.add_funnel()
            return
        sp.funnel_enabled = on
        self.changed.emit()

    def add_funnel(self):
        """Create the built-in funnel where the imported job had none."""
        job = self.w.job
        model = job.model
        if model is None:
            QtWidgets.QMessageBox.information(
                self, "Add a funnel", "Load a structure first.")
            return
        sp = job.spec
        if not (sp.lig.indices and sp.site.indices and sp.core.indices):
            QtWidgets.QMessageBox.information(
                self, "Add a funnel",
                "The funnel axis comes from the ligand, SITE and CORE groups, "
                "so those have to exist first.\n\nUse Edit ▸ Suggest CV "
                "groups from the structure (Ctrl+G), or set them in the "
                "Groups tab.")
            return
        if sp.funnel_enabled and not model.funnel_is_degenerate():
            ans = QtWidgets.QMessageBox.question(
                self, "Refit the funnel?",
                "A funnel is already defined. Refit it to the pocket and "
                "replace the current geometry?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No)
            if ans != QtWidgets.QMessageBox.Yes:
                return
        self.w.push_undo()
        rep = model.initialise_funnel(cutoff=job.cutoff_radius)
        self.changed.emit()
        self.w.statusBar().showMessage(
            f"funnel fitted: z {rep['z_min']:.2f} … {rep['z_max']:.2f} Å, "
            f"cone {rep['cone_deg']:.2f}°, clearance "
            f"{rep['clearance']:.2f} Å", 8000)

    def _push_funnel(self, *_):
        if self._loading:
            return
        sp = self.w.job.spec
        sender = self.sender()
        wants_frame = bool(self.f_lat1.value() or self.f_lat2.value()
                           or self.f_tilt.value())
        if wants_frame and not self.ensure_frame_ref(
                "the funnel offset and tilt"):
            self._loading = True
            self.f_lat1.setValue(sp.origin_lat1)
            self.f_lat2.setValue(sp.origin_lat2)
            self.f_tilt.setValue(sp.axis_tilt_deg)
            self._loading = False
            return
        for attr, row in (("z_cc", self.f_z_cc), ("r_cyl", self.f_r_cyl),
                          ("z_min", self.f_z_min), ("z_max", self.f_z_max),
                          ("k_rad", self.f_k_rad), ("k_z", self.f_k_z),
                          ("origin_lat1", self.f_lat1),
                          ("origin_lat2", self.f_lat2),
                          ("axis_tilt_deg", self.f_tilt),
                          ("axis_azimuth_deg", self.f_azim)):
            if sender is not None and sender is not row:
                continue
            v = row.value()
            if getattr(sp, attr) != v:
                setattr(sp, attr, v)
                sp.literals.pop(attr, None)
        self.changed.emit()

    def _funnel_angle(self, deg):
        if self._loading:
            return
        sp = self.w.job.spec
        sp.set_cone_angle_deg(deg)
        sp.literals.pop("cone_slope", None)
        self._loading = True
        self.f_slope.setValue(sp.cone_slope)
        self._loading = False
        self.changed.emit()

    def _funnel_slope(self, slope):
        if self._loading:
            return
        sp = self.w.job.spec
        sp.cone_slope = slope
        sp.literals.pop("cone_slope", None)
        self._loading = True
        self.f_cone.setValue(sp.cone_angle_deg)
        self._loading = False
        self.changed.emit()

    def _funnel_origin(self, value):
        if self._loading:
            return
        model = self.w.job.model
        if model is not None:
            model.set_origin_offset_A(value)
        self.changed.emit()

    # ------------------------------------------------------------------
    # body-fixed frame reference
    # ------------------------------------------------------------------
    def _apply_fref(self):
        st = self.w.job.structure
        if st is None:
            return
        try:
            idx = parse_selection(self.fref_expr.text(), st)
        except SelectionError as exc:
            QtWidgets.QMessageBox.warning(self, "Selection", str(exc))
            return
        if len(idx) == 0:
            QtWidgets.QMessageBox.information(self, "Selection",
                                              "That matches no atoms.")
            return
        sp = self.w.job.spec
        sp.frame_ref.indices = sorted(int(i) + 1 for i in idx)
        sp.frame_ref.expression = self.fref_expr.text()
        self.changed.emit()

    def _auto_fref(self):
        job = self.w.job
        if job.structure is None or job.model is None:
            return
        from ..core.autobuild import suggest_frame_reference
        idx = suggest_frame_reference(job.structure, job.spec, job.model)
        if not idx:
            QtWidgets.QMessageBox.information(
                self, "Frame reference",
                "No buried group far enough from the axis was found; pick one "
                "by hand.")
            return
        self.w.push_undo()
        job.spec.frame_ref.indices = idx
        self.changed.emit()

    def _clear_fref(self):
        sp = self.w.job.spec
        if sp.uses_perp_frame():
            QtWidgets.QMessageBox.warning(
                self, "Frame reference",
                "Something is still placed off the axis. Set those offsets "
                "back to zero first, otherwise the potential would refer to "
                "e1 and e2 without defining them.")
            return
        sp.frame_ref.indices = []
        self.changed.emit()

    # ------------------------------------------------------------------
    # placement and gradation
    # ------------------------------------------------------------------
    def ensure_frame_ref(self, why: str = "off-axis placement") -> bool:
        """A body-fixed reference is needed for sideways and tilted work.

        Rather than greying the controls out, the reference is created the
        moment something needs it, and the user is told which group was used.
        """
        job = self.w.job
        sp = job.spec
        if sp.has_frame_ref:
            return True
        if job.structure is None or job.model is None:
            return False
        from ..core.autobuild import suggest_frame_reference
        idx = suggest_frame_reference(job.structure, sp, job.model)
        if not idx:
            QtWidgets.QMessageBox.warning(
                self, "No reference group",
                "Sideways placement and tilt need a second, body-fixed "
                "direction, and no buried group far enough from the axis was "
                "found automatically.\n\nPick one by hand under \"Body-fixed "
                "frame\" and try again.")
            return False
        sp.frame_ref.indices = idx
        job.model.invalidate()
        names = ", ".join(job.structure.residue_signature(
            sp.frame_ref.idx0())[:3])
        self.w.statusBar().showMessage(
            f"body-fixed frame set from {names} so {why} can be written into "
            "the potential", 8000)
        return True

    def _push_position(self, *_):
        t = self._current
        if t is None or self._loading:
            return
        wants_frame = bool(self.pos_e1.value() or self.pos_e2.value()
                           or self.tilt.value())
        if wants_frame and not self.ensure_frame_ref(
                "the tilt and the sideways offsets"):
            self._loading = True
            self.pos_e1.setValue(t.offset_e1)
            self.pos_e2.setValue(t.offset_e2)
            self.tilt.setValue(t.tilt_deg)
            self._loading = False
            return
        sender = self.sender()
        if sender is None or sender is self.pos_axial:
            t.move_axially(self.pos_axial.value())
        for attr, row in (("offset_e1", self.pos_e1), ("offset_e2", self.pos_e2),
                          ("tilt_deg", self.tilt), ("azimuth_deg", self.azimuth)):
            if sender is None or sender is row:
                setattr(t, attr, row.value())
        m = self.w.job.model
        if m is not None:
            m.invalidate()
            for msg in m.clamp_tilts():
                self.w.statusBar().showMessage(msg, 5000)
        self.changed.emit()

    def _handles_toggled(self, on: bool):
        if self._loading:
            return
        style = self.w.viewer.funnel.style
        style.handle_term_var = (self._current.var
                                 if (on and self._current) else "")
        self.w.viewer.rebuild_funnel()
        self.w.viewer.render()

    def _push_levels(self, *_):
        t = self._current
        if t is None or self._loading:
            return
        t.own_levels = self.own_levels.isChecked()
        t.level_mode = ("energy" if self.level_mode.currentText() == "energies"
                        else "distance")
        vals = []
        for part in self.level_values.text().replace(";", ",").split(","):
            part = part.strip()
            if part:
                try:
                    vals.append(float(part))
                except ValueError:
                    pass
        if vals:
            t.levels = vals
        self.changed.emit()

    def refresh_placement(self):
        """Cheap update used while a handle is being dragged."""
        t = self._current
        if t is None:
            return
        self._apply_box_ranges(t)
        try:
            self._refresh_placement_inner(t)
        finally:
            self._loading = False
        self._update_position_info()

    def _refresh_placement_inner(self, t):
        self._loading = True
        self.pos_axial.setValue(t.axial_position())
        self.pos_e1.setValue(t.offset_e1)
        self.pos_e2.setValue(t.offset_e2)
        self.tilt.setValue(t.tilt_deg)
        self.azimuth.setValue(t.azimuth_deg)
        self.z_lo.setValue(t.z_lo)
        self.z_hi.setValue(t.z_hi)
        self.center_z.setValue(t.center_z)
        self.radius.setValue(t.radius)

    def _update_position_info(self):
        t = self._current
        model = self.w.job.model
        if t is None:
            return
        sp = self.w.job.spec
        bits = []
        if t.kind == "sphere":
            bits.append(f"centre at z = {t.center_z:+.4f} Å")
        else:
            bits.append(f"z from {t.z_lo:+.4f} to {t.z_hi:+.4f} Å "
                        f"(length {t.z_hi - t.z_lo:.4f} Å)")
        if t.is_off_axis:
            import math as _m
            d = _m.hypot(t.offset_e1, t.offset_e2)
            if d > 0:
                bits.append(f"{d:.4f} Å off the axis")
            if t.offset_axial:
                bits.append(f"origin {t.offset_axial:+.4f} Å along the axis")
        if t.is_tilted:
            bits.append(f"tilted {t.tilt_deg:.3f}° towards "
                        f"{t.azimuth_deg:+.2f}°")
        if t.is_off_axis and not sp.has_frame_ref:
            bits.append(f"<span style='color:{theme.BAD}'>a frame reference "
                        "group is required for off-axis placement</span>")
        elif not sp.has_frame_ref:
            bits.append("a body-fixed reference group will be picked "
                        "automatically the first time you move or tilt this "
                        "shape sideways")
        self.pos_info.setText(" · ".join(bits))
        for row in (self.pos_e1, self.pos_e2, self.tilt, self.azimuth):
            row.setEnabled(True)

    def _set_editor_enabled(self, on: bool):
        self.editor.setEnabled(on)

    # ------------------------------------------------------------------
    # list management
    # ------------------------------------------------------------------
    def _add(self, kind: str):
        spec = self.w.job.spec
        t = make_term(kind, spec, self.w.job.model,
                      [x.var for x in spec.terms])
        spec.terms.append(t)
        self.refresh()
        self.table.selectRow(len(spec.terms) - 1)
        self.changed.emit()

    def _duplicate(self):
        i = self.table.currentRow()
        if not (0 <= i < len(self.terms)):
            return
        t = self.terms[i].copy()
        from ..core.terms import next_var
        t.var = next_var([x.var for x in self.terms])
        t.label = t.label + " copy"
        self.terms.insert(i + 1, t)
        self.refresh()
        self.table.selectRow(i + 1)
        self.changed.emit()

    def _remove(self):
        i = self.table.currentRow()
        if not (0 <= i < len(self.terms)):
            return
        t = self.terms.pop(i)
        sp = self.w.job.spec
        sp.prints = [p for p in sp.prints if p[1] != t.energy_var]
        self.refresh()
        self.changed.emit()

    def _move(self, delta: int):
        i = self.table.currentRow()
        j = i + delta
        if not (0 <= i < len(self.terms)) or not (0 <= j < len(self.terms)):
            return
        self.terms[i], self.terms[j] = self.terms[j], self.terms[i]
        self.refresh()
        self.table.selectRow(j)
        self.changed.emit()

    def _selection_changed(self):
        i = self.table.currentRow()
        self._current = self.terms[i] if 0 <= i < len(self.terms) else None
        self._set_editor_enabled(self._current is not None)
        self._load_current()

    def _table_edited(self, item):
        if self._loading:
            return
        i = item.row()
        if not (0 <= i < len(self.terms)):
            return
        t = self.terms[i]
        if item.column() == 0:
            t.enabled = item.checkState() == QtCore.Qt.Checked
        elif item.column() == 1:
            t.label = item.text().strip() or t.label
        self.changed.emit()

    # ------------------------------------------------------------------
    # editor <-> term
    # ------------------------------------------------------------------
    def _apply_box_ranges(self, t):
        """Keep every positional field inside the solvent box."""
        m = self.w.job.model
        if m is None or t is None:
            return
        try:
            lo, hi = m.axis_limits(margin=0.25)
            if hi > lo:
                for row in (self.pos_axial, self.z_lo, self.z_hi,
                            self.center_z):
                    row.setRangeKeepValue(lo, hi)
            r_body = (t.radius if t.kind == "sphere"
                      else (0.0 if t.kind == "slab"
                            else m.term_profile_max(t, 0.25)))
            for which, row in ((1, self.pos_e1), (2, self.pos_e2)):
                a, b = m.lateral_limits(which, radius=r_body, margin=0.25)
                if b <= a:
                    a, b = m.lateral_limits(which, margin=0.25)
                if b > a:
                    row.setRangeKeepValue(a, b)
            room = m.term_max_radius(t, margin=0.25)
            if room > 0.2:
                self.radius.setRangeKeepValue(0.1, room)
        except Exception:
            pass

    def _load_current(self):
        t = self._current
        if t is None:
            return
        self._apply_box_ranges(t)
        try:
            self._load_current_inner(t)
        finally:
            # a failure here must never leave the panel deaf to the user
            self._loading = False
        style = self.w.viewer.funnel.style
        style.handle_term_var = (t.var if self.handles_here.isChecked()
                                 else "")
        self._sync_visibility()
        self._update_position_info()
        self.refresh_readouts()

    def _load_current_inner(self, t):
        self._loading = True
        self.label.setText(t.label)
        self.var.setText(t.var)
        self.mode.setCurrentText("confine  ·  keep inside" if t.mode == "confine"
                                 else "exclude  ·  keep outside")
        self.k.setValue(t.k)
        self.exponent.setValue(t.exponent)
        self.offset.setValue(t.offset)
        self.target.setCurrentText("the ligand (biased particle)"
                                   if t.target_kind == "ligand"
                                   else "another atom group")
        self.target_expr.setText(t.target_expression)
        self.profile.setText(t.profile)
        self.z_lo.setValue(t.z_lo)
        self.z_hi.setValue(t.z_hi)
        self.cap.setCurrentText({"solvent": "solvent side only",
                                 "pocket": "pocket side only",
                                 "both": "both ends",
                                 "none": "leave open"}[t.cap])
        self.k_cap.setValue(t.k_cap)
        self.center_mode.setCurrentText(
            "a point on the funnel axis" if t.center_mode == "axis"
            else "the COM of an atom group")
        self.center_z.setValue(t.center_z)
        self.radius.setValue(t.radius)
        if self.expr.toPlainText() != t.expression:
            self.expr.setPlainText(t.expression)
        self.region_on.setChecked(t.region.enabled)
        self.r_lo.setValue(t.region.z_lo)
        self.r_hi.setValue(t.region.z_hi)
        self.taper.setValue(t.region.taper)
        self.pos_axial.setValue(t.axial_position())
        self.pos_e1.setValue(t.offset_e1)
        self.pos_e2.setValue(t.offset_e2)
        self.tilt.setValue(t.tilt_deg)
        self.azimuth.setValue(t.azimuth_deg)
        self.own_levels.setChecked(t.own_levels)
        self.level_mode.setCurrentText("energies" if t.level_mode == "energy"
                                       else "distances outside the wall")
        self.level_values.setText(", ".join(f"{v:g}" for v in t.levels))
        self.color_btn.setStyleSheet(
            "background: rgb(%d,%d,%d); color: #101010; font-weight: 600;"
            % tuple(int(255 * c) for c in t.color))

    def _sync_visibility(self):
        t = self._current
        if t is None:
            return
        self.lathe_box.setVisible(t.kind == "lathe")
        self.sphere_box.setVisible(t.kind == "sphere")
        self.expr_box.setVisible(t.kind == "expression")
        self.k.setVisible(t.kind != "expression")
        self.exponent.setVisible(t.kind != "expression")
        self.offset.setVisible(t.kind in ("lathe", "sphere"))
        self.mode.setVisible(t.kind in ("lathe", "sphere"))
        self.z_lo.setVisible(t.kind in ("lathe", "slab"))
        self.z_hi.setVisible(t.kind in ("lathe", "slab"))
        self.center_z.setEnabled(t.center_mode == "axis")
        self.center_expr.setEnabled(t.center_mode == "group")
        for wdg in (self.r_lo, self.r_hi, self.taper):
            wdg.setEnabled(t.region.enabled)
        if t.kind == "slab":
            self.lathe_box.setVisible(True)
            self.preset.setVisible(False)
            self.profile.setVisible(False)
            self.profile_status.setVisible(False)
            self.cap.setVisible(False)
            self.k_cap.setVisible(False)
            self.preview.setVisible(False)
            self.lathe_box.setTitle("Axial window")
        else:
            self.preset.setVisible(True)
            self.profile.setVisible(True)
            self.profile_status.setVisible(True)
            self.cap.setVisible(True)
            self.k_cap.setVisible(True)
            self.preview.setVisible(True)
            self.lathe_box.setTitle("Lathe profile")

    def _push(self, *_, _source=None):
        t = self._current
        if t is None or self._loading:
            return
        sender = _source if _source is not None else self.sender()
        edited = lambda widget: sender is None or sender is widget
        if edited(self.label):
            t.label = self.label.text().strip() or t.label
        newvar = self.var.text().strip()
        if edited(self.var) and newvar and newvar != t.var and newvar.isidentifier():
            old = t.energy_var
            t.var = newvar
            sp = self.w.job.spec
            sp.prints = [(lbl, t.energy_var if v == old else v)
                         for lbl, v in sp.prints]
        if edited(self.mode):
            t.mode = "confine" if self.mode.currentText().startswith("confine") \
                else "exclude"
        for attr, row in (("k", self.k), ("exponent", self.exponent),
                          ("offset", self.offset), ("z_lo", self.z_lo),
                          ("z_hi", self.z_hi), ("k_cap", self.k_cap),
                          ("center_z", self.center_z), ("radius", self.radius)):
            if edited(row):
                setattr(t, attr, row.value())
        if edited(self.profile):
            t.profile = self.profile.text().strip() or t.profile
        if edited(self.cap):
            t.cap = {"solvent side only": "solvent", "pocket side only": "pocket",
                     "both ends": "both", "leave open": "none"}[
                         self.cap.currentText()]
        if edited(self.center_mode):
            t.center_mode = ("axis" if self.center_mode.currentText().startswith("a p")
                             else "group")
        if edited(self.region_on):
            t.region.enabled = self.region_on.isChecked()
        for attr, row in (("z_lo", self.r_lo), ("z_hi", self.r_hi),
                          ("taper", self.taper)):
            if edited(row):
                setattr(t.region, attr, row.value())
        self._sync_visibility()
        self.changed.emit()

    def _expr_changed(self):
        t = self._current
        if t is None or self._loading:
            return
        t.expression = self.expr.toPlainText().strip() or "0.0"
        self._check_expressions()
        self.changed.emit()

    def _target_changed(self, text):
        t = self._current
        if t is None or self._loading:
            return
        t.target_kind = "ligand" if text.startswith("the ligand") else "selection"
        self._sync_visibility()
        self.changed.emit()

    def _apply_target(self):
        t = self._current
        st = self.w.job.structure
        if t is None or st is None:
            return
        try:
            idx = parse_selection(self.target_expr.text(), st)
        except SelectionError as exc:
            QtWidgets.QMessageBox.warning(self, "Selection", str(exc))
            return
        if len(idx) == 0:
            QtWidgets.QMessageBox.information(self, "Selection",
                                              "That matches no atoms.")
            return
        t.target_indices = sorted(int(i) + 1 for i in idx)
        t.target_expression = self.target_expr.text()
        t.target_kind = "selection"
        self._loading = True
        self.target.setCurrentText("another atom group")
        self._loading = False
        self.changed.emit()

    def _apply_center(self):
        t = self._current
        st = self.w.job.structure
        if t is None or st is None:
            return
        try:
            idx = parse_selection(self.center_expr.text(), st)
        except SelectionError as exc:
            QtWidgets.QMessageBox.warning(self, "Selection", str(exc))
            return
        if len(idx) == 0:
            return
        t.center_indices = sorted(int(i) + 1 for i in idx)
        t.center_mode = "group"
        self._loading = True
        self.center_mode.setCurrentText("the COM of an atom group")
        self._loading = False
        self.changed.emit()

    def _pick_colour(self):
        t = self._current
        if t is None:
            return
        c0 = QtGui.QColor.fromRgbF(*t.color)
        c = QtWidgets.QColorDialog.getColor(c0, self, "Term colour")
        if c.isValid():
            t.color = (c.redF(), c.greenF(), c.blueF())
            self._load_current()
            self.changed.emit()

    def _preset_chosen(self, name: str):
        if self._loading or name == "—":
            return
        for label, expr, _note in PROFILE_PRESETS:
            if label == name:
                self.profile.setText(expr)
                self._push(_source=self.profile)
                break

    def _palette(self):
        dlg = PalettePopup(self.w.job.spec, self)
        if dlg.exec_() == QtWidgets.QDialog.Accepted and dlg.chosen:
            token = dlg.chosen
            if self._current is not None and self._current.kind == "expression":
                self.expr.insertPlainText(token)
            else:
                self.profile.insert(token)
                self._push(_source=self.profile)

    def _examples(self):
        t = self._current
        items = [
            ("Cylindrical wall at 8 Å",
             "0.5*25.0*(if rho-8.0 then rho-8.0 else 0.0)^2"),
            ("Wall 2 Å outside the funnel",
             "0.5*25.0*(if rho-(r_allowed+2.0) then rho-(r_allowed+2.0) "
             "else 0.0)^2"),
            ("Ellipsoid around z = 14 Å",
             "0.5*20.0*(if sqrt(((z-14.0)^2)/4.0+(rho^2))-7.0 then "
             "sqrt(((z-14.0)^2)/4.0+(rho^2))-7.0 else 0.0)^2"),
            ("Quartic soft wall",
             "0.5*5.0*(if rho-6.0 then rho-6.0 else 0.0)^4"),
            ("Linear ramp pushing towards the pocket",
             "if z-20.0 then 0.4*(z-20.0) else 0.0"),
            ("Smooth (differentiable) one-sided wall",
             "0.5*25.0*(gibbs_max(0.2,array(rho-8.0,0.0)))^2"),
            ("Cone with a fractional power",
             "0.5*25.0*(if rho-pow(z+10.0,0.5)*2.0 then "
             "rho-pow(z+10.0,0.5)*2.0 else 0.0)^2"),
            ("Keep 12 Å from a residue COM (target = that group)",
             "0.5*10.0*(if norm(min_image(lig_com-site_com))-12.0 then "
             "norm(min_image(lig_com-site_com))-12.0 else 0.0)^2"),
        ]
        dlg = QtWidgets.QDialog(self)
        dlg.setWindowTitle("Expression examples")
        dlg.resize(760, 420)
        lay = QtWidgets.QVBoxLayout(dlg)
        tree = QtWidgets.QTreeWidget()
        tree.setHeaderLabels(["what it does", "expression"])
        tree.setColumnWidth(0, 250)
        for name, expr in items:
            QtWidgets.QTreeWidgetItem(tree, [name, expr])
        lay.addWidget(tree)
        row = QtWidgets.QHBoxLayout()
        use = QtWidgets.QPushButton("Use this one")
        use.setProperty("accent", "true")
        close = QtWidgets.QPushButton("Close")
        row.addStretch(1)
        row.addWidget(use)
        row.addWidget(close)
        lay.addLayout(row)
        close.clicked.connect(dlg.reject)

        def take():
            it = tree.currentItem()
            if it is None:
                return
            if t is not None and t.kind == "expression":
                self.expr.setPlainText(it.text(1))
            dlg.accept()
        use.clicked.connect(take)
        tree.itemDoubleClicked.connect(lambda *a: take())
        dlg.exec_()

    # ------------------------------------------------------------------
    def _check_expressions(self):
        t = self._current
        if t is None:
            return
        spec = self.w.job.spec
        known = {n for n, _ in expression_variables(spec)}
        if t.kind == "expression":
            problems = check_expression(t.expression, known)
            self._show_status(self.expr_status, problems,
                              "the expression is valid Desmond "
                              "M-expression")
        if t.kind == "lathe":
            problems = check_expression(t.profile, known)
            self._show_status(self.profile_status, problems,
                              "the profile is valid")

    def _show_status(self, label: QtWidgets.QLabel, problems, ok_text: str):
        if problems:
            label.setText("<br>".join(
                f"<span style='color:{theme.BAD}'>✕ {p}</span>"
                for p in problems))
        else:
            label.setText(f"<span style='color:{theme.GOOD}'>✓ {ok_text}"
                          "</span>")

    def refresh_readouts(self):
        t = self._current
        model = self.w.job.model
        if t is None:
            return
        self.readout.set("kind", t.kind)
        for key, (d, e) in zip(("g05", "g10", "g20", "g30"),
                               t.gradation((0.5, 1.0, 2.0, 3.0))):
            self.gradation.set(key, "-" if t.kind == "expression"
                               else f"{e:.2f} kcal/mol")
        if model is None:
            return
        try:
            ctx = model.field_ctx(points=model.frame.lig_com[None, :])
            v0 = float(np.asarray(t.energy(ctx)).reshape(-1)[0])
            col = theme.GOOD if abs(v0) < 1e-6 else theme.WARN
            self.readout.set("v0", f"{v0:.4f} kcal/mol", col)
            z0, _rho0 = model.cv_of_ligand()
            r = t.boundary_radius(ctx, np.array([z0]))
            self.readout.set("r_at_lig",
                             "-" if r is None or not np.isfinite(r[0])
                             else f"{float(r[0]):.3f} Å")
            s = float(t.region.switch(np.array([z0]))[0])
            self.readout.set("switch", f"{s:.3f}")
        except Exception as exc:
            self.readout.set("v0", "error")
            self.readout.set("r_at_lig", str(exc)[:24])
        try:
            lines = emit_term(t, EmitCtx(
                funnel_enabled=self.w.job.spec.funnel_enabled))
            self.code.setPlainText("\n".join(
                l for l in lines if not l.startswith("# @ff-term")))
        except Exception as exc:
            self.code.setPlainText(f"# could not be generated: {exc}")
        self.preview.refresh(model, t)
        note = []
        if t.region.enabled and t.region.taper <= 0:
            note.append(f"<span style='color:{theme.WARN}'>A hard gate makes "
                        "the energy jump at the edges. Give the taper a width "
                        "of 1-3 Å.</span>")
        if t.region.enabled and t.kind == "lathe" and t.cap != "none":
            note.append(f"<span style='color:{theme.WARN}'>The switch scales "
                        "the whole term, so the end wall fades out where it "
                        "should be closing the volume. Set the ends to "
                        "“leave open” and close the volume with the "
                        "funnel walls or a slab term.</span>")
        self.region_note.setText("<br>".join(note))

    def refresh(self):
        try:
            self._refresh_inner()
        finally:
            self._loading = False

    def _refresh_inner(self):
        spec = self.w.job.spec
        model = self.w.job.model
        self._loading = True
        self.use_funnel.setChecked(spec.funnel_enabled)
        degenerate = model.funnel_is_degenerate() if model else True
        live = spec.funnel_enabled and not degenerate
        self.funnel_rows.setVisible(live)
        self.add_funnel_btn.setVisible(not live)
        if live and model is not None:
            try:
                lo, hi = model.axis_limits(margin=0.25)
                if hi > lo:
                    for row in (self.f_z_cc, self.f_z_min, self.f_z_max,
                                self.f_origin):
                        row.setRangeKeepValue(lo, hi)
                room = model.best_room(margin=0.25)
                if room > 0.2:
                    self.f_r_cyl.setRangeKeepValue(0.1, room)
                for which, row in ((1, self.f_lat1), (2, self.f_lat2)):
                    a, b = model.lateral_limits(which, margin=0.25)
                    if b > a:
                        row.setRangeKeepValue(a, b)
            except Exception:
                pass
        if live:
            self.f_z_cc.setValue(spec.z_cc)
            self.f_r_cyl.setValue(spec.r_cyl)
            self.f_cone.setValue(spec.cone_angle_deg)
            self.f_slope.setValue(spec.cone_slope)
            self.f_z_min.setValue(spec.z_min)
            self.f_z_max.setValue(spec.z_max)
            self.f_k_rad.setValue(spec.k_rad)
            self.f_k_z.setValue(spec.k_z)
            self.f_lat1.setValue(spec.origin_lat1)
            self.f_lat2.setValue(spec.origin_lat2)
            self.f_tilt.setValue(spec.axis_tilt_deg)
            self.f_azim.setValue(spec.axis_azimuth_deg)
            if model is not None:
                self.f_origin.setValue(model.origin_offset_A)
            self.funnel_status.setText(
                f"R_base {spec.r_base():.3f} Å · cone "
                f"{max(0.0, spec.z_cc - spec.z_min):.2f} Å · cylinder "
                f"{max(0.0, spec.z_max - spec.z_cc):.2f} Å · the same numbers "
                "are on the Funnel tab, with the 3-D handles")
        else:
            self.funnel_status.setText(
                "No funnel is defined. The imported job did not contain one, "
                "so none was invented.")
        for row in (self.f_lat1, self.f_lat2, self.f_tilt, self.f_azim):
            row.setEnabled(True)
        if spec.has_frame_ref and model is not None:
            import numpy as _np
            try:
                ref = model.st.center_of_mass(spec.frame_ref.idx0())
                v = model.st.min_image(ref - model.frame.core_com)
                perp = float(_np.linalg.norm(
                    v - float(v @ model.frame.axis) * model.frame.axis))
            except Exception:
                perp = float("nan")
            names = ", ".join(model.st.residue_signature(
                spec.frame_ref.idx0())[:4])
            colour = theme.GOOD if perp > 5.0 else theme.WARN
            self.fref_info.setText(
                f"<b>{spec.frame_ref.n}</b> atoms · {names}<br>"
                f"perpendicular reach <span style='color:{colour}'>"
                f"{perp:.2f} Å</span> — e1 points from CORE towards this "
                "group, e2 = axis × e1")
        else:
            self.fref_info.setText(
                "Not set. Shapes can still be placed anywhere along the axis; "
                "a reference group is only needed to move them <i>sideways</i>, "
                "because the direction has to be tied to the protein rather "
                "than to the box.")
        if spec.frame_ref.expression:
            self.fref_expr.setText(spec.frame_ref.expression)
        cur = self.table.currentRow()
        self.table.setRowCount(len(spec.terms))
        energies = dict(model.term_energies_at_ligand()) if model else {}
        for r, t in enumerate(spec.terms):
            chk = QtWidgets.QTableWidgetItem()
            chk.setFlags(QtCore.Qt.ItemIsUserCheckable | QtCore.Qt.ItemIsEnabled
                         | QtCore.Qt.ItemIsSelectable)
            chk.setCheckState(QtCore.Qt.Checked if t.enabled
                             else QtCore.Qt.Unchecked)
            self.table.setItem(r, 0, chk)
            name = QtWidgets.QTableWidgetItem(t.label)
            name.setForeground(QtGui.QColor.fromRgbF(*t.color))
            self.table.setItem(r, 1, name)
            for c, text in ((2, t.kind),
                            (3, "ligand" if t.target_kind == "ligand"
                             else f"{len(t.target_indices)} atoms"),
                            (4, "-" if t.kind == "expression" else f"{t.k:g}")):
                it = QtWidgets.QTableWidgetItem(text)
                it.setFlags(it.flags() & ~QtCore.Qt.ItemIsEditable)
                self.table.setItem(r, c, it)
            v = energies.get(t.label or t.var, float("nan"))
            it = QtWidgets.QTableWidgetItem("-" if not np.isfinite(v)
                                            else f"{v:.3f}")
            it.setFlags(it.flags() & ~QtCore.Qt.ItemIsEditable)
            if np.isfinite(v) and v > 1e-6:
                it.setForeground(QtGui.QColor(theme.WARN))
            self.table.setItem(r, 5, it)
        self._loading = False
        if 0 <= cur < len(spec.terms):
            self.table.selectRow(cur)
        elif spec.terms:
            self.table.selectRow(0)
        else:
            self._current = None
            self._set_editor_enabled(False)
        self._check_expressions()
