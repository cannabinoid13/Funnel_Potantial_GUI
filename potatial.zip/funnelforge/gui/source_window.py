"""The .pot source workbench: raw text on the left, what it means on the right.

The two halves are always views of the same string.  Editing happens in the
text; the inspector, the diagnostics and the validation layers are recomputed
from it and are tagged with the revision they describe, so a result that
belongs to older text is shown as stale instead of being passed off as
current.

Long work - parsing a large file, and above all asking the installed Desmond
parser - runs in a cancellable worker.  Every worker carries the revision it
started from and its result is dropped if the text has moved on, which is the
only way a slow answer cannot overwrite a newer question.

Two ways out, kept deliberately far apart in the toolbar:

* **Save source** writes the bytes as they are.  Always available.
* **Export run-ready** refuses unless the layers allow it, and says which
  physical contribution would be at risk.
"""

from __future__ import annotations

import os
import copy

from PyQt5 import QtCore, QtGui, QtWidgets

from ..core import safety
from ..core.document import Document
from ..core.lang import cst, patch, sema
from ..core.lang import diagnostics as diag

def display_text(text: str) -> str:
    """What the text looks like inside a Qt editor.

    ``QPlainTextEdit`` stores paragraphs, not bytes: it turns every CR and
    CRLF into a single LF and hands that back from ``toPlainText()``.  So the
    editor is compared against this projection of the document rather than
    against the document itself - if the two match, the user has typed
    nothing and the original bytes are written back untouched, mixed line
    endings and all.  Only a genuine edit can normalise them, and that is
    reported when it happens.
    """
    return text.replace("\r\n", "\n").replace("\r", "\n")


STATE_TEXT = {
    "passed": "PASS", "warning": "WARN", "error": "FAIL",
    "not_run": "not run", "stale": "STALE",
}
STATE_COLOUR = {
    "passed": "#2e7d32", "warning": "#b26a00", "error": "#b3261e",
    "not_run": "#5f6368", "stale": "#6a4bb5",
}
LAYER_TITLE = {
    "syntax": "1 · Source syntax",
    "model": "2 · Model coverage",
    "symbols": "3 · Symbols and data flow",
    "topology": "4 · Atom selections",
    "official": "5 · Desmond engine",
    "lint": "6 · Physical checks",
    "package": "7 · Job files",
}


# --------------------------------------------------------------------------
class Highlighter(QtGui.QSyntaxHighlighter):
    """Colour only.  The parser, not this, decides what anything means."""

    def __init__(self, doc):
        super().__init__(doc)
        def fmt(colour, bold=False, italic=False):
            f = QtGui.QTextCharFormat()
            f.setForeground(QtGui.QColor(colour))
            if bold:
                f.setFontWeight(QtGui.QFont.Bold)
            f.setFontItalic(italic)
            return f
        self.f_comment = fmt("#6a9955", italic=True)
        self.f_string = fmt("#ce9178")
        self.f_number = fmt("#b5cea8")
        self.f_keyword = fmt("#569cd6", bold=True)
        self.f_decl = fmt("#c586c0", bold=True)
        self.f_call = fmt("#dcdcaa")
        self.f_bind = fmt("#9cdcfe")
        import re
        self.rules = [
            (re.compile(r'"[^"]*"'), self.f_string),
            (re.compile(r"\b\d+(\.\d*)?([eE][+-]?\d+)?\b"), self.f_number),
            (re.compile(r"\b(if|then|else|series|static)\b"), self.f_keyword),
            (re.compile(r"\b(declare_meta|declare_output)\b"), self.f_decl),
            (re.compile(r"\b([A-Za-z]\w*)\s*\("), self.f_call),
            (re.compile(r"^\s*([A-Za-z]\w*)\s*="), self.f_bind),
        ]
        self.re_comment = re.compile(r"#[^\n]*")

    def highlightBlock(self, text: str) -> None:
        for rx, f in self.rules:
            for m in rx.finditer(text):
                g = 1 if m.groups() else 0
                self.setFormat(m.start(g), m.end(g) - m.start(g), f)
        for m in self.re_comment.finditer(text):
            self.setFormat(m.start(), m.end() - m.start(), self.f_comment)


class LineNumbers(QtWidgets.QWidget):
    def __init__(self, editor):
        super().__init__(editor)
        self.editor = editor

    def sizeHint(self):
        return QtCore.QSize(self.editor.gutter_width(), 0)

    def paintEvent(self, ev):
        self.editor.paint_gutter(ev)


class Editor(QtWidgets.QPlainTextEdit):
    """A plain text editor that never reformats what it is given."""

    def __init__(self):
        super().__init__()
        font = QtGui.QFont("DejaVu Sans Mono", 10)
        font.setStyleHint(QtGui.QFont.Monospace)
        self.setFont(font)
        self.setLineWrapMode(QtWidgets.QPlainTextEdit.NoWrap)
        self.setTabStopDistance(4 * QtGui.QFontMetricsF(font).width(" "))
        self.setAccessibleName("Potential source text")
        self.gutter = LineNumbers(self)
        self.blockCountChanged.connect(lambda _: self._resize_gutter())
        self.updateRequest.connect(self._update_gutter)
        self.cursorPositionChanged.connect(self._highlight_line)
        self._resize_gutter()

    def gutter_width(self) -> int:
        digits = max(3, len(str(max(1, self.blockCount()))))
        return 12 + QtGui.QFontMetrics(self.font()).width("9") * digits

    def _resize_gutter(self) -> None:
        self.setViewportMargins(self.gutter_width(), 0, 0, 0)

    def _update_gutter(self, rect, dy) -> None:
        if dy:
            self.gutter.scroll(0, dy)
        else:
            self.gutter.update(0, rect.y(), self.gutter.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self._resize_gutter()

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        cr = self.contentsRect()
        self.gutter.setGeometry(cr.left(), cr.top(), self.gutter_width(),
                                cr.height())

    def paint_gutter(self, ev) -> None:
        p = QtGui.QPainter(self.gutter)
        p.fillRect(ev.rect(), QtGui.QColor("#20232a"))
        block = self.firstVisibleBlock()
        top = self.blockBoundingGeometry(block).translated(
            self.contentOffset()).top()
        n = block.blockNumber()
        p.setPen(QtGui.QColor("#6b7280"))
        while block.isValid() and top <= ev.rect().bottom():
            if block.isVisible():
                p.drawText(0, int(top), self.gutter.width() - 6,
                           QtGui.QFontMetrics(self.font()).height(),
                           QtCore.Qt.AlignRight, str(n + 1))
            block = block.next()
            top += self.blockBoundingRect(block).height()
            n += 1

    def _highlight_line(self) -> None:
        sel = QtWidgets.QTextEdit.ExtraSelection()
        sel.format.setBackground(QtGui.QColor("#2a2f3a"))
        sel.format.setProperty(QtGui.QTextFormat.FullWidthSelection, True)
        sel.cursor = self.textCursor()
        sel.cursor.clearSelection()
        self.setExtraSelections([sel])

    def select_span(self, start: int, end: int) -> None:
        c = self.textCursor()
        c.setPosition(max(0, start))
        c.setPosition(max(0, end), QtGui.QTextCursor.KeepAnchor)
        self.setTextCursor(c)
        self.centerCursor()
        self.setFocus()


# --------------------------------------------------------------------------
class AnalysisWorker(QtCore.QThread):
    """Parse and analyse off the UI thread, tagged with its revision."""

    done = QtCore.pyqtSignal(str, object)

    def __init__(self, text: str, rev: str, cms: str, release: str,
                 path: str = ""):
        super().__init__()
        self.text, self.rev, self.cms, self.release = text, rev, cms, release
        self.path = path

    def run(self) -> None:
        doc = Document.from_text(self.text, self.path)
        doc.release = self.release
        try:
            doc.run_local_layers()
            if self.cms:
                doc.resolve_topology(self.cms)
            doc.check_package(cms_path=self.cms)
        except Exception as exc:                      # never kill the UI
            doc.report.mark("syntax", diag.State.ERROR,
                            note=f"analysis failed: {exc}")
        self.done.emit(self.rev, doc)


class OfficialWorker(QtCore.QThread):
    """Run the installed Desmond parser; cancellable, revision-tagged."""

    done = QtCore.pyqtSignal(str, object)

    def __init__(self, text: str, rev: str, cms: str, installation,
                 timeout: float):
        super().__init__()
        self.text, self.rev, self.cms = text, rev, cms
        self.installation, self.timeout = installation, timeout
        import threading
        self.cancel = threading.Event()

    def stop(self) -> None:
        self.cancel.set()

    def run(self) -> None:
        from ..core.desmond import adapter
        try:
            res = adapter.validate(self.text, self.cms or None,
                                   installation=self.installation,
                                   timeout=self.timeout, cancel=self.cancel)
        except Exception as exc:
            res = None
            self.error = str(exc)
        self.done.emit(self.rev, res)


# --------------------------------------------------------------------------
class SourceWindow(QtWidgets.QMainWindow):
    """Raw source and derived views of one ``.pot`` file."""

    def __init__(self, path: str = "", parent=None):
        super().__init__(parent)
        self.setWindowTitle("FunnelForge - potential source")
        self.resize(1580, 940)
        self.doc = Document.from_text("")
        self.view_doc = self.doc
        self._worker = None
        self._official = None
        self._pending_rev = ""
        self._loading = False
        self.cms_path = ""

        self.editor = Editor()
        self.hl = Highlighter(self.editor.document())
        self.editor.textChanged.connect(self._text_changed)

        self.tabs = QtWidgets.QTabWidget()
        self.tabs.setAccessibleName("Derived views")
        self._build_validation_tab()
        self._build_structure_tab()
        self._build_depends_tab()
        self._build_selection_tab()

        split = QtWidgets.QSplitter(QtCore.Qt.Horizontal)
        split.addWidget(self.editor)
        split.addWidget(self.tabs)
        split.setStretchFactor(0, 3)
        split.setStretchFactor(1, 2)
        self.setCentralWidget(split)

        self._build_toolbar()
        self.status = self.statusBar()
        self.lbl_verdict = QtWidgets.QLabel("no file")
        self.lbl_verdict.setAccessibleName("Overall verdict")
        self.status.addPermanentWidget(self.lbl_verdict)

        self._debounce = QtCore.QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(250)
        self._debounce.timeout.connect(self._reanalyse)

        if path:
            self.open_path(path)

    # -- construction --------------------------------------------------
    def _build_toolbar(self) -> None:
        tb = self.addToolBar("main")
        tb.setToolButtonStyle(QtCore.Qt.ToolButtonTextOnly)

        def act(text, slot, shortcut="", tip=""):
            a = QtWidgets.QAction(text, self)
            a.triggered.connect(slot)
            if shortcut:
                a.setShortcut(shortcut)
            a.setToolTip(tip or text)
            a.setStatusTip(tip or text)
            tb.addAction(a)
            return a

        act("Open…", self._open_dialog, "Ctrl+O", "Open a .pot file")
        act("Structure…", self._cms_dialog, "Ctrl+T",
            "Attach a .cms so atom selections can be resolved")
        tb.addSeparator()
        self.a_save = act("Save source", self._save_source, "Ctrl+S",
                          "Write the text exactly as it is, byte for byte")
        self.a_export = act("Export run-ready…", self._export, "Ctrl+E",
                            "Write only if every layer allows it")
        act("Show diff", self._show_diff, "Ctrl+D",
            "What has changed since the file was opened")
        tb.addSeparator()
        self.a_official = act("Validate with Desmond", self._run_official,
                              "F5", "Ask the installed Schrodinger parser")
        self.a_cancel = act("Cancel", self._cancel_official, "Esc",
                            "Stop the running validation")
        self.a_cancel.setEnabled(False)
        tb.addSeparator()
        act("Undo", self._undo, "Ctrl+Z")
        act("Redo", self._redo, "Ctrl+Shift+Z")

        self.inst_box = QtWidgets.QComboBox()
        self.inst_box.setAccessibleName("Schrodinger installation")
        self.inst_box.setToolTip("Which installation the official validation "
                                 "should use")
        tb.addWidget(QtWidgets.QLabel("  engine: "))
        tb.addWidget(self.inst_box)
        self._fill_installations()

    def _fill_installations(self) -> None:
        from ..core.desmond import adapter
        self.installations = [i for i in adapter.discover_installations()
                              if i.usable]
        self.inst_box.clear()
        for i in self.installations:
            self.inst_box.addItem(f"{i.version or '?'} ({i.path})")
        # default to whichever the adapter would pick on its own, so the
        # toolbar and the headless CLI cannot disagree about the engine
        preferred = adapter.default_installation()
        if preferred is not None:
            for k, i in enumerate(self.installations):
                if i.path == preferred.path:
                    self.inst_box.setCurrentIndex(k)
                    break
        if not self.installations:
            self.inst_box.addItem("none found")
            self.a_official.setEnabled(False)

    def _build_validation_tab(self) -> None:
        w = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(w)
        self.layer_table = QtWidgets.QTableWidget(0, 3)
        self.layer_table.setHorizontalHeaderLabels(["layer", "state", "note"])
        self.layer_table.verticalHeader().setVisible(False)
        self.layer_table.setAccessibleName("Validation layers")
        self.layer_table.setEditTriggers(
            QtWidgets.QAbstractItemView.NoEditTriggers)
        self.layer_table.horizontalHeader().setSectionResizeMode(
            2, QtWidgets.QHeaderView.Stretch)
        self.layer_table.setFixedHeight(210)
        v.addWidget(self.layer_table)

        row = QtWidgets.QHBoxLayout()
        self.filter = QtWidgets.QLineEdit()
        self.filter.setPlaceholderText("filter diagnostics (code or text)")
        self.filter.setAccessibleName("Filter diagnostics")
        self.filter.textChanged.connect(self._refresh_diagnostics)
        row.addWidget(self.filter)
        self.show_info = QtWidgets.QCheckBox("include informational")
        self.show_info.setChecked(True)
        self.show_info.stateChanged.connect(self._refresh_diagnostics)
        row.addWidget(self.show_info)
        v.addLayout(row)

        self.diag_list = QtWidgets.QTreeWidget()
        self.diag_list.setHeaderLabels(["severity", "code", "line", "message"])
        self.diag_list.setAccessibleName("Diagnostics")
        self.diag_list.setRootIsDecorated(False)
        self.diag_list.itemActivated.connect(self._goto_diagnostic)
        self.diag_list.itemClicked.connect(self._goto_diagnostic)
        self.diag_list.setColumnWidth(0, 78)
        self.diag_list.setColumnWidth(1, 64)
        self.diag_list.setColumnWidth(2, 52)
        v.addWidget(self.diag_list, 1)

        self.diag_detail = QtWidgets.QPlainTextEdit()
        self.diag_detail.setReadOnly(True)
        self.diag_detail.setFixedHeight(120)
        self.diag_detail.setAccessibleName("Diagnostic detail")
        v.addWidget(self.diag_detail)
        self.tabs.addTab(w, "Validation")

    def _build_structure_tab(self) -> None:
        self.tree = QtWidgets.QTreeWidget()
        self.tree.setHeaderLabels(["what", "detail"])
        self.tree.setAccessibleName("Structure of the potential")
        self.tree.setColumnWidth(0, 250)
        self.tree.itemActivated.connect(self._goto_node)
        self.tree.itemClicked.connect(self._goto_node)
        self.tabs.addTab(self.tree, "Structure")

    def _build_depends_tab(self) -> None:
        w = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(w)
        self.sym_box = QtWidgets.QComboBox()
        self.sym_box.setAccessibleName("Name to inspect")
        self.sym_box.currentTextChanged.connect(self._refresh_depends)
        v.addWidget(self.sym_box)
        self.depends = QtWidgets.QPlainTextEdit()
        self.depends.setReadOnly(True)
        self.depends.setAccessibleName("Dependency graph")
        f = QtGui.QFont("DejaVu Sans Mono", 10)
        self.depends.setFont(f)
        v.addWidget(self.depends, 1)
        self.tabs.addTab(w, "Dependencies")

    def _build_selection_tab(self) -> None:
        self.sel_table = QtWidgets.QTableWidget(0, 5)
        self.sel_table.setHorizontalHeaderLabels(
            ["name", "atoms", "chains", "residues", "selection"])
        self.sel_table.setAccessibleName("Atom selections")
        self.sel_table.verticalHeader().setVisible(False)
        self.sel_table.setEditTriggers(
            QtWidgets.QAbstractItemView.NoEditTriggers)
        self.sel_table.horizontalHeader().setSectionResizeMode(
            4, QtWidgets.QHeaderView.Stretch)
        self.tabs.addTab(self.sel_table, "Selections")

    # -- file ----------------------------------------------------------
    def open_path(self, path: str) -> None:
        try:
            doc = Document.open(path)
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "Cannot open", str(exc))
            return
        self.doc = doc
        self._loading = True
        self.editor.setPlainText(display_text(doc.source))
        self._loading = False
        self._warned_newlines = False
        self.setWindowTitle(f"FunnelForge - {os.path.basename(path)}")
        sib = os.path.splitext(path)[0] + ".cms"
        self.cms_path = sib if os.path.exists(sib) else ""
        self._reanalyse()

    def _open_dialog(self) -> None:
        p, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Open a potential", "", "Desmond potential (*.pot);;"
                                          "All files (*)")
        if p:
            self.open_path(p)

    def _cms_dialog(self) -> None:
        p, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Attach a structure", "", "Maestro structure (*.cms);;"
                                            "All files (*)")
        if p:
            self.cms_path = p
            self._reanalyse()

    def _save_source(self) -> None:
        if not self.doc.path:
            p, _ = QtWidgets.QFileDialog.getSaveFileName(
                self, "Save source as", "", "Desmond potential (*.pot)")
            if not p:
                return
            self.doc.path = p
        self._sync_document()
        try:
            self.doc.save_source()
        except safety.ExternalChange:
            r = QtWidgets.QMessageBox.question(
                self, "The file changed on disk",
                "This file was modified by something else since it was "
                "opened.\n\nOverwrite it with what is on screen?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No)
            if r != QtWidgets.QMessageBox.Yes:
                return
            self.doc.save_source(allow_overwrite_changed=True)
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "Cannot save", str(exc))
            return
        msg = f"saved {self.doc.path}"
        if getattr(self, "_warned_newlines", False):
            msg += ("  -  note: this file mixed CR and LF line endings and "
                    "was written with LF throughout, because the text editor "
                    "cannot hold both")
        self.status.showMessage(msg, 12000)

    def _export(self) -> None:
        self._sync_document()
        # A debounce or an in-flight worker may still describe older text.
        # Only the analyzed document owns the validation evidence; the editor
        # document owns the original encoding.  Both must describe this text.
        analyzed = self.view_doc
        if analyzed is None or analyzed.rev != self.doc.rev:
            QtWidgets.QMessageBox.warning(
                self, "Run-ready export refused",
                "The edited source has not finished analysis. Wait for the "
                "current analysis, then validate it with Desmond before "
                "exporting.")
            self._reanalyse()
            return
        blockers = analyzed.export_blockers()
        if blockers:
            text = "\n\n".join(
                f"[{b.code}] {b.title}\n{b.message}" for b in blockers)
            QtWidgets.QMessageBox.warning(
                self, "Run-ready export refused",
                "This file is not being written, because:\n\n" + text
                + "\n\nSaving the source is still available and is lossless.")
            return
        p, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Export run-ready potential", "",
            "Desmond potential (*.pot)")
        if not p:
            return
        # Recheck after the modal file dialog, which processes worker results
        # and permits changes on disk while it is open.
        self._sync_document()
        if analyzed.rev != self.doc.rev:
            QtWidgets.QMessageBox.warning(
                self, "Run-ready export refused",
                "The source changed while choosing the export destination. "
                "Validate the current text before exporting.")
            return
        analyzed.encoding = self.doc.encoding
        try:
            written, blockers = analyzed.export_run_ready(p)
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "Cannot export", str(exc))
            return
        if written:
            message = f"exported {written}"
            if (self.doc.encoding and self.doc.encoding.name != "utf-8") \
                    or self.doc.source.startswith("\ufeff"):
                message += " (UTF-8 without BOM, as required by Desmond)"
            self.status.showMessage(message, 8000)
        elif blockers:
            QtWidgets.QMessageBox.warning(
                self, "Run-ready export refused",
                "\n\n".join(f"[{b.code}] {b.title}\n{b.message}"
                            for b in blockers))

    def _show_diff(self) -> None:
        current = self.editor.toPlainText()
        original = ""
        if self.doc.path and os.path.exists(self.doc.path):
            original, _ = safety.read_text_file(self.doc.path)
        d = patch.diff_summary(original, current) or "no changes"
        box = QtWidgets.QDialog(self)
        box.setWindowTitle("Changes against the file on disk")
        box.resize(900, 600)
        lay = QtWidgets.QVBoxLayout(box)
        view = QtWidgets.QPlainTextEdit(d)
        view.setReadOnly(True)
        view.setFont(QtGui.QFont("DejaVu Sans Mono", 10))
        lay.addWidget(view)
        b = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Close)
        b.rejected.connect(box.reject)
        lay.addWidget(b)
        box.exec_()

    def _undo(self) -> None:
        self.editor.undo()

    def _redo(self) -> None:
        self.editor.redo()

    # -- analysis ------------------------------------------------------
    def _sync_document(self) -> None:
        """Push the editor's text into the document only if it really changed."""
        shown = self.editor.toPlainText()
        if shown == display_text(self.doc.source):
            return                     # nothing typed: keep the exact bytes
        if display_text(self.doc.source) != self.doc.source:
            self._warn_normalised()
        self.doc.set_source(shown)

    def _warn_normalised(self) -> None:
        if getattr(self, "_warned_newlines", False):
            return
        self._warned_newlines = True
        self.status.showMessage(
            "this file mixes CR and LF line endings; the text editor cannot "
            "hold both, so saving after an edit will write LF throughout",
            12000)

    def _text_changed(self) -> None:
        if self._loading:
            return
        self._debounce.start()

    def _reanalyse(self) -> None:
        self._sync_document()
        text = self.doc.source
        rev = self.doc.rev
        self._pending_rev = rev
        release = self.doc.release
        if self._worker is not None and self._worker.isRunning():
            self._worker.wait(50)
        self._worker = AnalysisWorker(text, rev, self.cms_path, release,
                                      self.doc.path)
        self._worker.done.connect(self._analysis_ready)
        self._worker.start()

    def _analysis_ready(self, rev: str, doc: Document) -> None:
        self._sync_document()
        if rev != self.doc.rev:
            return                     # a stale answer to an older question
        if doc.topology_path and doc.topology_path != self.cms_path:
            return                     # an answer for a previous structure
        previous = self.view_doc
        official = copy.deepcopy(previous.report.layers["official"]) \
            if previous is not None else None
        self.view_doc = doc
        self.view_doc.path = self.doc.path
        self.view_doc.topology_path = self.cms_path
        if official is not None and official.source_rev == rev:
            # Local reanalysis does not renew the engine's topology evidence.
            # Keep its exact fingerprint so an externally edited CMS remains
            # stale even after the new topology has been read successfully.
            if previous.topology_path != self.cms_path:
                official.state = diag.State.STALE
            else:
                self.view_doc.topology_digest = previous.topology_digest
            self.view_doc.report.layers["official"] = official
            self.view_doc.last_official = previous.last_official
        elif official is not None and official.state is not diag.State.NOT_RUN:
            official.state = diag.State.STALE
            self.view_doc.report.layers["official"] = official
        self._refresh_all()

    def _run_official(self) -> None:
        if not self.installations:
            return
        self._sync_document()
        text = self.doc.source
        inst = self.installations[max(0, self.inst_box.currentIndex())]
        self._official = OfficialWorker(text, self.doc.rev, self.cms_path,
                                        inst, 300.0)
        self._official.done.connect(self._official_ready)
        self._official.start()
        self.a_official.setEnabled(False)
        self.a_cancel.setEnabled(True)
        self.status.showMessage(
            f"asking {inst.version} to parse this text…")

    def _cancel_official(self) -> None:
        if self._official is not None:
            self._official.stop()
            self.status.showMessage("cancelling the official validation…",
                                    3000)

    def _official_ready(self, rev: str, res) -> None:
        self.a_official.setEnabled(True)
        self.a_cancel.setEnabled(False)
        if res is None:
            self.status.showMessage("the official validation could not run",
                                    6000)
            return
        self._sync_document()
        if rev != self.doc.rev:
            self.status.showMessage(
                "the text changed while Desmond was parsing; that result "
                "describes older text and was discarded", 8000)
            return
        manifest = getattr(res, "manifest", {})
        if "cms_path" in manifest and (manifest["cms_path"] or "") != (
                safety.canonical_path(self.cms_path) if self.cms_path else ""):
            self.status.showMessage(
                "the attached structure changed while Desmond was parsing; "
                "that result was discarded", 8000)
            return
        if self.view_doc.rev != rev:
            # The official worker can finish before the local worker. Attach
            # its verdict to current source, never to the older view.
            current = Document.from_text(self.doc.source, self.doc.path)
            current.release = self.doc.release
            current.run_local_layers()
            self._analysis_ready(rev, current)
        d = self.view_doc
        d.report.reset("official")
        for x in res.diagnostics:
            d.report.add(x)
        state = (diag.State.PASSED if res.ok else diag.State.ERROR) \
            if res.ran else diag.State.NOT_RUN
        d.report.mark("official", state, note=d._official_note(res),
                      source_rev=rev)
        d.last_official = res
        if self.cms_path:
            d.topology_path = self.cms_path
            d.topology_digest = manifest.get("cms_sha256") or safety.file_digest(self.cms_path)
        self._refresh_all()
        self.status.showMessage(res.summary() if hasattr(res, "summary")
                                else "official validation finished", 6000)

    # -- rendering -----------------------------------------------------
    def _refresh_all(self) -> None:
        self._refresh_layers()
        self._refresh_diagnostics()
        self._refresh_structure()
        self._refresh_selections()
        self._refresh_symbols()
        v = self.view_doc.verdict()
        self.lbl_verdict.setText(v)
        self.lbl_verdict.setToolTip(v)

    def _refresh_layers(self) -> None:
        rep = self.view_doc.report
        self.layer_table.setRowCount(len(rep.layers))
        for r, (name, st) in enumerate(rep.layers.items()):
            title = LAYER_TITLE.get(name, name)
            a = QtWidgets.QTableWidgetItem(title)
            state = st.state.value
            b = QtWidgets.QTableWidgetItem(STATE_TEXT.get(state, state))
            b.setForeground(QtGui.QBrush(QtGui.QColor(
                STATE_COLOUR.get(state, "#000"))))
            f = b.font()
            f.setBold(True)
            b.setFont(f)
            note = st.note or ""
            if st.ran_at:
                note = f"{note}   ({st.ran_at})" if note else st.ran_at
            c = QtWidgets.QTableWidgetItem(note)
            for item in (a, b, c):
                item.setToolTip(f"{title}: {STATE_TEXT.get(state, state)}. "
                                f"{note}")
            a.setData(QtCore.Qt.AccessibleTextRole,
                      f"{title}, {STATE_TEXT.get(state, state)}")
            self.layer_table.setItem(r, 0, a)
            self.layer_table.setItem(r, 1, b)
            self.layer_table.setItem(r, 2, c)
        self.layer_table.resizeColumnsToContents()

    def _refresh_diagnostics(self) -> None:
        self.diag_list.clear()
        needle = self.filter.text().strip().lower()
        want_info = self.show_info.isChecked()
        rank = {"error": 0, "warning": 1, "info": 2}
        rows = sorted(self.view_doc.report.all(),
                      key=lambda d: (rank.get(d.severity, 3), d.line))
        for d in rows:
            if not want_info and d.severity == "info":
                continue
            hay = f"{d.code} {d.message} {d.layer}".lower()
            if needle and needle not in hay:
                continue
            it = QtWidgets.QTreeWidgetItem([
                d.severity.upper(), d.code,
                str(d.line) if d.line else "-", d.message])
            it.setForeground(0, QtGui.QBrush(QtGui.QColor(
                {"error": "#b3261e", "warning": "#b26a00"}
                .get(d.severity, "#5f6368"))))
            it.setData(0, QtCore.Qt.UserRole, d)
            it.setToolTip(3, d.explain)
            self.diag_list.addTopLevelItem(it)
        self.diag_list.setAccessibleDescription(
            f"{self.diag_list.topLevelItemCount()} diagnostics listed")

    def _goto_diagnostic(self, item, _col=0) -> None:
        d = item.data(0, QtCore.Qt.UserRole)
        if d is None:
            return
        self.diag_detail.setPlainText(
            f"[{d.code}] {d.title}\nlayer: {d.layer}   severity: "
            f"{d.severity}\n\n{d.explain}\n\n{d.message}"
            + (f"\n\nevidence:\n{d.evidence}" if d.evidence else "")
            + (f"\n\nsuggestion:\n{d.suggestion}" if d.suggestion else "")
            + (f"\n\nblocks structured editing" if d.blocks_edit else "")
            + (f"\nblocks run-ready export" if d.blocks_export else ""))
        if d.span:
            self.editor.select_span(d.span[0], d.span[1])
        elif d.line:
            block = self.editor.document().findBlockByNumber(max(0, d.line - 1))
            self.editor.select_span(block.position(),
                                    block.position() + block.length() - 1)

    def _refresh_structure(self) -> None:
        self.tree.clear()
        try:
            an = self.view_doc.analysis()
        except Exception:
            return
        src = self.view_doc.source

        def node(parent, a, b, cst_node=None):
            it = QtWidgets.QTreeWidgetItem(parent, [a, b])
            if cst_node is not None:
                it.setData(0, QtCore.Qt.UserRole,
                           (cst_node.start, cst_node.end))
            return it

        decls = QtWidgets.QTreeWidgetItem(self.tree, ["Declarations", ""])
        for d in an.declarations:
            terms = ", ".join(f"{k}={v.span_text(src)}"
                              for k, v in d.terms.items())
            node(decls, d.which, terms, d.node)
        decls.setExpanded(True)

        sels = QtWidgets.QTreeWidgetItem(self.tree, ["Atom selections", ""])
        table = {r["name"]: r for r in
                 getattr(self.view_doc, "selection_table", [])}
        for s in an.selections:
            row = table.get(s.name)
            detail = (f"{row['n']} atoms" if row and row["n"] is not None
                      else "unresolved")
            node(sels, s.name, detail, s.bind)
        sels.setExpanded(True)

        mets = QtWidgets.QTreeWidgetItem(self.tree, ["Metadynamics", ""])
        for m in an.metas:
            label = f"meta(accumulator {m.index})"
            if m.owner:
                label += f" -> {m.owner}"
            detail = m.role
            if m.wt is not None and m.wt.confirmed:
                detail += ", well-tempered"
                if m.wt.ktemp is not None:
                    detail += f" (kDT={m.wt.ktemp:.6g}"
                    if m.wt.h0 is not None:
                        detail += f", h0={m.wt.h0:.6g}"
                    detail += ")"
            elif m.role != sema.PROBE and m.wt is not None:
                detail += ", well-tempering not confirmed"
            it = node(mets, label, detail, m.node)
            if m.wt is not None:
                node(it, "evidence", m.wt.evidence)
            if m.n_cvs is not None:
                node(it, "collective variables", str(m.n_cvs))
        mets.setExpanded(True)

        en = QtWidgets.QTreeWidgetItem(self.tree, ["Applied potential", ""])
        if an.energy_stmt is not None:
            node(en, "final expression",
                 an.energy_stmt.span_text(src).strip(), an.energy_stmt)
        for c in an.contributions:
            tag = "OPAQUE - not modelled" if c.opaque else \
                (", ".join(sorted(c.kinds)) or "term")
            node(en, c.label, tag, c.node)
        en.setExpanded(True)

        unk = QtWidgets.QTreeWidgetItem(
            self.tree, ["Preserved but not modelled", ""])
        for name, nodes in an.unknown_functions.items():
            node(unk, f"{name}()", f"{len(nodes)} call(s), kept verbatim",
                 nodes[0])
        for o in self.view_doc.parsed().opaque_nodes:
            node(unk, "unparsed statement",
                 o.span_text(src).strip()[:70], o)
        unk.setExpanded(True)

    def _refresh_selections(self) -> None:
        rows = getattr(self.view_doc, "selection_table", [])
        self.sel_table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            vals = [row["name"],
                    "-" if row["n"] is None else str(row["n"]),
                    ",".join(row["chains"]) or "-",
                    ", ".join(row["residues"][:6]) or (row["note"] or "-"),
                    row["asl"]]
            for c, v in enumerate(vals):
                self.sel_table.setItem(r, c, QtWidgets.QTableWidgetItem(v))
        self.sel_table.resizeColumnsToContents()

    def _refresh_symbols(self) -> None:
        try:
            an = self.view_doc.analysis()
        except Exception:
            return
        cur = self.sym_box.currentText()
        self.sym_box.blockSignals(True)
        self.sym_box.clear()
        self.sym_box.addItems(an.order)
        if cur in an.order:
            self.sym_box.setCurrentText(cur)
        self.sym_box.blockSignals(False)
        self._refresh_depends(self.sym_box.currentText())

    def _refresh_depends(self, name: str) -> None:
        try:
            an = self.view_doc.analysis()
        except Exception:
            return
        sym = an.symbols.get(name)
        if sym is None:
            self.depends.setPlainText("")
            return
        src = self.view_doc.source

        def closure(start, graph):
            seen, stack = set(), list(graph.get(start, ()))
            while stack:
                n = stack.pop()
                if n in seen:
                    continue
                seen.add(n)
                stack.extend(graph.get(n, ()))
            return sorted(seen)

        lines = [
            f"{name} = {sym.value.span_text(src).strip()}",
            f"  defined at line {sym.line}",
            f"  type            {sym.type}",
            f"  reaches the potential : {'yes' if sym.reaches_energy else 'no'}",
            f"  reaches a side effect : "
            f"{'yes' if sym.reaches_side_effect else 'no'}",
            "",
            "reads directly:   " + (", ".join(sorted(sym.deps)) or "nothing"),
            "reads in total:   " + (", ".join(closure(name, an.graph))
                                    or "nothing"),
            "read directly by: " + (", ".join(sorted(an.users.get(name, ())))
                                    or "nothing"),
            "read in total by: " + (", ".join(closure(name, an.users))
                                    or "nothing"),
            "",
            f"used at {len(sym.uses)} place(s):",
        ]
        for u in sym.uses[:40]:
            from ..core.lang.lexer import position
            ln, col = position(src, u.start)
            lines.append(f"   line {ln}:{col}")
        self.depends.setPlainText("\n".join(lines))

    def _goto_node(self, item, _col=0) -> None:
        span = item.data(0, QtCore.Qt.UserRole)
        if span:
            self.editor.select_span(span[0], span[1])


def main(argv=None) -> int:
    import sys
    argv = list(sys.argv if argv is None else argv)
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(argv)
    from . import theme
    app.setStyleSheet(theme.QSS)
    w = SourceWindow(argv[1] if len(argv) > 1 else "")
    w.show()
    return app.exec_()


if __name__ == "__main__":
    raise SystemExit(main())
