"""Dark theme, colour scales and shared visual constants."""

from __future__ import annotations

import numpy as np

# --------------------------------------------------------------------------
# palette
# --------------------------------------------------------------------------
BG0 = "#10131a"     # window
BG1 = "#171b24"     # panels
BG2 = "#1f2430"     # inputs
BG3 = "#2a3040"     # hover / borders
FG0 = "#e6e9f0"     # primary text
FG1 = "#a8b0c2"     # secondary text
FG2 = "#6f7891"     # disabled
ACCENT = "#4da3ff"
ACCENT_DIM = "#2b6fb5"
GOOD = "#49c98a"
WARN = "#e8b64c"
BAD = "#ef5f5f"
INFO = "#7aa2f7"
LIGAND = "#ff8f3f"
HANDLE = "#ffd166"
HANDLE_HOT = "#ff5d5d"

VIEW_BG_TOP = (0.055, 0.065, 0.095)
VIEW_BG_BOTTOM = (0.015, 0.018, 0.028)

CHAIN_COLORS = [
    (0.35, 0.70, 0.95), (0.98, 0.62, 0.30), (0.55, 0.85, 0.50),
    (0.90, 0.45, 0.75), (0.95, 0.85, 0.40), (0.55, 0.55, 0.95),
    (0.45, 0.90, 0.85), (0.85, 0.55, 0.45), (0.75, 0.75, 0.80),
]

SS_COLORS = {
    1: (0.95, 0.40, 0.45),      # helix
    2: (0.95, 0.85, 0.35),      # strand
    0: (0.60, 0.68, 0.80),      # loop / coil
    -1: (0.50, 0.55, 0.65),
}

# --------------------------------------------------------------------------
# potential colour scales:  0 kcal/mol -> blue,  max -> red
# --------------------------------------------------------------------------
COLOR_SCALES: dict[str, list[tuple[float, tuple[float, float, float]]]] = {
    "Blue → Red": [
        (0.00, (0.12, 0.38, 0.98)),
        (0.25, (0.20, 0.62, 0.95)),
        (0.50, (0.62, 0.42, 0.92)),
        (0.75, (0.95, 0.35, 0.55)),
        (1.00, (0.98, 0.16, 0.12)),
    ],
    "Blue → Cyan → Red": [
        (0.00, (0.10, 0.30, 0.95)),
        (0.33, (0.15, 0.85, 0.90)),
        (0.66, (0.98, 0.80, 0.25)),
        (1.00, (0.95, 0.15, 0.15)),
    ],
    "Cool → Warm": [
        (0.00, (0.23, 0.30, 0.75)),
        (0.50, (0.86, 0.86, 0.86)),
        (1.00, (0.71, 0.02, 0.15)),
    ],
    "Ice → Fire": [
        (0.00, (0.55, 0.80, 1.00)),
        (0.35, (0.25, 0.45, 0.95)),
        (0.70, (0.85, 0.35, 0.55)),
        (1.00, (1.00, 0.75, 0.20)),
    ],
}
DEFAULT_SCALE = "Blue → Red"


def scale_rgb(name: str, t) -> np.ndarray:
    """Sample a named colour scale at ``t`` in [0, 1] (scalar or array)."""
    stops = COLOR_SCALES.get(name) or COLOR_SCALES[DEFAULT_SCALE]
    xs = np.array([s[0] for s in stops])
    cols = np.array([s[1] for s in stops])
    t = np.clip(np.asarray(t, dtype=float), 0.0, 1.0)
    out = np.empty(t.shape + (3,), dtype=float)
    for k in range(3):
        out[..., k] = np.interp(t, xs, cols[:, k])
    return out


def make_lut(name: str, vmin: float, vmax: float, n: int = 256,
             max_opacity: float = 0.55, zero_transparent: bool = True):
    """A vtkLookupTable for the potential, transparent at the flat bottom."""
    import vtk
    lut = vtk.vtkLookupTable()
    lut.SetNumberOfTableValues(n)
    lut.SetRange(vmin, vmax)
    ts = np.linspace(0.0, 1.0, n)
    cols = scale_rgb(name, ts)
    for i, t in enumerate(ts):
        a = max_opacity * (t ** 0.6) if zero_transparent else max_opacity
        lut.SetTableValue(i, float(cols[i, 0]), float(cols[i, 1]),
                          float(cols[i, 2]), float(a))
    lut.Build()
    return lut


# --------------------------------------------------------------------------
# stylesheet
# --------------------------------------------------------------------------
QSS = f"""
* {{
    font-family: "Inter", "Segoe UI", "DejaVu Sans", sans-serif;
    font-size: 12px;
}}
QMainWindow, QDialog {{ background: {BG0}; }}
QWidget {{ color: {FG0}; }}
QLabel {{ color: {FG0}; background: transparent; }}
QLabel[dim="true"] {{ color: {FG1}; }}
QLabel[role="value"] {{
    color: {ACCENT}; font-family: "JetBrains Mono", "DejaVu Sans Mono", monospace;
    font-size: 12px;
}}
QLabel[role="head"] {{
    color: {FG1}; font-size: 10px; font-weight: 700;
    letter-spacing: 1px; text-transform: uppercase;
}}
QGroupBox {{
    background: {BG1}; border: 1px solid {BG3}; border-radius: 8px;
    margin-top: 14px; padding: 10px 8px 8px 8px; font-weight: 600;
}}
QGroupBox::title {{
    subcontrol-origin: margin; subcontrol-position: top left;
    left: 10px; top: 1px; padding: 2px 6px; color: {FG1};
    font-size: 10px; letter-spacing: 1px;
}}
QDockWidget {{ color: {FG1}; titlebar-close-icon: none; }}
QDockWidget::title {{
    background: {BG1}; padding: 6px 10px; border-bottom: 1px solid {BG3};
    font-size: 10px; letter-spacing: 1px; text-transform: uppercase;
}}
QTabWidget::pane {{ border: 1px solid {BG3}; border-radius: 8px; background: {BG1}; }}
QTabBar::tab {{
    background: transparent; color: {FG1}; padding: 7px 14px;
    border-bottom: 2px solid transparent; margin-right: 2px;
}}
QTabBar::tab:selected {{ color: {FG0}; border-bottom: 2px solid {ACCENT}; }}
QTabBar::tab:hover {{ color: {FG0}; background: {BG2}; border-top-left-radius: 6px;
                      border-top-right-radius: 6px; }}
QPushButton {{
    background: {BG2}; border: 1px solid {BG3}; border-radius: 6px;
    padding: 6px 12px; color: {FG0};
}}
QPushButton:hover {{ background: {BG3}; border-color: {ACCENT_DIM}; }}
QPushButton:pressed {{ background: {ACCENT_DIM}; }}
QPushButton:disabled {{ color: {FG2}; background: {BG1}; }}
QPushButton[accent="true"] {{
    background: {ACCENT_DIM}; border-color: {ACCENT}; color: white; font-weight: 600;
}}
QPushButton[accent="true"]:hover {{ background: {ACCENT}; }}
QPushButton[flat="true"] {{ background: transparent; border: none; padding: 4px 8px; }}
QPushButton[flat="true"]:hover {{ background: {BG2}; }}
QToolButton {{
    background: transparent; border: 1px solid transparent; border-radius: 6px;
    padding: 5px 8px; color: {FG0};
}}
QToolButton:hover {{ background: {BG2}; border-color: {BG3}; }}
QToolButton:checked {{ background: {ACCENT_DIM}; border-color: {ACCENT}; }}
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox, QPlainTextEdit, QTextEdit {{
    background: {BG2}; border: 1px solid {BG3}; border-radius: 6px;
    padding: 4px 6px; color: {FG0}; selection-background-color: {ACCENT_DIM};
}}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {{
    border-color: {ACCENT};
}}
QDoubleSpinBox, QSpinBox {{
    font-family: "JetBrains Mono", "DejaVu Sans Mono", monospace;
}}
QComboBox::drop-down {{ border: none; width: 20px; }}
QComboBox::down-arrow {{
    width: 0; height: 0; margin-right: 7px;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 5px solid {FG1};
}}
QComboBox::down-arrow:hover {{ border-top-color: {ACCENT}; }}
QSpinBox::up-button, QDoubleSpinBox::up-button,
QSpinBox::down-button, QDoubleSpinBox::down-button {{
    background: {BG3}; border: none; width: 13px; border-radius: 3px;
    margin: 1px;
}}
QSpinBox::up-button:hover, QDoubleSpinBox::up-button:hover,
QSpinBox::down-button:hover, QDoubleSpinBox::down-button:hover {{
    background: {ACCENT_DIM};
}}
QSpinBox::up-arrow, QDoubleSpinBox::up-arrow {{
    width: 0; height: 0;
    border-left: 3px solid transparent; border-right: 3px solid transparent;
    border-bottom: 4px solid {FG0};
}}
QSpinBox::down-arrow, QDoubleSpinBox::down-arrow {{
    width: 0; height: 0;
    border-left: 3px solid transparent; border-right: 3px solid transparent;
    border-top: 4px solid {FG0};
}}
QComboBox QAbstractItemView {{
    background: {BG2}; border: 1px solid {BG3}; selection-background-color: {ACCENT_DIM};
    outline: none;
}}
QSlider::groove:horizontal {{
    height: 4px; background: {BG3}; border-radius: 2px;
}}
QSlider::handle:horizontal {{
    width: 12px; height: 12px; margin: -5px 0; border-radius: 6px;
    background: {ACCENT};
}}
QSlider::sub-page:horizontal {{ background: {ACCENT_DIM}; border-radius: 2px; }}
QCheckBox, QRadioButton {{ spacing: 7px; }}
QCheckBox::indicator, QRadioButton::indicator {{
    width: 14px; height: 14px; border: 1px solid {BG3}; background: {BG2};
    border-radius: 4px;
}}
QRadioButton::indicator {{ border-radius: 7px; }}
QCheckBox::indicator:checked, QRadioButton::indicator:checked {{
    background: {ACCENT}; border-color: {ACCENT};
}}
QTableWidget, QTreeWidget, QListWidget {{
    background: {BG1}; border: 1px solid {BG3}; border-radius: 6px;
    gridline-color: {BG3}; alternate-background-color: {BG2};
    selection-background-color: {ACCENT_DIM}; outline: none;
}}
QHeaderView::section {{
    background: {BG2}; color: {FG1}; border: none;
    border-bottom: 1px solid {BG3}; padding: 5px 6px; font-size: 10px;
    letter-spacing: 0.6px;
}}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {BG3}; border-radius: 5px; min-height: 24px; }}
QScrollBar::handle:vertical:hover {{ background: {ACCENT_DIM}; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: {BG3}; border-radius: 5px; min-width: 24px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QStatusBar {{ background: {BG1}; color: {FG1}; border-top: 1px solid {BG3}; }}
QStatusBar QLabel {{ color: {FG1}; }}
QMenuBar {{ background: {BG0}; color: {FG0}; }}
QMenuBar::item {{ padding: 6px 11px; background: transparent; }}
QMenuBar::item:selected {{ background: {BG2}; border-radius: 5px; }}
QMenu {{ background: {BG1}; border: 1px solid {BG3}; padding: 5px; }}
QMenu::item {{ padding: 6px 22px 6px 20px; border-radius: 5px; }}
QMenu::item:selected {{ background: {ACCENT_DIM}; }}
QMenu::separator {{ height: 1px; background: {BG3}; margin: 5px 8px; }}
QToolBar {{ background: {BG1}; border-bottom: 1px solid {BG3}; spacing: 3px; padding: 4px; }}
QToolBar::separator {{ background: {BG3}; width: 1px; margin: 4px 6px; }}
QSplitter::handle {{ background: {BG0}; }}
QSplitter::handle:hover {{ background: {ACCENT_DIM}; }}
QProgressBar {{
    background: {BG2}; border: 1px solid {BG3}; border-radius: 6px;
    text-align: center; color: {FG0}; height: 16px;
}}
QProgressBar::chunk {{ background: {ACCENT_DIM}; border-radius: 5px; }}
QToolTip {{
    background: {BG2}; color: {FG0}; border: 1px solid {ACCENT_DIM};
    padding: 5px 7px; border-radius: 5px;
}}
"""
