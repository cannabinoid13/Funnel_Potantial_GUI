"""The 3-D view: structure, funnel, draggable handles, atom picking."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import vtk
from PyQt5 import QtCore, QtWidgets
from vtk.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor

from . import theme
from .reps import (RepBuilder, RepStyle, box_actor, sphere_actor,
                   caption_actor)
from .funnel_actors import FunnelVisual, Handle, scalar_bar

GROUPS = ["protein", "ligand", "cofactor", "ions", "water"]

DEFAULT_STYLES = {
    "protein": RepStyle("Cartoon (tube)", "Secondary structure", 1.0),
    "ligand": RepStyle("Ball & stick", "Element", 1.0, scale=1.15,
                       show_hydrogens=False),
    "cofactor": RepStyle("Licorice", "Element", 1.0),
    "ions": RepStyle("Spheres (VdW)", "Element", 0.9, scale=0.55),
    "water": RepStyle("Hidden", "Element", 0.65, scale=0.5),
}


@dataclass
class SceneOptions:
    show_box: bool = True
    show_site_core: bool = True
    show_labels: bool = True
    label_site_core: bool = False
    water_within_funnel: bool = True
    water_radius: float = 0.0
    orthographic: bool = False
    depth_peeling: bool = True
    scalar_bar: bool = True
    snap: float = 0.0
    fine_modifier: bool = True


class _Style(vtk.vtkInteractorStyleTrackballCamera):
    """Trackball camera plus handle dragging and atom picking.

    Handles are picked on the CPU from the mouse ray rather than with VTK's
    hardware picker: the hardware pass returns whatever translucent shell
    happens to be in front, which made the handles impossible to grab, and it
    depends on the driver.  Screen-space distance to the handle centre is
    predictable and ignores anything drawn over it.
    """

    #: how close, in pixels, the cursor has to be to grab a handle
    PICK_RADIUS = 18.0

    def __init__(self, viewer: "Viewer3D"):
        super().__init__()
        self.v = viewer
        self._drag: Handle | None = None
        self._t0 = 0.0
        self._v0 = 0.0
        self._extra = {}
        self._ids = []
        for event, cb in (("LeftButtonPressEvent", self._down),
                          ("LeftButtonReleaseEvent", self._up),
                          ("MouseMoveEvent", self._move)):
            self._ids.append(self.AddObserver(event, cb, 10.0))

    # -- helpers
    def _pos(self):
        return self.GetInteractor().GetEventPosition()

    def _abort(self):
        """Stop the event here, so the camera does not also react."""
        for tag in self._ids:
            cmd = self.GetCommand(tag)
            if cmd is not None:
                cmd.SetAbortFlag(1)

    def _pick_handle(self, x, y) -> Handle | None:
        v = self.v
        handles = v.funnel.handles
        if not handles:
            return None
        ren = v.ren
        cam = ren.GetActiveCamera()
        eye = np.asarray(cam.GetPosition())
        best, best_d, best_depth = None, 1e18, 1e18
        for h in handles:
            c = np.asarray(h.actor.GetCenter(), dtype=float)
            ren.SetWorldPoint(float(c[0]), float(c[1]), float(c[2]), 1.0)
            ren.WorldToDisplay()
            dx, dy, _dz = ren.GetDisplayPoint()
            d = float(np.hypot(dx - x, dy - y))
            if d > self.PICK_RADIUS:
                continue
            depth = float(np.linalg.norm(c - eye))
            # nearest to the cursor, and among those the nearest to the eye
            if d < best_d - 4.0 or (abs(d - best_d) <= 4.0
                                    and depth < best_depth):
                best, best_d, best_depth = h, d, depth
        return best

    # -- events
    def _down(self, obj, ev):
        x, y = self._pos()
        h = self._pick_handle(x, y)
        if h is not None:
            self._drag = h
            self.v.handleGrabbed.emit(h.key)
            self._t0, self._v0, self._extra = self.v.handle_drag_start(h, x, y)
            self.v.funnel.highlight(h)
            self.v.render()
            self._abort()
            return
        if self.v.pick_mode:
            idx = self.v.pick_atom(x, y)
            if idx:
                self.v.atomPicked.emit(idx)
            self._abort()
            return
        self.OnLeftButtonDown()

    def _move(self, obj, ev):
        x, y = self._pos()
        if self._drag is not None:
            self.v.handle_drag_move(self._drag, x, y, self._t0, self._v0,
                                    self._extra, self._modifier_scale())
            self._abort()
            return
        self.OnMouseMove()
        self.v.hover(x, y)

    def _up(self, obj, ev):
        if self._drag is not None:
            h = self._drag
            self._drag = None
            self.v.funnel.highlight(None)
            self.v.handleReleased.emit(h.key)
            self.v.render()
            self._abort()
            return
        self.OnLeftButtonUp()

    def _modifier_scale(self) -> float:
        it = self.GetInteractor()
        if not self.v.options.fine_modifier:
            return 1.0
        shift = bool(it.GetShiftKey())
        ctrl = bool(it.GetControlKey())
        if shift and ctrl:
            return 0.01
        if ctrl:
            return 0.05
        if shift:
            return 0.2
        return 1.0


class Viewer3D(QtWidgets.QWidget):
    handleGrabbed = QtCore.pyqtSignal(str)
    handleDragged = QtCore.pyqtSignal(str, float)
    handleReleased = QtCore.pyqtSignal(str)
    atomPicked = QtCore.pyqtSignal(int)
    atomHovered = QtCore.pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.depth_peeling_available = False
        self.structure = None
        self.model = None
        self.styles = {k: DEFAULT_STYLES[k] for k in GROUPS}
        self.options = SceneOptions()
        self.pick_mode = False
        self._group_actors: dict[str, list] = {k: [] for k in GROUPS}
        self._aux_actors: list = []
        self._bar = None
        self._pick_xyz = np.zeros((0, 3))
        self._pick_idx = np.zeros(0, dtype=int)
        self._hover_last = None
        self._dragging = False
        #: callable(handle key) -> current value, supplied by the main window
        self.value_of = None

        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.vtkw = QVTKRenderWindowInteractor(self)
        lay.addWidget(self.vtkw)

        self.ren = vtk.vtkRenderer()
        self.ren.SetBackground(*theme.VIEW_BG_BOTTOM)
        self.ren.SetBackground2(*theme.VIEW_BG_TOP)
        self.ren.GradientBackgroundOn()
        self.ren.SetTwoSidedLighting(True)
        rw = self.vtkw.GetRenderWindow()
        rw.AddRenderer(self.ren)
        # Depth peeling gives correct ordering for the nested transparent
        # funnel shells, but it needs alpha planes: without them VTK drops
        # translucent geometry altogether, so probe the context first.
        rw.SetAlphaBitPlanes(1)
        rw.SetMultiSamples(0)
        self.ren.SetMaximumNumberOfPeels(8)
        self.ren.SetOcclusionRatio(0.02)
        self.ren.UseDepthPeelingOff()

        # A second, depth-cleared layer for the drag handles: they have to
        # stay visible and grabbable even when a translucent shape is drawn
        # in front of them.
        rw.SetNumberOfLayers(2)
        self.ren_overlay = vtk.vtkRenderer()
        self.ren_overlay.SetLayer(1)
        self.ren_overlay.InteractiveOff()
        self.ren_overlay.SetActiveCamera(self.ren.GetActiveCamera())
        self.ren_overlay.PreserveDepthBufferOff()
        rw.AddRenderer(self.ren_overlay)

        self.iren = rw.GetInteractor()
        self.style = _Style(self)
        self.iren.SetInteractorStyle(self.style)

        self.funnel = FunnelVisual(self.ren, overlay=self.ren_overlay)
        self._setup_lights()
        self._setup_axes()
        self.vtkw.Initialize()
        QtCore.QTimer.singleShot(0, self._probe_transparency)

    # ------------------------------------------------------------------
    def _probe_transparency(self) -> None:
        """Enable depth peeling only when the GL context can support it."""
        rw = self.vtkw.GetRenderWindow()
        try:
            rw.Render()
        except Exception:
            return
        alpha = int(rw.GetAlphaBitPlanes() or 0)
        want = self.options.depth_peeling and alpha >= 1
        self.ren.SetUseDepthPeeling(1 if want else 0)
        self.depth_peeling_available = alpha >= 1
        rw.Render()
        if self.ren.GetLastRenderingUsedDepthPeeling() and not want:
            self.ren.SetUseDepthPeeling(0)

    def set_depth_peeling(self, on: bool) -> None:
        rw = self.vtkw.GetRenderWindow()
        alpha = int(rw.GetAlphaBitPlanes() or 0)
        self.options.depth_peeling = on
        self.ren.SetUseDepthPeeling(1 if (on and alpha >= 1) else 0)
        self.render()
        return alpha >= 1

    # ------------------------------------------------------------------
    def _setup_lights(self) -> None:
        self.ren.RemoveAllLights()
        kit = vtk.vtkLightKit()
        kit.SetKeyLightIntensity(1.05)
        kit.SetKeyLightWarmth(0.58)
        kit.SetFillLightWarmth(0.45)
        kit.SetKeyToFillRatio(2.4)
        kit.SetKeyToHeadRatio(3.2)
        kit.SetKeyToBackRatio(3.0)
        kit.AddLightsToRenderer(self.ren)

    def _setup_axes(self) -> None:
        axes = vtk.vtkAxesActor()
        axes.SetXAxisLabelText("x")
        axes.SetYAxisLabelText("y")
        axes.SetZAxisLabelText("z")
        for cap in (axes.GetXAxisCaptionActor2D(), axes.GetYAxisCaptionActor2D(),
                    axes.GetZAxisCaptionActor2D()):
            cap.GetCaptionTextProperty().SetColor(0.75, 0.8, 0.9)
            cap.GetCaptionTextProperty().SetFontSize(10)
            cap.GetCaptionTextProperty().ShadowOff()
        self.marker = vtk.vtkOrientationMarkerWidget()
        self.marker.SetOrientationMarker(axes)
        self.marker.SetInteractor(self.iren)
        self.marker.SetViewport(0.0, 0.0, 0.14, 0.19)
        self.marker.SetEnabled(1)
        self.marker.InteractiveOff()

    def render(self) -> None:
        self.vtkw.GetRenderWindow().Render()

    # ------------------------------------------------------------------
    # scene assembly
    # ------------------------------------------------------------------
    def set_job(self, structure, model, view: str = "side") -> None:
        self.structure = structure
        self.model = model
        self.builder = RepBuilder(structure, model) if structure is not None else None
        self.rebuild_structure()
        self.rebuild_funnel()
        self.reset_camera(along_axis=(view == "axis"), side=(view == "side"))

    def rebuild_all(self) -> None:
        self.rebuild_structure()
        self.rebuild_funnel()
        self.render()

    def group_mask(self, group: str) -> np.ndarray | None:
        st = self.structure
        if st is None:
            return None
        if group == "protein":
            return st.mask("protein")
        if group == "ligand":
            if self.model is None or not self.model.spec.lig.indices:
                return np.zeros(st.n_atoms, dtype=bool)
            idx = self.model.spec.lig.idx0()
            idx = idx[(idx >= 0) & (idx < st.n_atoms)]
            m = np.zeros(st.n_atoms, dtype=bool)
            for i in idx:                      # whole residues, so H shows too
                r = st.residue_of_atom(int(i))
                if r is not None:
                    m[r.first:r.last] = True
            return m
        if group == "cofactor":
            m = st.mask("hetero") & ~st.mask("ion")
            lig = self.group_mask("ligand")
            if lig is not None:
                m = m & ~lig
            return m
        if group == "ions":
            return st.mask("ion")
        if group == "water":
            m = st.mask("water")
            if self.options.water_within_funnel and self.model is not None:
                keep = np.zeros(st.n_atoms, dtype=bool)
                sel = self.model.atoms_in_funnel(m)
                # keep whole molecules
                for i in sel:
                    r = st.residue_of_atom(int(i))
                    if r is not None:
                        keep[r.first:r.last] = True
                m = keep
            elif self.options.water_radius > 0 and self.model is not None:
                fr = self.model.frame
                d = np.linalg.norm(st.xyz - fr.origin, axis=1)
                m = m & (d < self.options.water_radius)
            return m
        return None

    def rebuild_structure(self) -> None:
        if self.structure is None:
            return
        for g, actors in self._group_actors.items():
            for a in actors:
                self.ren.RemoveViewProp(a)
        self._group_actors = {k: [] for k in GROUPS}
        for a in self._aux_actors:
            self.ren.RemoveViewProp(a)
        self._aux_actors = []

        for g in GROUPS:
            style = self.styles[g]
            if style.representation == "Hidden":
                continue
            mask = self.group_mask(g)
            if mask is None or not mask.any():
                continue
            actors = self.builder.build(mask, style)
            for a in actors:
                if a is None:
                    continue
                a.PickableOff()
                self.ren.AddViewProp(a)
                self._group_actors[g].append(a)

        if self.options.show_box:
            ac = box_actor(self.structure.box,
                           center=self.structure.box_center)
            self.ren.AddViewProp(ac)
            self._aux_actors.append(ac)
        if self.options.show_site_core and self.model is not None:
            self._add_site_core()
        self._build_pick_index()

    def _add_site_core(self) -> None:
        st, sp = self.structure, self.model.spec
        for sel, col, tag in ((sp.site, (0.30, 0.85, 0.95), "SITE"),
                              (sp.core, (0.55, 0.95, 0.60), "CORE")):
            idx = sel.idx0()
            idx = idx[(idx >= 0) & (idx < st.n_atoms)]
            for i in idx:
                ac = sphere_actor(st.xyz[i], 0.42, col, opacity=0.9, res=14)
                ac.PickableOff()
                self.ren.AddViewProp(ac)
                self._aux_actors.append(ac)
            if self.options.show_labels and self.options.label_site_core \
                    and idx.size:
                shown = set()
                for i in idx:
                    r = st.residue_of_atom(int(i))
                    if r is None or r.long_label in shown:
                        continue
                    shown.add(r.long_label)
                    ac = caption_actor(f"{tag} {r.label}",
                                       st.xyz[i] + np.array([0, 0, 0.9]),
                                       col, 10)
                    ac.PickableOff()
                    self.ren.AddViewProp(ac)
                    self._aux_actors.append(ac)

    def rebuild_funnel(self, fast: bool = False) -> None:
        if self.model is None:
            return
        style = self.funnel.style
        if fast:
            keep = (style.show_section, style.show_volume)
            style.show_section = False
            style.show_volume = False
            self.funnel.rebuild(self.model)
            style.show_section, style.show_volume = keep
        else:
            self.funnel.rebuild(self.model)
        self._update_scalar_bar()

    def _update_scalar_bar(self) -> None:
        if self._bar is not None:
            self.ren.RemoveViewProp(self._bar)
            self._bar = None
        if self.options.scalar_bar and self.model is not None:
            self._bar = scalar_bar(self.funnel.style.scale_name,
                                   self.funnel.style.v_max)
            self.ren.AddViewProp(self._bar)

    # ------------------------------------------------------------------
    # picking
    # ------------------------------------------------------------------
    def _build_pick_index(self) -> None:
        st = self.structure
        if st is None:
            self._pick_xyz = np.zeros((0, 3))
            self._pick_idx = np.zeros(0, dtype=int)
            return
        masks = []
        for g in GROUPS:
            if self.styles[g].representation == "Hidden":
                continue
            m = self.group_mask(g)
            if m is not None:
                masks.append(m)
        if not masks:
            self._pick_xyz = np.zeros((0, 3))
            self._pick_idx = np.zeros(0, dtype=int)
            return
        mask = masks[0]
        for m in masks[1:]:
            mask = mask | m
        idx = np.where(mask)[0]
        self._pick_idx = idx
        self._pick_xyz = st.xyz[idx]

    def _ray(self, x, y):
        ren = self.ren
        ren.SetDisplayPoint(x, y, 0.0)
        ren.DisplayToWorld()
        p0 = np.array(ren.GetWorldPoint()[:3])
        ren.SetDisplayPoint(x, y, 1.0)
        ren.DisplayToWorld()
        w = ren.GetWorldPoint()
        p1 = np.array(w[:3]) / (w[3] if abs(w[3]) > 1e-12 else 1.0)
        d = p1 - p0
        n = np.linalg.norm(d)
        return p0, (d / n if n > 0 else np.array([0.0, 0.0, 1.0]))

    def pick_atom(self, x, y, tol: float = 2.2) -> int:
        if len(self._pick_xyz) == 0:
            return 0
        p0, d = self._ray(x, y)
        v = self._pick_xyz - p0
        t = v @ d
        perp = v - np.outer(t, d)
        dist = np.linalg.norm(perp, axis=1)
        ok = (t > 0) & (dist < tol)
        if not ok.any():
            return 0
        cand = np.where(ok)[0]
        best = cand[np.argmin(t[cand] + 3.0 * dist[cand])]
        return int(self._pick_idx[best]) + 1

    def hover(self, x, y) -> None:
        if self.structure is None:
            return
        i = self.pick_atom(x, y, tol=1.6)
        if i != self._hover_last:
            self._hover_last = i
            if i:
                self.atomHovered.emit(self.structure.describe_atom(i))
            else:
                self.atomHovered.emit("")

    # ------------------------------------------------------------------
    # handle dragging
    # ------------------------------------------------------------------
    def _closest_on_line(self, base, direction, x, y) -> float:
        """Parameter along (base + t*direction) closest to the mouse ray."""
        p0, d2 = self._ray(x, y)
        d1 = direction / np.linalg.norm(direction)
        w = p0 - base
        dd = float(d1 @ d2)
        denom = 1.0 - dd * dd
        if abs(denom) < 1e-8:
            return float(w @ d1)
        return float(((w @ d1) - (w @ d2) * dd) / denom)

    def handle_drag_start(self, h: Handle, x, y):
        """Grab a handle: remember where on its line the ray started."""
        base = h.base if h.base is not None else self.model.frame.origin
        direction = (h.direction if h.direction is not None
                     else self.model.frame.axis)
        t0 = self._closest_on_line(base, direction, x, y)
        v0 = 0.0
        if self.value_of is not None:
            try:
                v0 = float(self.value_of(h.key))
            except Exception:
                v0 = 0.0
        self._dragging = True
        return t0, v0, {"base": base, "direction": direction}

    def handle_drag_move(self, h: Handle, x, y, t0, v0, extra, scale) -> None:
        t = self._closest_on_line(extra["base"], extra["direction"], x, y)
        value = v0 + scale * (t - t0)
        snap = self.options.snap
        if snap > 0:
            value = round(value / snap) * snap
        self.handleDragged.emit(h.key, float(value))

    def end_drag(self) -> None:
        self._dragging = False

    # ------------------------------------------------------------------
    # camera
    # ------------------------------------------------------------------
    def funnel_bounds(self, pad: float = 4.0):
        """World bounds of whatever restrains the ligand, padded.

        Returns None when nothing is defined yet, so the camera falls back to
        framing the whole system instead of zooming onto a bare point.
        """
        m = self.model
        if m is None:
            return None
        sp = m.spec
        funnel = sp.funnel_enabled and not m.funnel_is_degenerate()
        if not funnel and not sp.active_terms:
            return None
        z_lo, z_hi, r_out = m.field_bounds(pad=pad)
        fr = m.frame
        corners = []
        for z in (z_lo, z_hi):
            for a in (-r_out, r_out):
                for b in (-r_out, r_out):
                    corners.append(fr.origin + z * fr.axis + a * fr.e1
                                   + b * fr.e2)
        pts = np.asarray(corners)
        lo = pts.min(axis=0)
        hi = pts.max(axis=0)
        return (lo[0], hi[0], lo[1], hi[1], lo[2], hi[2])

    def reset_camera(self, along_axis: bool = False, side: bool = False,
                     bounds=None, zoom: float = 1.35) -> None:
        cam = self.ren.GetActiveCamera()
        cam.SetParallelProjection(self.options.orthographic)
        if self.model is not None and (along_axis or side):
            fr = self.model.frame
            sp = self.model.spec
            center = fr.origin + 0.5 * (sp.z_min + sp.z_max) * fr.axis
            direction = (-fr.axis if along_axis else fr.e1)
            up = fr.e1 if along_axis else fr.axis
            cam.SetFocalPoint(*center)
            cam.SetPosition(*(center + direction * 10.0))
            cam.SetViewUp(*up)
            b = bounds or self.funnel_bounds(pad=4.0)
            if b is not None:
                self.ren.ResetCamera(*b)
            else:
                self.ren.ResetCamera()
            if zoom and zoom != 1.0:
                cam.Zoom(zoom)
        elif bounds is not None:
            self.ren.ResetCamera(*bounds)
            if zoom and zoom != 1.0:
                cam.Zoom(zoom)
        else:
            self.ren.ResetCamera()
        self.ren.ResetCameraClippingRange()
        self.render()

    def view_funnel_axis(self) -> None:
        self.reset_camera(along_axis=True)

    def view_funnel_side(self) -> None:
        self.reset_camera(side=True)
        if self.funnel.style.show_section:
            self.face_section_to_camera()
            self.rebuild_funnel()
            self.render()

    def fit_all(self) -> None:
        self.ren.ResetCamera()
        self.ren.ResetCameraClippingRange()
        self.render()

    def fit_funnel(self) -> None:
        b = self.funnel_bounds(pad=3.0)
        if b is not None:
            self.ren.ResetCamera(*b)
            self.ren.GetActiveCamera().Zoom(1.35)
            self.ren.ResetCameraClippingRange()
        self.render()

    def fit_ligand(self) -> None:
        if self.model is None:
            return self.fit_all()
        c = self.model.frame.lig_com
        r = 12.0
        self.ren.ResetCamera(c[0] - r, c[0] + r, c[1] - r, c[1] + r,
                             c[2] - r, c[2] + r)
        self.ren.GetActiveCamera().Zoom(1.3)
        self.ren.ResetCameraClippingRange()
        self.render()

    def set_orthographic(self, on: bool) -> None:
        self.options.orthographic = on
        self.ren.GetActiveCamera().SetParallelProjection(on)
        self.render()

    def face_section_to_camera(self) -> None:
        """Turn the cross-section plane so the camera looks straight at it."""
        if self.model is None:
            return
        fr = self.model.frame
        cam = self.ren.GetActiveCamera()
        d = np.asarray(cam.GetFocalPoint()) - np.asarray(cam.GetPosition())
        n = np.linalg.norm(d)
        if n < 1e-9:
            return
        d = d / n
        perp = d - (d @ fr.axis) * fr.axis
        if np.linalg.norm(perp) < 1e-6:
            return
        perp /= np.linalg.norm(perp)
        a = float(perp @ fr.e1)
        b = float(perp @ fr.e2)
        self.funnel.style.section_phi = float(np.arctan2(-a, b))

    def screenshot(self, path: str, magnification: int = 2) -> bool:
        rw = self.vtkw.GetRenderWindow()
        rw.Render()
        w2i = vtk.vtkWindowToImageFilter()
        w2i.SetInput(rw)
        try:
            w2i.SetScale(magnification, magnification)
        except AttributeError:
            w2i.SetMagnification(magnification)
        w2i.SetInputBufferTypeToRGBA()
        w2i.ReadFrontBufferOff()
        w2i.Update()
        writer = vtk.vtkPNGWriter()
        writer.SetFileName(path)
        writer.SetInputConnection(w2i.GetOutputPort())
        writer.Write()
        return True
