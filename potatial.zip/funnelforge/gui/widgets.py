"""Reusable widgets: precise numeric editors, readouts, issue tables."""

from __future__ import annotations

from PyQt5 import QtCore, QtGui, QtWidgets

from . import theme


class NoWheelDoubleSpin(QtWidgets.QDoubleSpinBox):
    """A spin box that ignores stray wheel events unless it has focus."""

    def wheelEvent(self, ev):
        if self.hasFocus():
            super().wheelEvent(ev)
        else:
            ev.ignore()


class ParamRow(QtWidgets.QWidget):
    """Label + high-precision spin box + optional slider, emitting one signal.

    The slider is a coarse gesture and the spin box is the exact value; both
    stay in sync, and ``decimals``/``step`` can be tuned per parameter so a
    quantity like the funnel origin can be nudged by 0.001 A.
    """

    valueChanged = QtCore.pyqtSignal(float)

    def __init__(self, label: str, value: float, minimum: float, maximum: float,
                 step: float = 0.1, decimals: int = 3, unit: str = "",
                 slider: bool = True, tip: str = "", parent=None):
        super().__init__(parent)
        self._block = False
        lay = QtWidgets.QHBoxLayout(self)
        lay.setContentsMargins(0, 1, 0, 1)
        lay.setSpacing(6)
        self.label = QtWidgets.QLabel(label)
        self.label.setMinimumWidth(96)
        self.label.setProperty("dim", "true")
        if tip:
            self.label.setToolTip(tip)
            self.setToolTip(tip)
        lay.addWidget(self.label)

        self.spin = NoWheelDoubleSpin()
        self.spin.setRange(minimum, maximum)
        self.spin.setDecimals(decimals)
        self.spin.setSingleStep(step)
        self.spin.setValue(value)
        self.spin.setKeyboardTracking(False)
        self.spin.setMinimumWidth(96)
        self.spin.setAlignment(QtCore.Qt.AlignRight)
        if unit:
            self.spin.setSuffix(" " + unit)
        lay.addWidget(self.spin)

        self.slider = None
        if slider:
            self.slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
            self.slider.setRange(0, 1000)
            self.slider.setValue(self._to_slider(value))
            self.slider.setMinimumWidth(80)
            lay.addWidget(self.slider, 1)
            self.slider.valueChanged.connect(self._from_slider)
        self.spin.valueChanged.connect(self._from_spin)

    # -- conversions
    def _to_slider(self, v: float) -> int:
        lo, hi = self.spin.minimum(), self.spin.maximum()
        if hi <= lo:
            return 0
        return int(round((v - lo) / (hi - lo) * 1000))

    def _from_slider(self, iv: int) -> None:
        if self._block:
            return
        lo, hi = self.spin.minimum(), self.spin.maximum()
        v = lo + (hi - lo) * iv / 1000.0
        self._block = True
        self.spin.setValue(v)
        self._block = False
        self.valueChanged.emit(self.spin.value())

    def _from_spin(self, v: float) -> None:
        if self._block:
            return
        if self.slider is not None:
            self._block = True
            self.slider.setValue(self._to_slider(v))
            self._block = False
        self.valueChanged.emit(v)

    # -- api
    def value(self) -> float:
        return self.spin.value()

    def setValue(self, v: float, silent: bool = True) -> None:
        self._block = silent
        self.spin.setValue(v)
        if self.slider is not None:
            self.slider.setValue(self._to_slider(v))
        self._block = False

    def setRangeKeepValue(self, lo: float, hi: float) -> None:
        """Set the bounds without letting the widget offer a value outside them.

        A spin box stores its range at its own display precision, so a bound
        of -37.70159 becomes -37.7016 - a hundredth of a millipoint *outside*
        the limit it was meant to enforce.  Rounding each bound inward keeps
        the widget's own arithmetic on the legal side of a box face.
        """
        import math
        step = 10.0 ** -self.spin.decimals()
        lo = math.ceil(lo / step) * step
        hi = math.floor(hi / step) * step
        if hi < lo:                      # a range narrower than one step
            lo = hi = 0.5 * (lo + hi)
        v = self.spin.value()
        self._block = True
        self.spin.setRange(lo, hi)
        self.spin.setValue(v)
        if self.slider is not None:
            self.slider.setValue(self._to_slider(v))
        self._block = False

    def setDecimals(self, d: int) -> None:
        self.spin.setDecimals(d)

    def setHighlighted(self, on: bool) -> None:
        self.spin.setStyleSheet(
            f"border-color: {theme.HANDLE};" if on else "")


class IntRow(QtWidgets.QWidget):
    valueChanged = QtCore.pyqtSignal(int)

    def __init__(self, label: str, value: int, minimum: int, maximum: int,
                 unit: str = "", tip: str = "", parent=None):
        super().__init__(parent)
        lay = QtWidgets.QHBoxLayout(self)
        lay.setContentsMargins(0, 1, 0, 1)
        lay.setSpacing(6)
        lbl = QtWidgets.QLabel(label)
        lbl.setMinimumWidth(96)
        lbl.setProperty("dim", "true")
        if tip:
            lbl.setToolTip(tip)
        lay.addWidget(lbl)
        self.spin = QtWidgets.QSpinBox()
        self.spin.setRange(minimum, maximum)
        self.spin.setValue(value)
        self.spin.setKeyboardTracking(False)
        self.spin.setAlignment(QtCore.Qt.AlignRight)
        self.spin.setMinimumWidth(96)
        if unit:
            self.spin.setSuffix(" " + unit)
        lay.addWidget(self.spin)
        lay.addStretch(1)
        self.spin.valueChanged.connect(self.valueChanged.emit)

    def value(self) -> int:
        return self.spin.value()

    def setValue(self, v: int) -> None:
        self.spin.blockSignals(True)
        self.spin.setValue(int(v))
        self.spin.blockSignals(False)


class TextRow(QtWidgets.QWidget):
    editingFinished = QtCore.pyqtSignal(str)

    def __init__(self, label: str, value: str = "", tip: str = "",
                 placeholder: str = "", parent=None):
        super().__init__(parent)
        lay = QtWidgets.QHBoxLayout(self)
        lay.setContentsMargins(0, 1, 0, 1)
        lay.setSpacing(6)
        lbl = QtWidgets.QLabel(label)
        lbl.setMinimumWidth(96)
        lbl.setProperty("dim", "true")
        if tip:
            lbl.setToolTip(tip)
        lay.addWidget(lbl)
        self.edit = QtWidgets.QLineEdit(value)
        if placeholder:
            self.edit.setPlaceholderText(placeholder)
        lay.addWidget(self.edit, 1)
        self.edit.editingFinished.connect(
            lambda: self.editingFinished.emit(self.edit.text()))

    def text(self) -> str:
        return self.edit.text()

    def setText(self, s: str) -> None:
        self.edit.blockSignals(True)
        self.edit.setText(s)
        self.edit.blockSignals(False)


class ComboRow(QtWidgets.QWidget):
    currentChanged = QtCore.pyqtSignal(str)

    def __init__(self, label: str, items: list[str], current: str = "",
                 tip: str = "", parent=None):
        super().__init__(parent)
        lay = QtWidgets.QHBoxLayout(self)
        lay.setContentsMargins(0, 1, 0, 1)
        lay.setSpacing(6)
        lbl = QtWidgets.QLabel(label)
        lbl.setMinimumWidth(96)
        lbl.setProperty("dim", "true")
        if tip:
            lbl.setToolTip(tip)
        lay.addWidget(lbl)
        self.combo = QtWidgets.QComboBox()
        self.combo.addItems(items)
        if current:
            i = self.combo.findText(current)
            if i >= 0:
                self.combo.setCurrentIndex(i)
        lay.addWidget(self.combo, 1)
        self.combo.currentTextChanged.connect(self.currentChanged.emit)

    def currentText(self) -> str:
        return self.combo.currentText()

    def setCurrentText(self, s: str) -> None:
        self.combo.blockSignals(True)
        i = self.combo.findText(s)
        if i >= 0:
            self.combo.setCurrentIndex(i)
        self.combo.blockSignals(False)


class Readout(QtWidgets.QWidget):
    """A compact grid of name -> monospaced value pairs."""

    def __init__(self, keys: list[tuple[str, str]], columns: int = 2, parent=None):
        super().__init__(parent)
        self.values: dict[str, QtWidgets.QLabel] = {}
        grid = QtWidgets.QGridLayout(self)
        grid.setContentsMargins(2, 2, 2, 2)
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(3)
        for n, (key, label) in enumerate(keys):
            r, c = divmod(n, columns)
            lbl = QtWidgets.QLabel(label)
            lbl.setProperty("dim", "true")
            val = QtWidgets.QLabel("-")
            val.setProperty("role", "value")
            val.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
            grid.addWidget(lbl, r, c * 2)
            grid.addWidget(val, r, c * 2 + 1)
            self.values[key] = val
        for c in range(columns):
            grid.setColumnStretch(c * 2 + 1, 1)

    def set(self, key: str, text: str, color: str | None = None) -> None:
        w = self.values.get(key)
        if w is None:
            return
        w.setText(text)
        w.setStyleSheet(f"color: {color};" if color else "")


class SectionTitle(QtWidgets.QWidget):
    def __init__(self, text: str, parent=None):
        super().__init__(parent)
        lay = QtWidgets.QHBoxLayout(self)
        lay.setContentsMargins(0, 6, 0, 2)
        lbl = QtWidgets.QLabel(text.upper())
        lbl.setProperty("role", "head")
        lay.addWidget(lbl)
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.HLine)
        line.setStyleSheet(f"color: {theme.BG3};")
        lay.addWidget(line, 1)


LEVEL_COLOR = {"error": theme.BAD, "warning": theme.WARN,
               "ok": theme.GOOD, "info": theme.INFO}
LEVEL_GLYPH = {"error": "✕", "warning": "!", "ok": "✓", "info": "i"}


class IssueTable(QtWidgets.QTreeWidget):
    """Validation report as a two-level tree (message + detail)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setColumnCount(3)
        self.setHeaderLabels(["", "Area", "Finding"])
        self.setRootIsDecorated(True)
        self.setAlternatingRowColors(True)
        self.header().setStretchLastSection(True)
        self.setColumnWidth(0, 26)
        self.setColumnWidth(1, 86)
        self.setWordWrap(True)

    def set_issues(self, issues) -> None:
        self.clear()
        order = {"error": 0, "warning": 1, "info": 2, "ok": 3}
        for issue in sorted(issues, key=lambda i: order.get(i.level, 4)):
            it = QtWidgets.QTreeWidgetItem(
                [LEVEL_GLYPH.get(issue.level, "?"), issue.category,
                 issue.message])
            col = QtGui.QColor(LEVEL_COLOR.get(issue.level, theme.FG1))
            it.setForeground(0, col)
            if issue.level == "error":
                it.setForeground(2, col)
            f = it.font(2)
            f.setBold(issue.level == "error")
            it.setFont(2, f)
            if issue.detail:
                sub = QtWidgets.QTreeWidgetItem(["", "", issue.detail])
                sub.setForeground(2, QtGui.QColor(theme.FG1))
                it.addChild(sub)
            self.addTopLevelItem(it)
        self.expandAll()


def hline() -> QtWidgets.QFrame:
    f = QtWidgets.QFrame()
    f.setFrameShape(QtWidgets.QFrame.HLine)
    f.setStyleSheet(f"color: {theme.BG3};")
    return f


def scroll_area(inner: QtWidgets.QWidget) -> QtWidgets.QScrollArea:
    sa = QtWidgets.QScrollArea()
    sa.setWidgetResizable(True)
    sa.setFrameShape(QtWidgets.QFrame.NoFrame)
    sa.setWidget(inner)
    sa.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
    return sa


def vbox(*widgets, spacing: int = 4, margins=(8, 6, 8, 6)) -> QtWidgets.QWidget:
    w = QtWidgets.QWidget()
    lay = QtWidgets.QVBoxLayout(w)
    lay.setContentsMargins(*margins)
    lay.setSpacing(spacing)
    for x in widgets:
        if x is None:
            lay.addStretch(1)
        elif isinstance(x, QtWidgets.QLayout):
            lay.addLayout(x)
        else:
            lay.addWidget(x)
    return w


def group(title: str, *widgets, spacing: int = 3) -> QtWidgets.QGroupBox:
    g = QtWidgets.QGroupBox(title)
    lay = QtWidgets.QVBoxLayout(g)
    lay.setContentsMargins(8, 4, 8, 6)
    lay.setSpacing(spacing)
    for x in widgets:
        if x is None:
            lay.addStretch(1)
        elif isinstance(x, QtWidgets.QLayout):
            lay.addLayout(x)
        else:
            lay.addWidget(x)
    return g
