"""Headless validator for Desmond ``.pot`` files.

Runs exactly the layers the desktop interface runs, over the same core
library, so a result in CI and a result on screen cannot disagree::

    python -m funnelforge.potcheck run.pot
    python -m funnelforge.potcheck run.pot --cms run.cms --official
    python -m funnelforge.potcheck *.pot --json > report.json

Exit codes are meant for scripting:

==  ============================================================
0   every layer that ran passed
1   at least one layer reported an error
2   the file could not be read at all
3   the official validator was requested and could not be run
==  ============================================================

The tool never rewrites the input.  ``--format`` is the only mode that
produces text, and it writes to stdout unless ``--in-place`` is given, which
first prints the diff it would apply.
"""

from __future__ import annotations

import argparse
import json
import os
import sys

from .core import safety
from .core.document import Document
from .core.lang import diagnostics as diag


def _severity_rank(d) -> int:
    return {"error": 0, "warning": 1, "info": 2}.get(d.severity, 3)


def _print_report(doc: Document, path: str, show_all: bool,
                  quiet: bool) -> None:
    print(f"== {path}")
    print(doc.report.summary())
    rows = sorted(doc.report.all(), key=lambda d: (_severity_rank(d), d.line))
    if not show_all:
        rows = [d for d in rows if d.severity != "info"]
    for d in rows:
        where = f"{d.line}:{d.col}" if d.line else "-"
        print(f"  {d.severity.upper():7s} {d.code:7s} {where:>9s}  {d.message}")
        if d.evidence and not quiet:
            ev = d.evidence.strip().replace("\n", " ")[:160]
            print(f"          evidence: {ev}")
        if d.suggestion and not quiet:
            print(f"          suggestion: {d.suggestion}")
    print(f"  verdict: {doc.verdict()}")


def _analysis_overview(doc: Document) -> None:
    an = doc.analysis()
    print("  -- structure")
    print(f"     statements        {len(doc.parsed().statements())}")
    print(f"     names             {len(an.symbols)} "
          f"({len(an.reachable)} reach the potential)")
    table = {r["name"]: r for r in getattr(doc, "selection_table", [])}
    for sel in an.selections:
        row = table.get(sel.name)
        if row is None:
            print(f"     selection {sel.name:14s} unresolved (no structure "
                  "supplied)")
        elif row["n"] is None:
            print(f"     selection {sel.name:14s} not understood by this "
                  f"interface: {row['note'][:60]}")
        else:
            who = ", ".join(row["residues"][:4]) or "-"
            print(f"     selection {sel.name:14s} {row['n']:>6} atoms  "
                  f"chain {','.join(row['chains']) or '-'}  {who}")
    for d in an.meta_declarations:
        print(f"     declare_meta #{d.index}    dimension="
              f"{d.dimension} name={d.output_name!r}")
    for m in an.metas:
        tag = m.role
        if m.wt is not None and m.wt.confirmed:
            tag += f", well-tempered (kDT={m.wt.ktemp:.6g})" \
                if m.wt.ktemp is not None else ", well-tempered"
        elif m.role != "probe":
            tag += ", well-tempering not confirmed"
        owner = f" -> {m.owner}" if m.owner else ""
        print(f"     meta(acc {m.index}){owner:20s} {tag}")
    if an.energy_stmt is not None:
        print(f"     potential         "
              f"{an.energy_stmt.span_text(doc.source).strip()}")
    for c in an.contributions:
        mark = "OPAQUE " if c.opaque else ""
        kinds = f" [{', '.join(sorted(c.kinds))}]" if c.kinds else ""
        print(f"       + {mark}{c.label}{kinds}")
    if an.unknown_functions:
        print("     unrecognised      "
              + ", ".join(f"{k}()" for k in sorted(an.unknown_functions))
              + "  (preserved verbatim)")
    for node in doc.parsed().opaque_nodes:
        print(f"     opaque span       "
              f"{node.span_text(doc.source).strip()[:70]!r}")


def _to_json(doc: Document, path: str) -> dict:
    an = doc.analysis()
    return {
        "file": path,
        "revision": doc.rev,
        "verdict": doc.verdict(),
        "layers": {k: {"state": v.state.value, "note": v.note,
                       "ran_at": v.ran_at, "source_rev": v.source_rev}
                   for k, v in doc.report.layers.items()},
        "diagnostics": [
            {"code": d.code, "layer": d.layer, "severity": d.severity,
             "line": d.line, "col": d.col, "message": d.message,
             "evidence": d.evidence[:400], "blocks_export": d.blocks_export}
            for d in doc.report.all()],
        "structure": {
            "statements": len(doc.parsed().statements()),
            "names": len(an.symbols),
            "reaching_potential": sorted(an.reachable),
            "selections": [{"name": s.name, "dim": s.type.dim}
                           for s in an.selections],
            "meta_calls": [
                {"accumulator": m.index, "role": m.role, "owner": m.owner,
                 "cvs": m.n_cvs, "hills": m.n_hills,
                 "well_tempered": bool(m.wt and m.wt.confirmed),
                 "ktemp": (m.wt.ktemp if m.wt else None),
                 "h0": (m.wt.h0 if m.wt else None),
                 "evidence": (m.wt.evidence if m.wt else "")}
                for m in an.metas],
            "contributions": [{"label": c.label, "opaque": c.opaque,
                               "kinds": sorted(c.kinds)}
                              for c in an.contributions],
            "unknown_functions": sorted(an.unknown_functions),
            "opaque_spans": [[n.start, n.end]
                             for n in doc.parsed().opaque_nodes],
        },
        "selection_table": getattr(doc, "selection_table", []),
        "official": (doc.last_official.manifest
                     if getattr(doc, "last_official", None) else None),
        "export_blockers": [{"code": b.code, "message": b.message}
                            for b in doc.export_blockers()],
    }


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        prog="potcheck",
        description="Validate and inspect Desmond .pot files without a GUI.")
    ap.add_argument("files", nargs="*", help="one or more .pot files")
    ap.add_argument("--cms", default="", help="topology to resolve selections "
                                              "against and validate with")
    ap.add_argument("--official", action="store_true",
                    help="run the installed Schrodinger/Desmond parser")
    ap.add_argument("--schrodinger", default="",
                    help="use this installation instead of the newest found")
    ap.add_argument("--timeout", type=float, default=180.0)
    ap.add_argument("--json", action="store_true", help="machine-readable")
    ap.add_argument("--all", action="store_true",
                    help="include informational diagnostics")
    ap.add_argument("--quiet", action="store_true", help="messages only")
    ap.add_argument("--no-overview", action="store_true")
    ap.add_argument("--no-package", action="store_true",
                    help="skip the .msj/.cfg/.sh/.cms cross-file checks")
    ap.add_argument("--msj", default="", help="companion .msj (default: the "
                                              "one beside the .pot)")
    ap.add_argument("--cfg", default="", help="companion .cfg")
    ap.add_argument("--sh", default="", help="companion .sh")
    ap.add_argument("--list-installations", action="store_true")
    ap.add_argument("--max-bytes", type=int,
                    default=safety.DEFAULT_LIMITS.max_file_bytes)
    args = ap.parse_args(argv)

    if not args.files and not args.list_installations:
        ap.error("give at least one .pot file, or --list-installations")

    if args.list_installations:
        from .core.desmond import adapter
        for i in adapter.discover_installations():
            print(f"{i.path}  {i.version or '?'} build {i.build or '?'}  "
                  f"{'usable' if i.usable else i.note}")
        return 0

    inst = None
    if args.schrodinger:
        from .core.desmond import adapter
        inst = next((i for i in adapter.discover_installations()
                     if os.path.realpath(i.path)
                     == os.path.realpath(args.schrodinger)), None)
        if inst is None:
            print(f"no Schrodinger installation at {args.schrodinger}",
                  file=sys.stderr)
            return 3

    limits = safety.Limits(max_file_bytes=args.max_bytes)
    worst = 0
    out: list = []
    for path in args.files:
        try:
            doc = Document.open(path, limits)
        except Exception as exc:
            print(f"{path}: cannot read: {exc}", file=sys.stderr)
            worst = max(worst, 2)
            continue
        doc.run_local_layers()
        if args.cms:
            try:
                doc.resolve_topology(args.cms)
            except Exception as exc:
                print(f"{path}: topology: {exc}", file=sys.stderr)
        if not args.no_package:
            try:
                doc.check_package(args.msj, args.cfg, args.sh, args.cms)
            except Exception as exc:
                print(f"{path}: package: {exc}", file=sys.stderr)
        if args.official:
            res = doc.validate_official(args.cms or None, installation=inst,
                                        timeout=args.timeout)
            if not res.ran:
                worst = max(worst, 3)
        if any(v.state is diag.State.ERROR for v in doc.report.layers.values()):
            worst = max(worst, 1)
        if args.json:
            out.append(_to_json(doc, path))
        else:
            _print_report(doc, path, args.all, args.quiet)
            if not args.no_overview:
                _analysis_overview(doc)
            print()
    if args.json:
        json.dump(out, sys.stdout, indent=1)
        sys.stdout.write("\n")
    return worst


if __name__ == "__main__":
    raise SystemExit(main())
