#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

JOBNAME="AChE-G2N_WT_funnel_MetaD_run"
CMS="${JOBNAME}.cms"
MSJ="${JOBNAME}.msj"
CFG="${JOBNAME}.cfg"
POT="${JOBNAME}.pot"
VALIDATOR="validate_package.py"
PREFLIGHT="preflight_pot.py"
MANIFEST="PACKAGE_MANIFEST.sha256"

if [[ -z "${SCHRODINGER:-}" ]]; then
  echo "ERROR: SCHRODINGER environment variable is not set." >&2
  exit 2
fi

for required in "${CMS}" "${MSJ}" "${CFG}" "${POT}" "${VALIDATOR}" "${PREFLIGHT}" "${MANIFEST}"; do
  if [[ ! -s "${required}" ]]; then
    echo "ERROR: Missing or empty input file: ${required}" >&2
    exit 2
  fi
done

for executable in "${SCHRODINGER}/run" "${SCHRODINGER}/utilities/multisim"; do
  if [[ ! -x "${executable}" ]]; then
    echo "ERROR: Required Schrodinger executable is unavailable: ${executable}" >&2
    exit 2
  fi
done

sha256sum -c "${MANIFEST}"

shopt -s nullglob
existing_outputs=()
literal_outputs=(
    "${JOBNAME}.cvseq" \
    "${JOBNAME}.kerseq" \
    "${JOBNAME}.cpt" \
    "${JOBNAME}-out.cms" \
    "${JOBNAME}_trj" \
    "${JOBNAME}.ene" \
    "${JOBNAME}_simbox.dat" \
    "${JOBNAME}_multisim.log" \
    "${JOBNAME}-multisim_checkpoint"
)
for candidate in "${literal_outputs[@]}"; do
  if [[ -e "${candidate}" || -L "${candidate}" ]]; then
    existing_outputs+=("${candidate}")
  fi
done
for candidate in "${JOBNAME}"-[0-9]*; do
  existing_outputs+=("${candidate}")
done
if (( ${#existing_outputs[@]} > 0 )); then
  echo "ERROR: Existing output/restart material was found; a fresh run will not be launched:" >&2
  printf '  %s\n' "${existing_outputs[@]}" >&2
  echo "Use a clean directory. Do not treat a fresh launch as a restart." >&2
  exit 2
fi

"${SCHRODINGER}/run" "${VALIDATOR}"
"${SCHRODINGER}/run" "${PREFLIGHT}" "${CMS}" "${POT}"

exec "${SCHRODINGER}/utilities/multisim" \
  -JOBNAME "${JOBNAME}" \
  -HOST "${DESMOND_HOST:-localhost}" \
  -maxjob 1 \
  -cpu 1 \
  -m "${MSJ}" \
  -c "${CFG}" \
  -description "Well-Tempered Funnel Metadynamics" \
  "${CMS}" \
  -mode umbrella \
  -o "${JOBNAME}-out.cms" \
  -lic DESMOND_GPGPU:16
