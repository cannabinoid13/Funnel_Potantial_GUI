# AChE-G2N 200 ns / 310 K Well-Tempered Funnel MetaD

Bu paket, verilen 41.986 atomlu AChE-G2N CMS sistemini son doğrulanmış
AChE-G4N/G5N WT-Funnel MetaD protokolüyle çalıştırır.
G2N için Maestro'nun geçici mesafe-MetaD tanımı kullanılmaz; üretim aşaması FILE tabanlı,
tek boyutlu **well-tempered** funnel metadynamics'tir.

## Referans protokolle funnel eşdeğerliği

Aşağıdakiler referans paketle birebir aynıdır:

- protein-bağlı O/U/V referans gruplarının kalıntıları ve omurga atomları;
- eksenin yerel `u/v/w` katsayıları;
- origin'in yerel `u/v/w` uzaklık katsayıları;
- `z_min`, `z_cc`, `z_max`, silindir yarıçapı ve koni eğimi;
- radyal ve eksenel duvar formülleri ve kuvvet sabitleri;
- WT-MetaD boyutu, hill yüksekliği/genişliği/aralığı ve bias factor;
- MD ensemble, süre, sıcaklık, zaman adımları ve çıktı aralıkları;
- takip edilen sekiz kalıntı (Asp74, Trp86, Tyr124, Trp286, Phe297, Tyr337, Phe338, Tyr341), üç gate ölçümü ve Tyr337 rotamerleri.

| Ortak funnel parametresi | Değer |
|---|---:|
| `z_min` | -0.9313 Å |
| `z_cc` | 23.4485 Å |
| `z_max` | 28.948553856514945 Å |
| `r_cyl` | 4.110265665681823 Å |
| `cone_slope` | 0.40890707118416053 |
| Koni yarı açısı | yaklaşık 22.24° |
| `k_rad` | 29.0 kcal mol⁻¹ Å⁻² |
| `k_z` | 50.0 kcal mol⁻¹ Å⁻² |

Protein-bağlı frame:

- O: zincir A, Ser399–His405, omurga N/CA/C/O, 28 atom;
- U: zincir A, Ala528–Asn533, omurga N/CA/C/O, 24 atom;
- V: zincir A, Arg424–Phe430, omurga N/CA/C/O, 28 atom;

Bu sistemdeki başlangıç frame mesafeleri `OU/OV/UV = 11.154314/18.371845/18.651493 Å`; en kısa yarım kutu 34.251897 Å'dır. Bu nedenle minimum-image dalı güvenli kalır.

| Büyüklük | Bu sistemdeki değer |
|---|---|
| Birim eksen | `(0.3997277548580135, -0.9089113780663901, -0.11873427819137787)` |
| Origin | `(1.6612985960336033, -10.245141943749921, -5.061455841391394)` Å |
| Ligand `z` | 1.4353079460726115 Å |
| Ligand `rho` | 1.8267959316755318 Å |
| Başlangıç izinli yarıçap | 13.111615555867706 Å |
| Gram–Schmidt yüksekliği | 17.64600182608874 Å |
| Frame condition sine | 0.9604915315905357 |
| Frame anchor cosine | 0.2783092124649611 |

Ligand `z/rho` değerlerinin referanstan farklı olması beklenir; ligand farklıdır.
Funnel laboratuvar koordinatlarına sabitlenmemiştir; aynı protein omurga referanslarına
aynı yerel katsayılarla bağlıdır. Funnel ligandın COM'una göre yeniden merkezlenmemiş
veya yeniden yöneltilmemiştir.

## Well-tempered bias ve üretim ayarları

- Biaslanan tek CV: zincir B `LIG1:1` G2N ligandının 34 ağır atomlu (C24N6O4), kütle-ağırlıklı COM ilerlemesi `z`.
- `rho`: ikinci MetaD CV'si değildir; yalnız flat-bottom funnel duvarıyla sınırlandırılır.
- Üretim: 200000 ps (200 ns), 310 K, 1.01325 bar, NPT–MTK.
- RESPA: 2/2/6 fs.
- **Well-tempered şema:** `V_old = meta(0,array(0,0),array(z))` sondası ile mevcut bias okunur, `hill = h0*exp(-V_old/kTemp)` ile hill yüksekliği üstel olarak söndürülür.
- İlk hill: 0.25 kcal/mol; `sigma_z = 0.50 Å`; hill aralığı 2 ps.
- Bias factor `gamma = 15`; `kTemp = (gamma-1)·kB·T = 8.624466483 kcal/mol`.
- Kernel cutoff: 9 Gauss genişliği.
- CVSEQ: 2 ps; DTR: 20 ps; enerji/simbox: 2 ps; checkpoint: 500 ps.
- Rastgele hız tohumu: 2007.

200 ns sonunda yaklaşık 100.001 CV kaydı, yaklaşık 100.000 gerçek hill ve 10.001 trajektori karesi beklenir.
Kaynak MSJ'deki sabit 0.03 kcal/mol hill ve 0.09 ps aralık düzeni kullanılmaz.

## Kritik kalıntı paneli

Aynı sekiz yan zincir 2 ps'de izlenir ve ayrı bias CV'si yapılmaz:

`Asp74, Trp86, Tyr124, Trp286, Phe297, Tyr337, Phe338, Tyr341`

CVSEQ şu gözlemleri içerir:

- ligand–sekiz yan zincir COM mesafeleri;
- Tyr124-OH–Phe338-CE2, Asp74-OD2–Tyr341-OH ve Tyr124-OH–Tyr337-OH gate mesafeleri;
- Tyr337 `chi1/chi2` cos–sin çiftleri;
- `z`, `rho`, izinli yarıçap, duvar/bias enerjileri ve frame sağlık ölçüleri.

## Çalıştırma

Paketi temiz ve yazılabilir bir dizine çıkarın:

```bash
chmod +x AChE-G2N_WT_funnel_MetaD_run.sh
./AChE-G2N_WT_funnel_MetaD_run.sh
```

İsteğe bağlı host:

```bash
DESMOND_HOST="localhost:1" ./AChE-G2N_WT_funnel_MetaD_run.sh
```

Başlatıcı sırasıyla paket manifestini, CMS/AID/parametre/geometri kilitlerini,
2.084 rijit dönüş–öteleme–PBC testini ve kurulu Schrödinger ortamında
gerçek `enhsamp.parseStr` POT derlemesini çalıştırır. Eski çıktı saptanırsa üzerine
yazmadan durur.

Üretim sonrası analiz:

```bash
"${SCHRODINGER}/run" analyze_critical_residues.py \
  --cms AChE-G2N_WT_funnel_MetaD_run-out.cms \
  --trajectory AChE-G2N_WT_funnel_MetaD_run_trj \
  --output-dir critical_residue_analysis

python3 analyze_funnel_metad.py \
  --kerseq AChE-G2N_WT_funnel_MetaD_run.kerseq --cvseq AChE-G2N_WT_funnel_MetaD_run.cvseq \
  --gamma 15 --temperature 310 --r-cyl 4.110265665681823
```

> Maestro'nun `meta.py` analiz aracı FILE tabanlı POT işlerini okuyamaz
> (`AttributeError: 'Atom' object has no attribute 'cv'`); FES `analyze_funnel_metad.py`
> ile `.kerseq`'ten yeniden kurulur.

## Sistem kimliği ve karşılaştırılabilirlik

| | Bu paket | Referans (AChE-G5N) |
|---|---|---|
| Toplam atom | 41986 | 43306 |
| Kutu (Å) | 76.781247 × 84.400749 × 68.503793 | 79.667851 × 82.136076 × 70.262673 |
| Ligand ağır atom | 34 (C24N6O4) | 31 (C21N6O4) |
| Ligand AID | 8286–8319 | 8287-8317 |
| Başlangıç `z` (Å) | 1.435308 | 1.792804 |
| Başlangıç `rho` (Å) | 1.826796 | 1.110479 |
| Protonasyon | GLU396, HIS447, GLH450, ASP494 | GLH396, HIS447, GLH450, ASP494 |
| CMS SHA-256 | `76487d225429d22c93ebb73e87159d6a4e11568a89dc5c306e57c0669aaee189` | `e2cbcaf02fc24e5685e88b099e1d3db894d8dafe609875e6c799e33ec5f8103d` |

> **Uyarı — kontrollü karşılaştırma sınırı.** Aşağıdaki mikrodurumlar referans
> paketten farklıdır: `A:396` bu pakette **GLU**, referansta **GLH**.
> Bu bir POT/funnel hatası değildir ve verilen CMS bilinçli olarak değiştirilmemiştir
> (metin düzeyinde değiştirmek kuvvet alanı topolojisini bozardı); ancak
> “yalnız ligand değişti” yorumunu sınırlar. Katı ligand karşılaştırması için her iki
> kompleks aynı protein mikrodurumu ve aynı hazırlama iş akışıyla yeniden oluşturulmalıdır.

