#!/usr/bin/env python3
"""Post-process a FILE-based WT-Funnel MetaD job (.kerseq + .cvseq).

Maestro's own metadynamics analyser ($SCHRODINGER/run -FROM desmond meta.py)
CANNOT read a `meta = FILE` job: it expects the GUI `meta = {cv = [...]}` block
and dies with `AttributeError: 'Atom' object has no attribute 'cv'`.
This script does the job instead, with stock python3 + numpy.

Outputs
  fes.csv               reconstructed 1-D free energy along z
  convergence.csv       block-wise dG and hill-height decay
  walls.csv             funnel wall / frame health statistics from the CVSEQ
  summary.txt           the same numbers in readable form

Usage
  python3 analyze_funnel_metad.py --kerseq JOB.kerseq [--cvseq JOB.cvseq] \
      [--gamma 15] [--temperature 310] [--r-cyl 4.110265665681823] \
      [--bound -1,8] [--bulk 24,28.5] [--outdir funnel_analysis]
"""
from __future__ import annotations

import argparse
import math
from pathlib import Path

import numpy as np

KB = 0.0019872041  # kcal/mol/K


def pair(text):
    lo, hi = text.split(",")
    return float(lo), float(hi)


def load_hills(path):
    data = np.loadtxt(path, comments="#")
    if data.ndim != 2 or data.shape[1] < 4:
        raise SystemExit(f"Unexpected kerseq shape {data.shape}")
    t, h, c, w = data[:, 0], data[:, 1], data[:, 2], data[:, 3]
    keep = h > 0.0          # drop the zero-height well-tempered probe rows
    return t[keep], h[keep], c[keep], w[keep]


def build_fes(z, h, c, w, gamma):
    bias = np.zeros_like(z)
    for i in range(len(h)):
        bias += h[i] * np.exp(-0.5 * ((z - c[i]) / w[i]) ** 2)
    return -(gamma / (gamma - 1.0)) * bias, bias


def binding_free_energy(z, fes, kT, bound, bulk, r_cyl):
    mb = (z >= bulk[0]) & (z <= bulk[1])
    if not mb.any():
        raise SystemExit("bulk window contains no grid points")
    w_ref = fes[mb].mean()
    ms = (z >= bound[0]) & (z <= bound[1])
    dz = z[1] - z[0]
    integral = np.sum(np.exp(-(fes[ms] - w_ref) / kT)) * dz     # Angstrom
    c_std = 1.0 / 1660.5391                                     # A^-3 at 1 M
    return -kT * math.log(c_std * math.pi * r_cyl ** 2 * integral), w_ref


def parse_cvseq(path):
    import re
    pattern = re.compile(r"\[([A-Za-z_0-9]+) \[([^\]]*)\]\]")
    names, rows = None, []
    with open(path) as handle:
        for line in handle:
            kv = pattern.findall(line)
            if not kv:
                continue
            if names is None:
                names = [k for k, _ in kv]
            rows.append([float(v.split()[0]) for _, v in kv])
    if names is None:
        raise SystemExit(f"No CVSEQ records parsed from {path}")
    return names, np.array(rows)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--kerseq", required=True, type=Path)
    ap.add_argument("--cvseq", type=Path)
    ap.add_argument("--gamma", type=float, default=15.0)
    ap.add_argument("--temperature", type=float, default=310.0)
    ap.add_argument("--r-cyl", type=float, default=4.110265665681823)
    ap.add_argument("--bound", type=pair, default=(-1.0, 8.0), help="z window of the bound state")
    ap.add_argument("--bulk", type=pair, default=(24.0, 28.5), help="z window of the bulk plateau")
    ap.add_argument("--blocks", type=int, default=10)
    ap.add_argument("--grid", type=float, default=0.02, help="FES grid spacing (A)")
    ap.add_argument("--outdir", type=Path, default=Path("funnel_analysis"))
    args = ap.parse_args()

    kT = KB * args.temperature
    t, h, c, w = load_hills(args.kerseq)
    args.outdir.mkdir(parents=True, exist_ok=True)
    lines = []
    P = lambda s: (print(s), lines.append(s))

    P(f"hills                 : {len(h)} deposited over {t.min():.1f}-{t.max():.1f} ps")
    P(f"hill height           : {h[0]:.4f} -> {h[-1]:.6f} kcal/mol "
      f"(last 1% mean {h[int(0.99*len(h)):].mean():.6f})")
    P(f"kTemp (gamma-1)kB T   : {(args.gamma - 1) * kT:.9f} kcal/mol")

    z = np.arange(c.min() - 2.0, c.max() + 2.0 + args.grid, args.grid)
    fes, bias = build_fes(z, h, c, w, args.gamma)
    fes -= fes.min()
    dg, w_ref = binding_free_energy(z, fes, kT, args.bound, args.bulk, args.r_cyl)
    P(f"max accumulated bias  : {bias.max():.2f} kcal/mol")
    P(f"standard dG_bind      : {dg:+.2f} kcal/mol "
      f"(bound z in {args.bound}, bulk plateau z in {args.bulk}, R_cyl={args.r_cyl:.3f} A)")

    np.savetxt(args.outdir / "fes.csv",
               np.c_[z, fes, fes - w_ref], delimiter=",",
               header="z_A,F_kcalmol,F_minus_bulk_kcalmol", comments="")

    P("")
    P("convergence (cumulative)")
    P(f"{'t_ns':>7} {'dG':>8} {'W_bulk':>8} {'hill_mean':>10}")
    conv = []
    for b in range(1, args.blocks + 1):
        tf = t.max() * b / args.blocks
        m = t <= tf
        f_b, _ = build_fes(z, h[m], c[m], w[m], args.gamma)
        f_b -= f_b.min()
        try:
            g_b, wr = binding_free_energy(z, f_b, kT, args.bound, args.bulk, args.r_cyl)
        except SystemExit:
            continue
        hm = h[m][-max(1, int(0.1 * m.sum())):].mean()
        conv.append((tf / 1000.0, g_b, wr, hm))
        P(f"{tf/1000:7.1f} {g_b:8.2f} {wr:8.2f} {hm:10.5f}")
    np.savetxt(args.outdir / "convergence.csv", np.array(conv), delimiter=",",
               header="t_ns,dG_kcalmol,W_bulk_kcalmol,recent_hill_kcalmol", comments="")

    lo, hi = args.bound[1], args.bulk[0]
    state = np.where(c < lo, 0, np.where(c > hi, 1, -1))
    seen, crossings = -1, 0
    for s in state:
        if s == -1:
            continue
        if seen != -1 and s != seen:
            crossings += 1
        seen = s
    P("")
    P(f"bound(z<{lo:g}) <-> bulk(z>{hi:g}) crossings: {crossings}")
    if crossings < 5:
        P("  WARNING: fewer than ~5 recrossings - treat the FES and dG as unconverged.")

    if args.cvseq and args.cvseq.is_file():
        names, A = parse_cvseq(args.cvseq)
        idx = {n: i for i, n in enumerate(names)}
        get = lambda k: A[:, idx[k]]
        ex, vr, vz = get("funnel_radial_excess_A"), get("funnel_Vrad_kcalmol"), get("funnel_Vzwall_kcalmol")
        rho, ra, zc = get("funnel_rho_A"), get("funnel_radius_A"), get("funnel_z_A")
        P("")
        P(f"CVSEQ records         : {len(A)}")
        P(f"radial wall engaged   : {100*(ex>0).mean():.2f}% of frames, "
          f"max excess {ex.max():.3f} A, max V_rad {vr.max():.2f} kcal/mol")
        P(f"axial wall engaged    : {100*(vz>0).mean():.2f}% of frames, max V_z {vz.max():.2f} kcal/mol")
        P(f"rho / r_allowed       : mean {np.mean(rho/ra):.3f}, p99 {np.percentile(rho/ra,99):.3f}")
        rows = []
        for k in ("frame_anchor_OU_A", "frame_anchor_OV_A", "frame_anchor_UV_A",
                  "frame_perpendicular_A", "frame_condition_sine",
                  "frame_anchor_cosine", "frame_axis_pre_norm"):
            if k in idx:
                v = get(k)
                P(f"{k:<22}: min {v.min():.4f}  max {v.max():.4f}  mean {v.mean():.4f}")
                rows.append((k, v.min(), v.max(), v.mean()))
        with (args.outdir / "walls.csv").open("w") as fh:
            fh.write("quantity,min,max,mean\n")
            fh.write(f"funnel_z_A,{zc.min()},{zc.max()},{zc.mean()}\n")
            fh.write(f"funnel_rho_A,{rho.min()},{rho.max()},{rho.mean()}\n")
            fh.write(f"radial_excess_A,{ex.min()},{ex.max()},{ex.mean()}\n")
            fh.write(f"V_rad_kcalmol,{vr.min()},{vr.max()},{vr.mean()}\n")
            fh.write(f"V_zwall_kcalmol,{vz.min()},{vz.max()},{vz.mean()}\n")
            for k, a, b, m in rows:
                fh.write(f"{k},{a},{b},{m}\n")

    (args.outdir / "summary.txt").write_text("\n".join(lines) + "\n")
    print(f"\nWritten to {args.outdir}/")


if __name__ == "__main__":
    main()
