#!/usr/bin/env bash
set -euo pipefail

: "${SCHRODINGER:?SCHRODINGER ortam degiskeni tanimli degil}"

JOBNAME="designer_job"

exec "${SCHRODINGER}/utilities/multisim" \
  -JOBNAME "${JOBNAME}" \
  -HOST localhost \
  -maxjob 1 \
  -cpu 1 \
  -m "${JOBNAME}.msj" \
  -c "${JOBNAME}.cfg" \
  -description "Funnel WT-MetaD" \
  "${JOBNAME}.cms" \
  -mode umbrella \
  -o "${JOBNAME}-out.cms" \
  -lic DESMOND_GPGPU:16
