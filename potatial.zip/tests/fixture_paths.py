"""Where the suites find a real Desmond job, without leaving the repository.

Resolution order, so a developer can point the suites at their own job while
CI and a fresh clone still work:

1. ``$FUNNELFORGE_TEST_JOB`` - a path to a ``.pot`` with its siblings.
2. ``tests/corpus/ache/…`` - the acetylcholinesterase package that ships with
   the repository.  This is the *general* fixture: nothing in it is named the
   way this program's own designer names things.
3. Nothing, in which case the suites say so and skip rather than passing
   hollowly.

For the funnel designer's own suite there is also :func:`designer_job`, which
builds a designer-shaped job from the corpus structure the first time it is
asked and caches it under ``tests/corpus/generated``.  The designer models one
template and legitimately needs a job in that template; generating it from a
real 41 986-atom structure is a stronger test than shipping a hand-made one,
and it keeps the suite self-contained.
"""

from __future__ import annotations

import os

HERE = os.path.dirname(os.path.abspath(__file__))
CORPUS = os.path.join(HERE, "corpus")
ACHE = os.path.join(CORPUS, "ache", "AChE-G2N_WT_Funnel_MetaD_run",
                    "AChE-G2N_WT_funnel_MetaD_run")
GENERATED = os.path.join(CORPUS, "generated")


def real_pot() -> str:
    """A real ``.pot`` to analyse, or "" when none is available."""
    env = os.environ.get("FUNNELFORGE_TEST_JOB", "")
    if env and os.path.exists(env):
        return env
    if os.path.exists(ACHE + ".pot"):
        return ACHE + ".pot"
    return ""


def real_cms(pot: str = "") -> str:
    pot = pot or real_pot()
    if not pot:
        return ""
    cms = os.path.splitext(pot)[0] + ".cms"
    return cms if os.path.exists(cms) else ""


def designer_job() -> str:
    """A job in the funnel designer's own template, built once and cached.

    Returns the path to a ``.pot``, or "" when there is no structure to build
    it from.  The build uses only public entry points - the same ones the
    interface uses when a user imports a bare structure and presses
    *Suggest funnel from pocket* - so a failure here is a real failure of that
    path, not of the fixture.
    """
    out = os.path.join(GENERATED, "designer_job.pot")
    if os.path.exists(out):
        return out
    cms = real_cms()
    if not cms:
        return ""
    os.makedirs(GENERATED, exist_ok=True)

    from funnelforge.core.project import Job
    from funnelforge.core.autobuild import suggest_groups

    job = Job()
    job.attach_structure(cms)
    sug = suggest_groups(job.structure)
    job.spec.lig, job.spec.site, job.spec.core = sug.lig, sug.site, sug.core
    job.spec.ligand_label = sug.label
    job.refresh_model()
    job.model.initialise_funnel()
    # a couple of reported distances, so the diagnostics paths have something
    # real to round-trip
    from funnelforge.core.funnel import make_diagnostic
    from funnelforge.core.asl import parse_residue_shorthand
    for token in ("124", "337"):
        found = parse_residue_shorthand(token, job.structure)
        if found:
            job.spec.diagnostics.append(
                make_diagnostic(job.spec, found[0]["label"],
                                found[0]["indices"]))
    job.refresh_model()
    res = job.export(GENERATED, "designer_job", cms_mode="symlink")
    if not res.verified:
        raise RuntimeError(
            "could not build the designer fixture: "
            + "; ".join(i.message for i in res.issues if i.level == "error"))
    return out
