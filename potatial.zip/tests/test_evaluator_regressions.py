"""Numerical regressions for imported, unconventionally named potentials."""
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest

from funnelforge.core import asl
from funnelforge.core.document import Document, _resolve_asl
from funnelforge.core.mexpr import (Interpreter, MExprError, V, evaluate_pot,
                                   parse_expression)


class Structure:
    xyz = np.array([[1., 0., 0.], [0., 0., 0.],
                    [0., 1., 0.], [0., 1., 1.]])
    mass = np.array([1., 2., 3., 4.])
    n_atoms = 4
    chain = np.array(["A", "B", "C", "D"])
    resnum = np.arange(1, 5)

    def center_of_mass(self, ids):
        return np.average(self.xyz[ids], weights=self.mass[ids], axis=0)

    def min_image(self, xyz):
        return np.asarray(xyz)

    def mask(self, name):
        return np.zeros(self.n_atoms, dtype=bool)

    def residue_of_atom(self, index):
        return SimpleNamespace(chain=self.chain[index], long_label=f"R{index+1}")


def test_local_selection_uses_the_same_ids_and_residues_as_atom_lists():
    st = Structure()
    assert _resolve_asl("index 1-2", st, asl) == [1, 2]
    doc = Document.from_text('grp = atomsel("index 1-2"); 0.0;')
    row = doc.resolve_topology(structure=st)[0]
    assert row["chains"] == ["A", "B"]
    assert row["residues"] == ["R1", "R2"]
    assert not any(d.code == "TOP002" for d in doc.report.all())
    result = evaluate_pot('grp = atomsel("index 1-2"); '
                          'p = pos(grp[0]); p;', st)
    np.testing.assert_array_equal(result.array("p"), st.xyz[0])


@pytest.mark.parametrize("selection", ["atom. 1,bad,3", "atom. 3-1", "atom. 0"])
def test_malformed_atom_lists_never_silently_select_a_subset(selection):
    with pytest.raises((ValueError, MExprError)):
        evaluate_pot(f'g = atomsel("{selection}"); 0.0;', Structure())


def test_probe_moves_aliases_subsets_geometry_and_particle_observables_together():
    st = Structure()
    source = ('cargo = atomsel("atom. 1,2"); same = cargo; one = same[0]; '
              'whole = center_of_mass(cargo); alias = center_of_mass(same); '
              'part = center_of_mass(one); cog = center_of_geometry(same); '
              'weighted = pos_inner_prod(same, array(1.0, 2.0))/3.0; '
              'anchor = atomsel("atom. 4"); d = dist(one, anchor[0]); '
              'm = mass(cargo); d;')
    probes = np.array([[3., 4., 5.], [6., 7., 8.]])
    result = evaluate_pot(source, st, probe=probes, probe_group="cargo")
    shifts = probes - st.center_of_mass(np.array([0, 1]))
    for key in ("whole", "alias", "weighted"):
        np.testing.assert_allclose(result.array(key), probes)
    np.testing.assert_allclose(result.array("part"), shifts + st.xyz[0])
    np.testing.assert_allclose(result.array("cog"), shifts + st.xyz[:2].mean(axis=0))
    np.testing.assert_allclose(result.array("d"),
                               np.linalg.norm(shifts + st.xyz[0] - st.xyz[3], axis=1))
    np.testing.assert_array_equal(result.array("m"), [1., 2.])


def test_dihedral_and_angle_match_particle_and_bond_vector_forms():
    source = ('g = atomsel("atom. 1-4"); '
              'torsion = dihedral_gid(g[0],g[1],g[2],g[3]); '
              'radians = dihedral_gid_radians(g[0],g[1],g[2],g[3]); '
              'bonds = dihedral(pos(g[1])-pos(g[0]), '
              'pos(g[2])-pos(g[1]), pos(g[3])-pos(g[2])); '
              'angle = angle_gid_radians(g[0],g[1],g[2]); angle;')
    result = evaluate_pot(source, Structure())
    np.testing.assert_allclose(result.array("torsion"), [0., -1.], atol=1e-12)
    np.testing.assert_allclose(result.array("bonds"), result.array("torsion"))
    assert result.scalar("radians") == pytest.approx(-np.pi / 2)
    assert result.scalar("angle") == pytest.approx(np.pi / 2)
    batch = evaluate_pot(source, Structure(), probe=np.zeros((2, 3)), probe_group="g")
    assert batch.array("torsion").shape == (2, 2)


def test_branches_and_arrays_broadcast_across_independent_sample_axes():
    env = {"left": V.num(np.array([[[1.]], [[-1.]]])),
           "right": V.num(np.arange(3.).reshape(1, 3, 1)),
           "fixed": V.num([3., 4., 5.])}
    interp = Interpreter(None, env=env)
    out = interp.run("v = if left then right else fixed; a = array(left, right); v;")
    assert out.array("v").shape == (2, 3, 3)
    np.testing.assert_array_equal(out.array("v")[0], np.repeat(np.arange(3.)[:, None], 3, axis=1))
    assert out.array("a").shape == (2, 3, 2)


def test_expression_parser_consumes_every_token_and_blocks_allow_final_expression():
    with pytest.raises(MExprError, match="trailing"):
        parse_expression("1.0; mystery()")
    result = evaluate_pot("a = { x = 2.0; x*x }; a;", None)
    assert result.scalar("a") == 4.
    values = ",".join(str(i) + ".0" for i in range(20))
    assert evaluate_pot(f"a = array({values}); n=length(a); n;", None).scalar("n") == 20


@pytest.mark.parametrize("expr", ["array(1.0,2.0)[0.4]", "array(1.0)[array(0.0,0.0)]",
                                  "series (i=0:1.4) i"])
def test_indices_and_iteration_bounds_are_never_rounded(expr):
    with pytest.raises(MExprError):
        evaluate_pot(f"a = {expr}; a;", None)


def test_real_ache_source_including_rotamer_monitoring_evaluates_in_batches():
    from funnelforge.core.cms import Structure as CmsStructure
    parent = Path(__file__).parent / "corpus/ache/AChE-G2N_WT_Funnel_MetaD_run"
    path = parent / "AChE-G2N_WT_funnel_MetaD_run.pot"
    if not path.with_suffix(".cms").exists():
        pytest.skip("production CMS fixture unavailable")
    st = CmsStructure.load(str(path.with_suffix(".cms")))
    result = evaluate_pot(path.read_text(), st)
    probe = np.asarray(result.array("lig_com")) + np.array([[0., 0., 0.], [1., 2., 3.]])
    batch = evaluate_pot(path.read_text(), st, probe=probe)
    assert batch.value.data.shape == (2, 1)
    assert np.isfinite(batch.value.data).all()
    assert batch.array("z")[0] == pytest.approx(result.scalar("z"))
    assert result.array("tyr337_chi1").shape == (2,)


def test_custom_source_bom_crlf_survive_parsing_and_evaluation():
    from funnelforge.core.cms import Structure as CmsStructure
    from funnelforge.core.lang import cst
    from funnelforge.core.lang.lexer import tokenize
    from funnelforge.core.potfile import parse_pot, emit_pot
    path = (Path(__file__).parent / "corpus/ache/AChE-G2N_WT_Funnel_MetaD_run"
            / "AChE-G2N_WT_funnel_MetaD_run.pot")
    if not path.with_suffix(".cms").exists():
        pytest.skip("production CMS fixture unavailable")
    source = "\ufeff" + path.read_text().replace("\n", "\r\n")
    assert tokenize(source).text == source
    assert not cst.parse(source).problems
    spec, report = parse_pot(source)
    assert spec.source_adapter and not report.errors
    assert emit_pot(spec).encode("utf-8") == source.encode("utf-8")
    st = CmsStructure.load(str(path.with_suffix(".cms")))
    result = evaluate_pot(source, st)
    assert np.isfinite(result.value.data).all()
