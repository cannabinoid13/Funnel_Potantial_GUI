"""Headless GUI tests: the interactive paths, driven without a mouse.

Run under a virtual display::

    xvfb-run -a python tests/test_gui.py
"""

from __future__ import annotations

import os
import sys
import tempfile
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fixture_paths import designer_job              # noqa: E402

#: the designer's own suite needs a job in the designer's template; it is
#: built from the repository corpus, so nothing here depends on a path
#: outside the tree
JOB = designer_job()

_HAVE_DISPLAY = bool(os.environ.get("DISPLAY") or
                     os.environ.get("WAYLAND_DISPLAY"))
if not _HAVE_DISPLAY:
    try:
        import pytest
        pytest.skip("no X display; run under xvfb-run",
                    allow_module_level=True)
    except ImportError:
        print("no X display; run this file under xvfb-run")
        raise SystemExit(2)

from PyQt5 import QtCore, QtWidgets
QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_ShareOpenGLContexts, True)
_app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv)

from funnelforge.gui import theme
import funnelforge.gui.main_window as MW
from funnelforge.gui.reps import REPRESENTATIONS, COLOR_MODES
from funnelforge.gui.viewer import GROUPS

MW.MainWindow._import_report = lambda self, rep: None
_app.setStyleSheet(theme.QSS)
_win = None


def _close_modals():
    """Auto-dismiss any modal dialog so exec_() cannot block the tests."""
    for w in QtWidgets.QApplication.topLevelWidgets():
        if isinstance(w, QtWidgets.QMessageBox) and w.isVisible():
            btn = (w.button(QtWidgets.QMessageBox.Yes)
                   or w.button(QtWidgets.QMessageBox.Ok)
                   or w.defaultButton())
            if btn is not None:
                btn.click()
            else:
                w.close()
        elif isinstance(w, QtWidgets.QDialog) and w.isVisible():
            w.accept()


_modal_timer = QtCore.QTimer()
_modal_timer.timeout.connect(_close_modals)
_modal_timer.start(60)


def spin(n=6, dt=0.008):
    for _ in range(n):
        _app.processEvents()
        time.sleep(dt)


def window():
    global _win
    if _win is None:
        _win = MW.MainWindow(None)
        _win.resize(1500, 940)
        _win.show()
        spin(6)
        _win.import_bundle(JOB)
        spin(12)
    return _win


def test_window_loads_job():
    w = window()
    assert w.job.structure is not None
    assert w.job.spec.lig.n > 0
    assert w.job.spec.site.n > 0 and w.job.spec.core.n > 0
    assert len(w.viewer.funnel.actors) > 10
    assert len(w.viewer.funnel.handles) == 6
    assert f"{w.job.structure.n_atoms:,} atoms" in w.lbl_struct.text()
    w.run_validation()
    errors = [i.message for i in w.job.validate() if i.level == "error"]
    assert not errors, errors


def test_all_representations_and_colours_build():
    w = window()
    for group in GROUPS:
        for rep in REPRESENTATIONS:
            w.display.rows[group]["rep"].setCurrentText(rep)
            spin(2, 0.005)
            assert w.viewer.styles[group].representation == rep
        w.display.rows[group]["rep"].setCurrentText(
            {"protein": "Cartoon (tube)", "ligand": "Ball & stick",
             "cofactor": "Licorice", "ions": "Spheres (VdW)",
             "water": "Hidden"}[group])
    for mode in COLOR_MODES:
        w.display.rows["protein"]["col"].setCurrentText(mode)
        spin(2, 0.005)
    w.display.rows["protein"]["col"].setCurrentText("Secondary structure")
    spin(2)


def test_funnel_presets_and_camera():
    w = window()
    for preset in ["Shape only", "Shells (default)", "Cross-section",
                   "Volume glow", "Everything"]:
        w.display.preset.setCurrentText(preset)
        w.display._apply_preset(preset)
        spin(4, 0.01)
    w.display.preset.setCurrentText("Shells (default)")
    w.display._apply_preset("Shells (default)")
    for fn in (w.viewer.view_funnel_axis, w.viewer.view_funnel_side,
               w.viewer.fit_funnel, w.viewer.fit_all, w.viewer.fit_ligand):
        fn()
        spin(2, 0.01)
    w.viewer.set_orthographic(True)
    spin(2)
    w.viewer.set_orthographic(False)


def test_panel_edit_flows_into_pot_text():
    w = window()
    w.funnel.z_cc.setValue(21.0, silent=False)
    w.funnel.k_rad.setValue(35.0, silent=False)
    w.funnel.cone_deg.setValue(26.0, silent=False)
    spin(10)
    assert abs(w.job.spec.z_cc - 21.0) < 1e-9
    assert abs(w.job.spec.k_rad - 35.0) < 1e-9
    assert abs(w.job.spec.cone_angle_deg - 26.0) < 1e-6
    w.potential.refresh()
    text = w.potential.view.toPlainText()
    assert "z_cc = 21.0;" in text and "k_rad = 35.0;" in text
    assert "changed line" in w.potential.status.text()
    assert w.job.verify_pot_text(text)["ok"]


def test_handle_drag_updates_spec_and_undo():
    w = window()
    before = w.job.spec.z_max
    w.push_undo()
    w.apply_handle("z_max", before - 6.0)
    w.on_handle_released("z_max")
    spin(6)
    assert abs(w.job.spec.z_max - (before - 6.0)) < 1e-9
    w.undo()
    spin(6)
    assert abs(w.job.spec.z_max - before) < 1e-9
    w.redo()
    spin(4)
    assert abs(w.job.spec.z_max - (before - 6.0)) < 1e-9
    w.undo()
    spin(4)


def test_origin_handle_moves_the_frame_only():
    w = window()
    m = w.job.model
    off0 = m.origin_offset_A
    z0, _ = m.cv_of_ligand()
    w.apply_handle("origin", off0 + 2.0)
    spin(4)
    z1, _ = w.job.model.cv_of_ligand()
    assert abs((z0 - 2.0) - z1) < 1e-6      # ligand z shifts with the origin
    w.apply_handle("origin", off0)
    spin(4)
    assert abs(w.job.model.origin_offset_A - off0) < 1e-9


def test_atom_picking_edits_the_active_group():
    w = window()
    w.tabs.setCurrentWidget(w.groups)
    w.groups.site.pick.setChecked(True)
    spin(4)
    assert w.viewer.pick_mode
    n0 = w.job.spec.site.n
    w.on_atom_picked(1184)
    spin(4)
    assert w.job.spec.site.n == n0 + 1 and 1184 in w.job.spec.site.indices
    w.on_atom_picked(1184)
    spin(4)
    assert w.job.spec.site.n == n0
    w.groups.site.pick.setChecked(False)
    spin(2)
    assert not w.viewer.pick_mode


def test_selection_expression_editor():
    w = window()
    ed = w.groups.lig
    saved = list(w.job.spec.lig.indices)
    st = w.job.structure
    res = st.residue_of_atom(saved[0] - 1)
    chain, name = res.chain, res.resname.strip()
    ed.expr.setText(f"chain {chain} and resname {name} and heavy")
    ed._apply_expr()
    spin(6)
    assert w.job.spec.lig.indices == saved, (chain, name)
    ed.expr.setText(f"chain {chain} and resname {name}")   # with hydrogens
    ed._apply_expr()
    spin(6)
    assert w.job.spec.lig.n > len(saved)
    msgs = " | ".join(i.message for i in w.job.validate())
    assert "hydrogen" in msgs
    w.job.spec.lig.indices = saved
    w.on_changed(geometry=True, structure=True)
    spin(4)


def test_diagnostic_add_and_remove():
    w = window()
    n0 = len(w.job.spec.diagnostics)
    w.groups.diag_expr.setText("chain A and resnum 158 and name CA")
    w.groups._add_diag()
    spin(6)
    assert len(w.job.spec.diagnostics) == n0 + 1
    text = w.job.pot_text()
    assert "_sel = atomsel(" in text
    assert w.job.verify_pot_text(text)["ok"]
    w.groups.diag.setCurrentCell(n0, 0)
    w.groups._del_diag()
    spin(4)
    assert len(w.job.spec.diagnostics) == n0


def test_metad_panel_gamma_and_ktemp():
    w = window()
    w.metad.lock_ktemp.setChecked(False)
    w.metad.gamma.setValue(20.0, silent=False)
    spin(6)
    from funnelforge.core.funnel import KB_KCAL
    assert abs(w.job.spec.ktemp - 19 * KB_KCAL * w.job.spec.temperature) < 1e-9
    w.metad.gamma.setValue(15.0, silent=False)
    spin(4)
    w.metad.lock_ktemp.setChecked(True)


def test_job_panel_patches_cfg_and_sh():
    w = window()
    w.jobpanel.time_ns.setValue(250.0, silent=False)
    w.jobpanel.traj.setValue(50.0, silent=False)
    w.jobpanel.host.setText("gpu-node")
    w.jobpanel._sh_changed()
    spin(8)
    assert w.job.cfg.number("time") == 250000.0
    assert w.job.cfg.number("trajectory.interval") == 50.0
    assert "-HOST gpu-node" in w.job.sh.render()
    w.jobpanel.time_ns.setValue(500.0, silent=False)
    w.jobpanel.traj.setValue(20.0, silent=False)
    w.jobpanel.host.setText("localhost")
    w.jobpanel._sh_changed()
    spin(4)


def test_temperature_change_keeps_files_consistent():
    w = window()
    w.metad.lock_ktemp.setChecked(False)
    w.jobpanel.temperature.setValue(300.0, silent=False)
    spin(8)
    assert w.job.cfg.temperature() == 300.0
    assert abs(w.job.spec.temperature - 300.0) < 1e-9
    msgs = " | ".join(i.message for i in w.job.validate())
    assert "does not match" not in msgs
    w.jobpanel.temperature.setValue(310.0, silent=False)
    spin(6)
    w.metad.lock_ktemp.setChecked(True)


def test_suggest_funnel_produces_a_valid_funnel():
    w = window()
    saved = w.job.spec.copy()
    try:
        w.suggest_funnel()
        spin(10, 0.02)
        sp, m = w.job.spec, w.job.model
        z0, rho0 = m.cv_of_ligand()
        assert sp.z_min < z0 < sp.z_max
        assert rho0 < sp.r_allowed(z0)
        assert float(sp.wall_potential(z0, rho0)) == 0.0
        clear, _ = m.funnel_clearance()
        assert clear > 0
        assert w.job.verify_pot_text(w.job.pot_text())["ok"]
    finally:
        w.job.spec = saved
        w.job.refresh_model()
        w.viewer.model = w.job.model
        w.viewer.rebuild_all()
        w.refresh_all()
        spin(4)


def test_shapes_panel_builds_every_kind():
    w = window()
    saved = w.job.spec.copy()
    try:
        w.tabs.setCurrentWidget(w.shapes)
        for kind in ("lathe", "sphere", "slab", "expression"):
            w.shapes._add(kind)
            spin(6)
        assert [t.kind for t in w.job.spec.terms] == \
            ["lathe", "sphere", "slab", "expression"]
        assert w.shapes.table.rowCount() == 4
        # every kind renders and the file still verifies
        assert len(w.viewer.funnel.actors) > 10
        assert w.job.verify_pot_text(w.job.pot_text())["ok"]
        # the generated code preview is populated for the selected term
        w.shapes.table.selectRow(0)
        spin(4)
        assert "w1_" in w.shapes.code.toPlainText()
        # duplicate, move and remove
        w.shapes._duplicate()
        spin(4)
        assert len(w.job.spec.terms) == 5
        w.shapes._move(+1)
        spin(4)
        w.shapes._remove()
        spin(4)
        assert len(w.job.spec.terms) == 4
        # disabling a term takes it out of v_total
        w.job.spec.terms[0].enabled = False
        w.on_changed(geometry=True)
        spin(6)
        assert w.job.spec.terms[0].energy_var not in w.job.pot_text().split(
            "v_total = ")[1].split(";")[0]
    finally:
        w.job.spec = saved
        w.job.refresh_model()
        w.viewer.model = w.job.model
        w.viewer.rebuild_all()
        w.refresh_all()
        spin(4)


def test_shapes_panel_lathe_editing_and_preview():
    w = window()
    saved = w.job.spec.copy()
    try:
        w.tabs.setCurrentWidget(w.shapes)
        w.shapes._add("lathe")
        spin(6)
        t = w.job.spec.terms[-1]
        w.shapes.profile.setText("5.0+6.0*exp(0.0-((z-10.0)^2)/40.0)")
        w.shapes._push()
        spin(6)
        assert t.profile.startswith("5.0+6.0*exp")
        assert "✓" in w.shapes.profile_status.text()
        r = w.job.model.term_profile(t, np.array([10.0]))
        assert abs(float(r[0]) - 11.0) < 1e-9
        # a broken profile is reported, not silently accepted
        w.shapes.profile.setText("5.0+abs(z)")
        w.shapes._push()
        spin(6)
        assert "✕" in w.shapes.profile_status.text()
        msgs = " | ".join(i.message for i in w.job.validate())
        assert "abs()" in msgs
        w.shapes.profile.setText("6.0")
        w.shapes._push()
        spin(4)
        # presets fill the box
        w.shapes.preset.setCurrentText("Cylinder")
        spin(4)
        assert w.job.spec.terms[-1].profile == "6.0"
        assert w.job.verify_pot_text(w.job.pot_text())["ok"]
    finally:
        w.job.spec = saved
        w.job.refresh_model()
        w.viewer.model = w.job.model
        w.viewer.rebuild_all()
        w.refresh_all()
        spin(4)


def test_shapes_panel_expression_and_region():
    w = window()
    saved = w.job.spec.copy()
    try:
        w.tabs.setCurrentWidget(w.shapes)
        w.shapes._add("expression")
        spin(6)
        t = w.job.spec.terms[-1]
        w.shapes.expr.setPlainText(
            "0.5*15.0*(if rho-5.0 then rho-5.0 else 0.0)^2")
        spin(8)
        assert t.expression.startswith("0.5*15.0")
        assert "✓" in w.shapes.expr_status.text()
        # region with a smooth taper
        w.shapes.region_on.setChecked(True)
        w.shapes.r_lo.setValue(24.0, silent=False)
        w.shapes.r_hi.setValue(34.0, silent=False)
        w.shapes.taper.setValue(2.5, silent=False)
        spin(8)
        assert t.region.enabled and abs(t.region.taper - 2.5) < 1e-9
        text = w.job.pot_text()
        assert f"{t.var}_s = " in text and f"v_{t.var} = {t.var}_s*" in text
        assert w.job.verify_pot_text(text)["ok"]
        # a non-Desmond function is rejected on the spot
        w.shapes.expr.setPlainText("max(rho,0.0)")
        spin(6)
        assert "✕" in w.shapes.expr_status.text()
    finally:
        w.job.spec = saved
        w.job.refresh_model()
        w.viewer.model = w.job.model
        w.viewer.rebuild_all()
        w.refresh_all()
        spin(4)


def test_funnel_off_and_total_field_view():
    w = window()
    saved = w.job.spec.copy()
    try:
        w.tabs.setCurrentWidget(w.shapes)
        w.shapes._add("lathe")
        spin(4)
        w.job.spec.terms[-1].cap = "both"
        w.shapes.use_funnel.setChecked(False)
        spin(8)
        assert w.job.spec.funnel_enabled is False
        text = w.job.pot_text()
        assert "v_rad" not in text
        assert w.job.verify_pot_text(text)["ok"]
        # the combined-field iso-surfaces render
        w.display.f_total.setChecked(True)
        spin(10)
        assert w.viewer.funnel.style.show_total_field
        assert len(w.viewer.funnel.actors) > 0
        w.display.f_total.setChecked(False)
        w.shapes.use_funnel.setChecked(True)
        spin(6)
    finally:
        w.job.spec = saved
        w.job.refresh_model()
        w.viewer.model = w.job.model
        w.viewer.rebuild_all()
        w.refresh_all()
        spin(4)


def test_no_funnel_is_drawn_without_one():
    """The 3-D view must show no funnel when the job has none."""
    w = window()
    saved = w.job.spec.copy()
    try:
        w.job.spec.funnel_enabled = False
        w.job.spec.z_min = w.job.spec.z_max = 0.0
        w.job.spec.r_cyl = 0.0
        w.on_changed(geometry=True)
        spin(8)
        assert w.job.model.funnel_is_degenerate()
        keys = {h.key for h in w.viewer.funnel.handles}
        assert "z_min" not in keys and "r_cyl" not in keys
        assert "origin" in keys          # the frame handle stays
        # nothing funnel-shaped is left in the scene; only frame props remain
        counts = w.viewer.funnel.counts
        assert counts["funnel"] == 0, counts
        assert counts["frame"] > 0
        # and the Funnel tab says so instead of showing stale numbers
        w.tabs.setCurrentWidget(w.funnel)
        w.funnel.refresh()
        spin(6)
        assert not w.funnel.shape_group.isVisible()
        assert w.funnel.no_funnel_note.isVisible()
    finally:
        w.job.spec = saved
        w.job.refresh_model()
        w.viewer.model = w.job.model
        w.viewer.rebuild_all()
        w.refresh_all()
        spin(4)


def test_add_funnel_from_the_shapes_tab():
    w = window()
    saved = w.job.spec.copy()
    try:
        w.tabs.setCurrentWidget(w.shapes)
        w.job.spec.funnel_enabled = False
        w.job.spec.z_min = w.job.spec.z_max = 0.0
        w.job.spec.r_cyl = 0.0
        w.on_changed(geometry=True)
        spin(6)
        assert w.shapes.add_funnel_btn.isVisible()
        w.shapes.add_funnel()
        spin(10)
        sp = w.job.spec
        assert sp.funnel_enabled and not w.job.model.funnel_is_degenerate()
        z0, rho0 = w.job.model.cv_of_ligand()
        assert sp.z_min < z0 < sp.z_max and rho0 < sp.r_allowed(z0)
        assert w.viewer.funnel.counts["funnel"] > 0
        assert w.shapes.funnel_rows.isVisible()
        assert w.job.verify_pot_text(w.job.pot_text())["ok"]
        # the inline funnel editor writes through to the spec
        w.shapes.f_r_cyl.setValue(5.5, silent=False)
        spin(6)
        assert abs(w.job.spec.r_cyl - 5.5) < 1e-9
        assert "r_cyl = 5.5;" in w.job.pot_text()
    finally:
        w.job.spec = saved
        w.job.refresh_model()
        w.viewer.model = w.job.model
        w.viewer.rebuild_all()
        w.refresh_all()
        spin(4)


def test_manual_placement_from_panel_and_handles():
    w = window()
    saved = w.job.spec.copy()
    try:
        w.tabs.setCurrentWidget(w.shapes)
        w.shapes._auto_fref()
        spin(6)
        assert w.job.spec.has_frame_ref
        w.shapes._add("sphere")
        spin(6)
        t = w.job.spec.terms[-1]
        # numeric placement, four decimals
        w.shapes.pos_axial.setValue(7.2500, silent=False)
        w.shapes.pos_e1.setValue(1.7500, silent=False)
        w.shapes.pos_e2.setValue(-2.2500, silent=False)
        spin(8)
        assert abs(t.center_z - 7.25) < 1e-9
        assert abs(t.offset_e1 - 1.75) < 1e-9
        assert abs(t.offset_e2 + 2.25) < 1e-9
        text = w.job.pot_text()
        assert f"{t.var}_ax = origin+1.75*e1-2.25*e2;" in text
        assert w.job.verify_pot_text(text)["ok"]

        # handles exist for the selected term only, and dragging them works
        keys = {h.key for h in w.viewer.funnel.handles}
        assert f"t:{t.var}:axial" in keys
        assert f"t:{t.var}:e1" in keys and f"t:{t.var}:e2" in keys
        assert f"t:{t.var}:R" in keys
        assert abs(w.handle_value(f"t:{t.var}:e1") - 1.75) < 1e-9
        w.apply_handle(f"t:{t.var}:axial", 12.0)
        spin(4)
        assert abs(t.center_z - 12.0) < 1e-9
        w.apply_handle(f"t:{t.var}:R", 9.5)
        spin(4)
        assert abs(t.radius - 9.5) < 1e-9
        w.apply_handle(f"t:{t.var}:e2", 0.5)
        spin(4)
        assert abs(t.offset_e2 - 0.5) < 1e-9
        assert w.job.verify_pot_text(w.job.pot_text())["ok"]

        # a second term does not clutter the view with its handles
        w.shapes._add("lathe")
        spin(6)
        t2 = w.job.spec.terms[-1]
        keys = {h.key for h in w.viewer.funnel.handles}
        assert f"t:{t2.var}:axial" in keys
        assert f"t:{t.var}:axial" not in keys

        # the funnel frame itself can be slid sideways too
        w.funnel.origin_lat1.setValue(1.25, silent=False)
        spin(6)
        assert abs(w.job.spec.origin_lat1 - 1.25) < 1e-9
        assert "*e1" in w.job.pot_text().split("origin = ")[1].split(";")[0]
        assert w.job.verify_pot_text(w.job.pot_text())["ok"]
    finally:
        w.job.spec = saved
        w.job.refresh_model()
        w.viewer.model = w.job.model
        w.viewer.rebuild_all()
        w.refresh_all()
        spin(4)


def _screen_of(w, p):
    ren = w.viewer.ren
    ren.SetWorldPoint(float(p[0]), float(p[1]), float(p[2]), 1.0)
    ren.WorldToDisplay()
    d = ren.GetDisplayPoint()
    return int(d[0]), int(d[1])


def test_handles_can_actually_be_grabbed_with_the_mouse():
    """Regression: hardware picking hit the translucent shell, never a handle,
    and the abort call did not exist, so the camera moved instead."""
    w = window()
    w.viewer.view_funnel_side()
    spin(8)
    iren = w.viewer.iren
    keys = [h.key for h in w.viewer.funnel.handles]
    assert keys, "no handles at all"
    grabbed = []
    for key in keys:
        h = next((q for q in w.viewer.funnel.handles if q.key == key), None)
        if h is None:
            continue
        x, y = _screen_of(w, np.array(h.actor.GetCenter()))
        iren.SetEventPosition(x, y)
        iren.InvokeEvent("LeftButtonPressEvent")
        got = w.viewer.style._drag
        if got is not None:
            grabbed.append(got.key)
        iren.InvokeEvent("LeftButtonReleaseEvent")
        spin(2)
    assert len(grabbed) == len(keys), (grabbed, keys)
    # dragging must move the parameter and must not rotate the camera
    cam = w.viewer.ren.GetActiveCamera()
    before_cam = np.array(cam.GetPosition())
    h = next(q for q in w.viewer.funnel.handles if q.key == "z_max")
    z_before = w.job.spec.z_max
    x, y = _screen_of(w, np.array(h.actor.GetCenter()))
    iren.SetEventPosition(x, y)
    iren.InvokeEvent("LeftButtonPressEvent")
    for dy in (6, 14, 22):
        iren.SetEventPosition(x, y - dy)
        iren.InvokeEvent("MouseMoveEvent")
    iren.InvokeEvent("LeftButtonReleaseEvent")
    spin(6)
    assert abs(w.job.spec.z_max - z_before) > 0.05, "the drag did nothing"
    assert np.allclose(np.array(cam.GetPosition()), before_cam, atol=1e-6), \
        "the camera moved while a handle was being dragged"
    assert w.job.verify_pot_text(w.job.pot_text())["ok"]


def test_handles_live_in_the_overlay_layer():
    w = window()
    spin(4)
    overlay = w.viewer.ren_overlay
    props = overlay.GetViewProps()
    assert props.GetNumberOfItems() == len(w.viewer.funnel.handles) > 0
    # and nothing in the main scene is pickable, so a click is unambiguous
    pickable = [a for a in w.viewer.funnel.actors
                if hasattr(a, "GetPickable") and a.GetPickable()]
    assert pickable == []


def test_gui_keeps_shapes_inside_the_solvent_box():
    w = window()
    saved = w.job.spec.copy()
    try:
        w.tabs.setCurrentWidget(w.shapes)
        w.shapes._auto_fref()
        w.shapes._add("sphere")
        spin(8)
        t = w.job.spec.terms[-1]
        # the numeric fields cannot even reach outside the cell.  Refresh
        # first: the range is recomputed on refresh, so comparing it against
        # limits taken later would be comparing two different states.
        w.shapes.refresh()
        spin(4)
        m = w.job.model
        lo, hi = m.axis_limits(margin=0.25)
        assert w.shapes.pos_axial.spin.minimum() >= lo - 1e-9
        assert w.shapes.pos_axial.spin.maximum() <= hi + 1e-9
        w.shapes.pos_axial.setValue(1e4, silent=False)
        spin(6)
        assert t.axial_position() <= hi + 1e-6
        # and a handle dragged outwards stops at the wall
        w.apply_handle(f"t:{t.var}:axial", 1e4)
        spin(4)
        assert t.axial_position() <= hi + 1e-6
        assert m.outside_box() == []
        # the funnel itself is held in too
        w.funnel.z_max.setValue(1e4, silent=False)
        spin(8)
        assert w.job.model.outside_box() == []

        # and hammering every handle to infinity still lands inside
        w.shapes._auto_fref()
        w.shapes._add("lathe")
        spin(6)
        t2 = w.job.spec.terms[-1]
        w.shapes.tilt.setValue(35.0, silent=False)
        spin(4)
        for what in ("axial", "e1", "e2", "z_lo", "z_hi", "tilt1", "tilt2"):
            key = f"t:{t2.var}:{what}"
            w.apply_handle(key, 1e4)
            w.on_handle_released(key)
            spin(2)
        for key in ("z_min", "z_max", "r_cyl", "cone", "axis_tilt1"):
            w.apply_handle(key, 1e4)
            w.on_handle_released(key)
            spin(2)
        spin(8)
        assert w.job.model.outside_box() == [], w.job.model.outside_box()
        assert w.job.verify_pot_text(w.job.pot_text())["ok"]
        assert w.job.verify_pot_text(w.job.pot_text())["ok"]
    finally:
        w.job.spec = saved
        w.job.refresh_model()
        w.viewer.model = w.job.model
        w.viewer.rebuild_all()
        w.refresh_all()
        spin(4)


def test_clicked_residue_becomes_the_ligand():
    """Ctrl+G must never overrule the molecule the user picked."""
    w = window()
    saved = w.job.spec.copy()
    try:
        from funnelforge.core.autobuild import candidate_ligands
        st = w.job.structure
        cands = candidate_ligands(st)
        labels = [r.long_label for r, _n, _i in cands]
        assert labels, "the structure should offer at least one ligand"
        assert not st.mask("water")[np.asarray(cands[0][2]) - 1].any()
        first_label = cands[0][0].long_label
        others = [i for r, _n, i in cands if r.long_label != first_label]
        chain_c = others[0] if others else cands[0][2]

        # arm "set from clicked residue" and click one atom of chain C
        w.tabs.setCurrentWidget(w.groups)
        w.groups.lig.replace_btn.setChecked(True)
        spin(4)
        assert w.viewer.pick_mode
        w.on_atom_picked(chain_c[5])
        spin(6)
        assert w.job.spec.lig.indices == sorted(chain_c)
        assert not w.groups.lig.replace_btn.isChecked()   # one shot only
        assert not w.viewer.pick_mode

        # and the suggestion keeps it instead of jumping to the biggest one
        from funnelforge.core.autobuild import suggest_groups
        sug = suggest_groups(st, lig_indices=w.job.spec.lig.indices)
        assert sug.lig.indices == sorted(chain_c)
        assert "kept your selection" in sug.notes[0]
        w.suggest_groups()
        spin(8)
        assert w.job.spec.lig.indices == sorted(chain_c)
        assert w.job.spec.site.n and w.job.spec.core.n
        assert w.job.verify_pot_text(w.job.pot_text())["ok"]

        # a whole-residue click on an already-selected residue removes it
        w.groups.lig.pick.setChecked(True)
        spin(2)
        w.on_atom_picked(chain_c[0])
        spin(4)
        assert w.job.spec.lig.n == 0
        w.on_atom_picked(chain_c[0])
        spin(4)
        assert w.job.spec.lig.indices == sorted(chain_c)
        w.groups.lig.pick.setChecked(False)

        # single-atom clicks still work where they should
        w.groups.site.pick.setChecked(True)
        spin(2)
        n0 = w.job.spec.site.n
        probe = next(i for i in range(2, 500)
                     if i not in w.job.spec.site.indices)
        w.on_atom_picked(probe)
        spin(4)
        assert w.job.spec.site.n == n0 + 1
        assert probe in w.job.spec.site.indices
        w.on_atom_picked(probe)
        spin(4)
        assert w.job.spec.site.n == n0
        w.groups.site.pick.setChecked(False)
    finally:
        w.job.spec = saved
        w.job.refresh_model()
        w.viewer.model = w.job.model
        w.viewer.rebuild_all()
        w.refresh_all()
        spin(4)


def test_tilt_from_panel_and_from_the_end_handles():
    """Angles are settable numerically and by swinging either end in 3-D."""
    w = window()
    saved = w.job.spec.copy()
    try:
        w.tabs.setCurrentWidget(w.shapes)
        w.shapes._auto_fref()
        spin(6)
        w.shapes._add("lathe")
        spin(8)
        t = w.job.spec.terms[-1]
        assert w.shapes.tilt.spin.isEnabled(), "a frame reference unlocks tilt"

        # numeric, to four decimals
        w.shapes.tilt.setValue(17.5, silent=False)
        w.shapes.azimuth.setValue(-40.0, silent=False)
        spin(8)
        assert abs(t.tilt_deg - 17.5) < 1e-9
        assert abs(t.azimuth_deg - (-40.0)) < 1e-9
        o, u, v1, v2 = w.job.model.term_frame(t)
        ang = np.degrees(np.arccos(np.clip(
            float(u @ w.job.model.frame.axis), -1, 1)))
        assert abs(ang - 17.5) < 1e-6
        assert w.job.verify_pot_text(w.job.pot_text())["ok"]

        # the swing handles exist at both ends and are idempotent
        keys = [h.key for h in w.viewer.funnel.handles]
        for suffix in ("", "_lo"):
            for comp in (1, 2):
                assert f"t:{t.var}:tilt{comp}{suffix}" in keys, keys
        key = f"t:{t.var}:tilt1"
        v0 = w.handle_value(key)
        w.apply_handle(key, v0 + 2.0)
        spin(4)
        first = (t.tilt_deg, t.azimuth_deg)
        w.apply_handle(key, v0 + 2.0)
        spin(4)
        assert (t.tilt_deg, t.azimuth_deg) == first, "swing must be idempotent"
        assert abs(w.handle_value(key) - (v0 + 2.0)) < 1e-6
        # the low-end handle turns the other way
        low = f"t:{t.var}:tilt1_lo"
        before = t.tilt_components()[0]
        w.apply_handle(low, w.handle_value(low) + 2.0)
        spin(4)
        assert t.tilt_components()[0] < before

        # the funnel axis itself can be swung too
        w.funnel.axis_tilt.setValue(9.0, silent=False)
        spin(8)
        assert abs(w.job.spec.axis_tilt_deg - 9.0) < 1e-9
        assert "axis_tilt1" in [h.key for h in w.viewer.funnel.handles]
        w.apply_handle("axis_tilt2", w.handle_value("axis_tilt2") + 1.5)
        spin(6)
        assert w.job.spec.axis_tilt_deg > 0
        assert w.job.model.outside_box() == []
        assert w.job.verify_pot_text(w.job.pot_text())["ok"]
    finally:
        w.job.spec = saved
        w.job.refresh_model()
        w.viewer.model = w.job.model
        w.viewer.rebuild_all()
        w.refresh_all()
        spin(4)


def test_every_shape_control_actually_applies():
    """Drive each control the way a user does and check the model followed.

    This is the regression net for "lots of things in the Shapes tab do
    nothing": the sideways and tilt fields used to be greyed out whenever no
    body-fixed reference group existed, which is the state every fresh import
    starts in.
    """
    w = window()
    saved = w.job.spec.copy()
    try:
        sp = w.job.spec
        sp.frame_ref.indices = []          # the state a fresh import is in
        w.job.refresh_model()
        w.tabs.setCurrentWidget(w.shapes)
        w.refresh_all()
        spin(6)
        S = w.shapes

        def drive(widget_call, getter, expect, name):
            widget_call()
            spin(4)
            got = getter()
            if isinstance(expect, float):
                assert abs(float(got) - expect) < 1e-6, (name, got, expect)
            else:
                assert got == expect, (name, got, expect)

        # --- the built-in funnel card
        for name, call, getter, want in (
            ("z_cc", lambda: S.f_z_cc.setValue(22.0, silent=False),
             lambda: sp.z_cc, 22.0),
            ("r_cyl", lambda: S.f_r_cyl.setValue(5.0, silent=False),
             lambda: sp.r_cyl, 5.0),
            ("cone", lambda: S.f_cone.setValue(28.0, silent=False),
             lambda: sp.cone_angle_deg, 28.0),
            ("slope", lambda: S.f_slope.setValue(0.55, silent=False),
             lambda: sp.cone_slope, 0.55),
            ("z_min", lambda: S.f_z_min.setValue(-6.0, silent=False),
             lambda: sp.z_min, -6.0),
            ("z_max", lambda: S.f_z_max.setValue(30.0, silent=False),
             lambda: sp.z_max, 30.0),
            ("k_rad", lambda: S.f_k_rad.setValue(33.0, silent=False),
             lambda: sp.k_rad, 33.0),
            ("k_z", lambda: S.f_k_z.setValue(44.0, silent=False),
             lambda: sp.k_z, 44.0),
            ("origin", lambda: S.f_origin.setValue(11.0, silent=False),
             lambda: w.job.model.origin_offset_A, 11.0),
        ):
            assert S.f_z_cc.spin.isEnabled()
            drive(call, getter, want, name)

        # these three need a body-fixed frame, which must appear on demand
        assert not sp.has_frame_ref
        assert S.f_lat1.spin.isEnabled(), "origin e1 must never be dead"
        drive(lambda: S.f_lat1.setValue(1.5, silent=False),
              lambda: sp.origin_lat1, 1.5, "origin e1")
        assert sp.has_frame_ref, "the reference group should have appeared"
        drive(lambda: S.f_lat2.setValue(-1.0, silent=False),
              lambda: sp.origin_lat2, -1.0, "origin e2")
        drive(lambda: S.f_tilt.setValue(8.0, silent=False),
              lambda: sp.axis_tilt_deg, 8.0, "axis tilt")
        drive(lambda: S.f_azim.setValue(45.0, silent=False),
              lambda: sp.axis_azimuth_deg, 45.0, "axis azimuth")

        # --- a shape term: every field on every card
        S._add("lathe")
        spin(8)
        t = sp.terms[-1]
        for name, call, getter, want in (
            ("tilt", lambda: S.tilt.setValue(20.0, silent=False),
             lambda: t.tilt_deg, 20.0),
            ("azimuth", lambda: S.azimuth.setValue(-30.0, silent=False),
             lambda: t.azimuth_deg, -30.0),
            ("e1", lambda: S.pos_e1.setValue(2.0, silent=False),
             lambda: t.offset_e1, 2.0),
            ("e2", lambda: S.pos_e2.setValue(1.0, silent=False),
             lambda: t.offset_e2, 1.0),
            ("axial", lambda: S.pos_axial.setValue(6.0, silent=False),
             lambda: t.axial_position(), 6.0),
            ("k", lambda: S.k.setValue(40.0, silent=False), lambda: t.k, 40.0),
            ("exponent", lambda: S.exponent.spin.setValue(4),
             lambda: t.exponent, 4),
            ("slack", lambda: S.offset.setValue(0.5, silent=False),
             lambda: t.offset, 0.5),
            ("z_lo", lambda: S.z_lo.setValue(-2.0, silent=False),
             lambda: t.z_lo, -2.0),
            ("z_hi", lambda: S.z_hi.setValue(28.0, silent=False),
             lambda: t.z_hi, 28.0),
            ("k_cap", lambda: S.k_cap.setValue(70.0, silent=False),
             lambda: t.k_cap, 70.0),
            ("radius", lambda: S.radius.setValue(9.0, silent=False),
             lambda: t.radius, 9.0),
            ("centre z", lambda: S.center_z.setValue(5.0, silent=False),
             lambda: t.center_z, 5.0),
            ("profile", lambda: (S.profile.setText("7.5"),
                                 S.profile.editingFinished.emit()),
             lambda: t.profile, "7.5"),
            ("label", lambda: (S.label.setText("Renamed"),
                               S.label.edit.editingFinished.emit()),
             lambda: t.label, "Renamed"),
            ("mode", lambda: S.mode.combo.setCurrentText(
                "exclude  ·  keep outside"), lambda: t.mode, "exclude"),
            ("cap", lambda: S.cap.combo.setCurrentText("both ends"),
             lambda: t.cap, "both"),
            ("region", lambda: S.region_on.setChecked(True),
             lambda: t.region.enabled, True),
            ("region z_lo", lambda: S.r_lo.setValue(2.0, silent=False),
             lambda: t.region.z_lo, 2.0),
            ("taper", lambda: S.taper.setValue(3.0, silent=False),
             lambda: t.region.taper, 3.0),
            ("own levels", lambda: S.own_levels.setChecked(True),
             lambda: t.own_levels, True),
            ("level mode", lambda: S.level_mode.combo.setCurrentText(
                "energies"), lambda: t.level_mode, "energy"),
            ("levels", lambda: (S.level_values.setText("2, 9"),
                                S.level_values.edit.editingFinished.emit()),
             lambda: t.levels, [2.0, 9.0]),
            ("handles here", lambda: S.handles_here.setChecked(False),
             lambda: w.viewer.funnel.style.handle_term_var, ""),
        ):
            drive(call, getter, want, name)
        S.handles_here.setChecked(True)
        spin(4)

        # nothing may have escaped the cell, and the file must still be right
        assert w.job.model.outside_box() == []
        info = w.job.verify_pot_text(w.job.pot_text())
        assert info["ok"], info
        assert not S._loading, "the panel must not be left deaf"

        # and the whole set still exports and re-imports
        import tempfile, os
        out = tempfile.mkdtemp(prefix="ff_controls_")
        # Exercising all pose controls can put the starting ligand outside
        # the wall. Such a job is now refused before any files are written.
        z0, rho0 = w.job.model.cv_of_ligand()
        if rho0 >= float(sp.r_allowed(z0)):
            refused = w.job.export(out, "controls_job", cms_mode="symlink")
            assert not refused.ok and not refused.written
            assert os.listdir(out) == []
            sp.r_cyl += rho0 - float(sp.r_allowed(z0)) + 0.25
            w.job.refresh_model()
        res = w.job.export(out, "controls_job", cms_mode="symlink")
        assert res.verified, res.verification
        assert res.ok and res.written, [(i.message, i.detail) for i in res.issues]
        from funnelforge.core.project import Job
        again = Job()
        again.import_bundle(os.path.join(out, "controls_job.pot"))
        assert abs(again.spec.axis_tilt_deg - sp.axis_tilt_deg) < 1e-9
        assert abs(again.spec.terms[0].tilt_deg - t.tilt_deg) < 1e-9
        assert abs(again.spec.origin_lat1 - sp.origin_lat1) < 1e-9
    finally:
        w.job.spec = saved
        w.job.refresh_model()
        w.viewer.model = w.job.model
        w.viewer.rebuild_all()
        w.refresh_all()
        spin(4)


def test_diagnostics_accept_a_residue_number():
    """The reported-distance box has to take what people actually type."""
    w = window()
    saved = w.job.spec.copy()
    try:
        w.tabs.setCurrentWidget(w.groups)
        G, sp = w.groups, w.job.spec
        n0 = len(sp.diagnostics)

        def add(text):
            G.diag_expr.setText(text)
            G._add_diag()
            spin(6)

        # a bare number takes the whole residue's heavy atoms
        st = w.job.structure
        prot = np.where(st.mask("protein"))[0]
        pick = st.residue_of_atom(int(prot[len(prot) // 2]))
        add(str(pick.resnum))
        assert len(sp.diagnostics) == n0 + 1
        d = sp.diagnostics[-1]
        assert d.label.lower().startswith(pick.resname.strip().lower()[:3])
        assert str(pick.resnum) in d.label
        heavy = [int(i) + 1 for i in np.where(st.mask("heavy"))[0]
                 if st.residue_of_atom(int(i)) is pick]
        assert sorted(d.indices) == sorted(heavy)
        assert all(st.anum[i - 1] > 1 for i in d.indices)
        # an atom name narrows it to that one atom
        one = heavy[len(heavy) // 2]
        aname = str(st.atomname[one - 1]).strip()
        add(f"{pick.resnum}:{aname}")
        assert sp.diagnostics[-1].indices == [one], aname
        # several at once, and the chain form
        two = [st.residue_of_atom(int(prot[len(prot) // 4])),
               st.residue_of_atom(int(prot[3 * len(prot) // 4]))]
        add(f"{two[0].resnum}, {two[1].resnum}")
        assert len(sp.diagnostics) == n0 + 4
        # the chain-qualified form
        add(f"{two[0].chain}:{two[0].resnum}")
        got = sp.diagnostics[-1].label.lower()
        assert got.startswith(two[0].resname.strip().lower()[:3])
        assert str(two[0].resnum) in got
        # the full selection language still works
        add("chain A and resnum 196 and name CA")
        assert len(sp.diagnostics) == n0 + 6
        # names can never collide, even against the imported d_tyr114
        names = [x.var for x in sp.diagnostics] + \
                [x.dist_var for x in sp.diagnostics]
        assert len(names) == len(set(names)), names
        assert not [i for i in w.job.validate() if i.level == "error"]
        assert w.job.verify_pot_text(w.job.pot_text())["ok"]
        # every one of them is printed in the CV file
        text = w.job.pot_text()
        for x in sp.diagnostics:
            assert f'print("{x.print_label}",{x.dist_var});' in text
        # a nonsense residue is refused with a readable message, not a crash
        before = len(sp.diagnostics)
        add("99999")
        assert len(sp.diagnostics) == before
        # picking in 3-D adds the clicked residue
        G.diag_pick.setChecked(True)
        spin(4)
        clicked = int(prot[len(prot) // 5]) + 1
        clicked_res = st.residue_of_atom(clicked - 1)
        w.on_atom_picked(clicked)
        spin(6)
        assert len(sp.diagnostics) == before + 1
        got = sp.diagnostics[-1].label.lower()
        assert got.startswith(clicked_res.resname.strip().lower()[:3])
        assert str(clicked_res.resnum) in got
        G.diag_pick.setChecked(False)
        # and the table lets the atom list be edited by hand
        row = len(sp.diagnostics) - 1
        G.diag.item(row, 2).setText(f"{clicked},{clicked + 1}")
        spin(4)
        assert sp.diagnostics[-1].indices == [clicked, clicked + 1]
    finally:
        w.job.spec = saved
        w.job.refresh_model()
        w.refresh_all()
        spin(4)


def test_suggest_groups_never_overwrites_what_you_have():
    w = window()
    saved = w.job.spec.copy()
    try:
        sp = w.job.spec
        before = (list(sp.lig.indices), list(sp.site.indices),
                  list(sp.core.indices))
        w.suggest_groups()
        spin(8)
        assert (list(sp.lig.indices), list(sp.site.indices),
                list(sp.core.indices)) == before, "Ctrl+G replaced a group"
        # an empty group is the only thing it fills
        sp.site.indices = []
        w.job.refresh_model()
        w.suggest_groups()
        spin(8)
        assert sp.site.indices, "the empty group was not filled"
        assert list(sp.core.indices) == before[2]
        assert list(sp.lig.indices) == before[0]
    finally:
        w.job.spec = saved
        w.job.refresh_model()
        w.refresh_all()
        spin(4)


def test_export_from_gui_and_snapshot():
    w = window()
    out = tempfile.mkdtemp(prefix="ff_gui_")
    w.jobpanel.outdir.setText(out)
    w.jobpanel.jobname.setText("gui_export_job")
    w.jobpanel._jobname_changed("gui_export_job")
    spin(4)
    # renaming the job must fix every cross-reference immediately
    errors = [i.message for i in w.job.validate() if i.level == "error"]
    assert not errors, errors
    prod = w.job.msj.production
    assert prod.meta_file == "gui_export_job.pot"
    assert prod.cfg_file == "gui_export_job.cfg"
    assert w.job.sh.jobname == "gui_export_job"
    w.do_export()
    spin(20, 0.02)
    for ext in (".pot", ".msj", ".cfg", ".sh", ".cms"):
        assert os.path.exists(os.path.join(out, "gui_export_job" + ext)), ext
    png = os.path.join(out, "shot.png")
    w.viewer.screenshot(png, magnification=1)
    assert os.path.exists(png) and os.path.getsize(png) > 5000
    name = os.path.splitext(os.path.basename(JOB))[0]
    w.jobpanel.jobname.setText(name)
    w.jobpanel._jobname_changed(name)


def test_session_save_and_reload_in_gui():
    w = window()
    path = os.path.join(tempfile.mkdtemp(), "session.json")
    w.job.save_session(path)
    spin(2)
    rep = w.job.load_session(path)
    w.after_import(rep)
    spin(8)
    assert w.job.structure is not None
    assert len(w.viewer.funnel.handles) == 6


def test_probe_and_verify_actions():
    w = window()
    w.probe_dialog()
    w.do_verify()
    spin(6)
    assert "PASS" in w.validate.verify_out.toPlainText()


def _main() -> int:
    # definition order, so the fresh-state tests run before the mutating ones
    tests = sorted(((k, v) for k, v in globals().items()
                    if k.startswith("test_") and callable(v)),
                   key=lambda kv: kv[1].__code__.co_firstlineno)
    fails = 0
    for name, fn in tests:
        try:
            fn()
            print(f"  PASS  {name}")
        except Exception as exc:
            fails += 1
            import traceback
            print(f"  FAIL  {name}: {exc}")
            traceback.print_exc(limit=4)
    print(f"\n{len(tests) - fails}/{len(tests)} passed")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(_main())
