"""Bundle regressions: real launch graphs, provenance and transactional export."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
from types import SimpleNamespace
import zipfile

import numpy as np
import pytest

from funnelforge.core.jobfiles import (
    BundlePaths, CfgFile, MsjFile, ShFile, bundle_replacements,
    discover_bundle, finalize_bundle_export, rewrite_file_references,
    stage_bundle_export, validate_export_tree,
)
from funnelforge.core.project import Job


LAUNCH = '''#!/usr/bin/env bash
set -euo pipefail
JOBNAME="original"
CMS="${JOBNAME}.cms"
MSJ="${JOBNAME}.msj"
CFG="${JOBNAME}.cfg"
POT="${JOBNAME}.pot"
VALIDATOR="validate_package.py"
PREFLIGHT="preflight_pot.py"
MANIFEST="PACKAGE_MANIFEST.sha256"
sha256sum -c "${MANIFEST}"
"${SCHRODINGER}/run" "${VALIDATOR}"
"${SCHRODINGER}/run" "${PREFLIGHT}" "${CMS}" "${POT}"
exec "${SCHRODINGER}/utilities/multisim" \\
 -JOBNAME "${JOBNAME}" -HOST "${DESMOND_HOST:-localhost}" \\
 -cpu 1 -maxjob 1 -m "${MSJ}" -c "${CFG}" "${CMS}" \\
 -mode umbrella -lic DESMOND_GPGPU:16 -description "Custom job"
'''


def package(directory):
    directory.mkdir(parents=True, exist_ok=True)
    contents = {
        'original.pot': 'return(0);\n',
        'original.cms': 'CMS test payload\n',
        'original.cfg': 'time = 500000\ntemperature = [[310 0]]\nmeta_file = ?\n',
        'original.msj': 'simulate { meta = FILE meta_file = "original.pot" cfg_file = "original.cfg" }\n',
        'original.sh': LAUNCH,
        'validate_package.py': 'raise RuntimeError("the frozen geometry changed")\n',
        'preflight_pot.py': '# Engine preflight remains original.\n',
        'helpers/analyze.py': 'STEM = "original"\ndef run():\n    return STEM\n',
        'README.md': '# Original locked geometry report\n',
    }
    for name, text in contents.items():
        p = directory / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text)
    (directory / 'PACKAGE_MANIFEST.sha256').write_text(''.join(
        hashlib.sha256((directory / name).read_bytes()).hexdigest() + '  ' + name + '\n'
        for name in contents))
    return directory


def test_archive_discovers_nested_package_and_retains_helpers(tmp_path):
    source = package(tmp_path / 'source')
    archive = tmp_path / 'package.zip'
    with zipfile.ZipFile(archive, 'w') as z:
        for p in source.rglob('*'):
            if p.is_file():
                z.write(p, 'nested/package/' + p.relative_to(source).as_posix())
    paths = discover_bundle(str(archive))
    assert paths.archive_path == str(archive)
    assert Path(paths.root_dir).name == 'package'
    assert Path(paths.cms).name == 'original.cms'
    assert 'helpers/analyze.py' in [Path(p).relative_to(paths.root_dir).as_posix() for p in paths.files]
    assert ShFile.load(paths.sh).render() == LAUNCH


def test_discovery_follows_mismatched_input_names(tmp_path):
    (tmp_path / 'production.msj').write_text(
        'simulate { meta = FILE meta_file = "restraints/special.pot" cfg_file = "settings.cfg" }')
    (tmp_path / 'restraints').mkdir()
    (tmp_path / 'restraints/special.pot').write_text('return(0);')
    (tmp_path / 'settings.cfg').write_text('time = 1000')
    (tmp_path / 'solvated.cms').write_text('CMS')
    (tmp_path / 'launch.sh').write_text(
        '#!/bin/bash\nexec "$SCHRODINGER/utilities/multisim" -JOBNAME simulation '
        '-m production.msj -c settings.cfg "solvated.cms" -o simulation-out.cms\n')
    paths = discover_bundle(str(tmp_path / 'launch.sh'))
    assert Path(paths.pot).name == 'special.pot'
    assert Path(paths.cfg).name == 'settings.cfg'
    assert Path(paths.cms).name == 'solvated.cms'
    assert Path(paths.msj).name == 'production.msj'
    paths = discover_bundle(str(tmp_path))
    assert Path(paths.pot).name == 'special.pot'


def test_ambiguous_packages_and_zip_traversal_are_reported(tmp_path):
    for stem in ('first', 'second'):
        (tmp_path / (stem + '.pot')).write_text('return(0);')
    with pytest.raises(ValueError, match='Multiple pot'):
        discover_bundle(str(tmp_path))
    archive = tmp_path / 'hostile.zip'
    with zipfile.ZipFile(archive, 'w') as z:
        z.writestr('../escape.pot', 'return(0);')
    with pytest.raises(ValueError, match='travers'):
        discover_bundle(str(archive))
    assert not (tmp_path.parent / 'escape.pot').exists()


def test_launcher_lossless_quotes_and_literal_references(tmp_path):
    sh = ShFile(LAUNCH)
    assert sh.render() == LAUNCH
    sh.host = 'gpu queue'
    sh.jobname = 'adjusted'
    rendered = sh.render()
    assert "-HOST 'gpu queue'" in rendered
    assert 'JOBNAME="adjusted"' in rendered
    assert '"${SCHRODINGER}/run" "${PREFLIGHT}"' in rendered
    literal = ShFile('exec multisim -JOBNAME old -m old.msj -c old.cfg old.cms\n')
    literal.jobname = 'new'
    literal.rewrite_references({'old.msj': 'new.msj', 'old.cfg': 'new.cfg', 'old.cms': 'new.cms'})
    assert '-JOBNAME "new" -m new.msj -c new.cfg new.cms' in literal.render()
    assert rewrite_file_references('STEM="run"\ndef run(): pass', {'run': 'changed'}) == \
        'STEM="changed"\ndef run(): pass'


def test_adjusted_package_keeps_preflight_and_checks_current_artifacts(tmp_path):
    source = package(tmp_path / 'source')
    paths = discover_bundle(str(source))
    staging = tmp_path / 'stage'
    staging.mkdir()
    replacements = bundle_replacements(paths, 'adjusted')
    stage_bundle_export(paths, str(staging), replacements)
    for attr in ('cms', 'pot', 'msj', 'cfg'):
        text = Path(getattr(paths, attr)).read_text()
        (staging / ('adjusted.' + attr)).write_text(rewrite_file_references(text, replacements))
    sh = ShFile.load(paths.sh)
    sh.jobname = 'adjusted'
    sh.rewrite_references(replacements)
    (staging / 'adjusted.sh').write_text(sh.render())
    geometry = dict(axis=[0., 0., 1.], origin=[1., 2., 3.], z_min=-1., z_max=20., r_cyl=4.)
    finalize_bundle_export(paths, str(staging), replacements, {'ok': True, 'n_probe': 4000}, 'adjusted', geometry)
    assert not validate_export_tree(str(staging), 'adjusted')
    launch = (staging / 'adjusted.sh').read_text()
    assert 'VALIDATOR="funnelforge_validate_export.py"' in launch
    assert '"${SCHRODINGER}/run" "${PREFLIGHT}" "${CMS}" "${POT}"' in launch
    assert (staging / 'preflight_pot.py').read_bytes() == (source / 'preflight_pot.py').read_bytes()
    assert (staging / '.funnelforge-source/validate_package.py').read_bytes() == \
        (source / 'validate_package.py').read_bytes()
    assert 'STEM = "adjusted"' in (staging / 'helpers/analyze.py').read_text()
    report = json.loads((staging / 'FUNNELFORGE_EXPORT.json').read_text())
    assert report['geometry'] == geometry
    # Only our generated checker runs. Imported scripts are never executed.
    checked = subprocess.run([sys.executable, str(staging / 'funnelforge_validate_export.py')],
                             capture_output=True, text=True)
    assert checked.returncode == 0, checked.stderr
    assert subprocess.run(['bash', '-n', str(staging / 'adjusted.sh')]).returncode == 0
    (staging / 'helpers/analyze.py').write_text('tampered')
    checked = subprocess.run([sys.executable, str(staging / 'funnelforge_validate_export.py')],
                             capture_output=True, text=True)
    assert checked.returncode != 0 and 'checksum mismatch' in checked.stderr


def io_job(tmp_path):
    source = package(tmp_path / 'source')
    job = Job()
    job.paths = discover_bundle(str(source))
    job.jobname = 'original'
    job.cfg = CfgFile.load(job.paths.cfg)
    job.msj = MsjFile.load(job.paths.msj)
    job.sh = ShFile.load(job.paths.sh)
    job.model = SimpleNamespace(frame=SimpleNamespace(axis=np.array([0., 0., 1.]),
                                                     origin=np.array([0., 0., 0.])))
    job.pot_text = lambda: 'return(0);\n'
    job.verify_pot_text = lambda text: {'ok': True}
    job.validate = lambda: []
    return job


def test_failed_cms_copy_leaves_source_and_destination_unchanged(tmp_path, monkeypatch):
    job = io_job(tmp_path)
    output = tmp_path / 'output'
    output.mkdir()
    (output / 'unrelated.txt').write_text('keep')
    original = Path(job.paths.pot).read_bytes()
    job.spec.cvseq_name = 'original.cvseq'
    def fail(*args):
        raise OSError('simulated full disk')
    monkeypatch.setattr('funnelforge.core.project.place_cms', fail)
    result = job.export(str(output), 'adjusted')
    assert not result.ok and not result.written
    assert 'simulated full disk' in result.issues[-1].detail
    assert list(p.name for p in output.iterdir()) == ['unrelated.txt']
    assert Path(job.paths.pot).read_bytes() == original
    assert job.jobname == 'original' and job.spec.cvseq_name == 'original.cvseq'
    assert not list(tmp_path.glob('.funnelforge-export-*'))


def test_missing_launcher_dependency_blocks_commit(tmp_path):
    job = io_job(tmp_path)
    job.sh.text = LAUNCH.replace('preflight_pot.py', 'missing_preflight.py')
    output = tmp_path / 'output'
    result = job.export(str(output), 'adjusted')
    assert not result.ok and not result.written and not output.exists()
    assert any('Missing exported dependency' in i.message for i in result.issues)


def test_source_directory_and_unsafe_jobname_are_never_written(tmp_path):
    job = io_job(tmp_path)
    assert not job.export(job.paths.root_dir, 'adjusted').ok
    assert not job.export(str(tmp_path), 'adjusted').ok
    assert not job.export(str(tmp_path / 'out'), '../escaped').ok
    assert not (tmp_path / 'escaped.pot').exists()


def test_zip_structure_link_survives_archive_lifetime_and_bom_is_normalized(tmp_path):
    job = io_job(tmp_path)
    job.paths.archive_path = str(tmp_path / 'source.zip')
    job.pot_text = lambda: '\ufeffreturn(0);\n'
    seen = []
    def verify(text):
        seen.append(text)
        return {'ok': True}
    job.verify_pot_text = verify
    output = tmp_path / 'output'
    result = job.export(str(output), 'adjusted', cms_mode='symlink')
    assert result.ok and result.written
    assert seen == ['return(0);\n']
    assert (output / 'adjusted.pot').read_bytes() == b'return(0);\n'
    assert not (output / 'adjusted.cms').is_symlink()
    assert (output / 'adjusted.cms').read_bytes() == Path(job.paths.cms).read_bytes()
    assert any('Copied the CMS' in i.message for i in result.issues)
    assert any('byte-order mark' in i.message for i in result.issues)


def test_commit_failure_rolls_back_existing_directory(tmp_path, monkeypatch):
    job = io_job(tmp_path)
    output = tmp_path / 'output'
    output.mkdir()
    (output / 'keep.txt').write_text('previous content')
    import os
    original_replace = os.replace
    def fail_commit(source, target):
        if Path(source).name.startswith('.funnelforge-export-'):
            raise OSError('simulated rename failure')
        return original_replace(source, target)
    monkeypatch.setattr('funnelforge.core.project.os.replace', fail_commit)
    result = job.export(str(output), 'adjusted')
    assert not result.ok and not result.written
    assert (output / 'keep.txt').read_text() == 'previous content'
    assert sorted(p.name for p in output.iterdir()) == ['keep.txt']
    assert not list(tmp_path.glob('.funnelforge-previous-*'))
