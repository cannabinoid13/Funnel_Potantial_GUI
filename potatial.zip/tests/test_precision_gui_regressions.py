"""Changing one visible control must not round unrelated source parameters."""
from types import SimpleNamespace

import pytest
from PyQt5 import QtWidgets

from funnelforge.core.funnel import FunnelSpec
from funnelforge.core.terms import Term
from funnelforge.gui.shapes_panel import ShapesPanel
from tests.test_custom_gui import custom_window


@pytest.mark.parametrize("panel_name,row_name", [("funnel", "k_rad"), ("shapes", "f_k_rad")])
def test_force_edit_preserves_every_other_imported_literal(custom_window, panel_name, row_name):
    window, app, errors = custom_window
    before = window.job.pot_text()
    getattr(getattr(window, panel_name), row_name).spin.setValue(30.)
    app.processEvents()
    assert not errors, errors
    assert window.job.pot_text() == before.replace("k_rad = 29.0;", "k_rad = 30.0;")
    assert window.job.spec.r_cyl == 4.110265665681823
    assert window.job.spec.z_max == 28.948553856514945


@pytest.mark.parametrize("panel_name,row_name", [("funnel", "origin_lat1"), ("shapes", "f_lat1")])
def test_lateral_edit_preserves_precise_tilt_and_other_offset(custom_window, panel_name, row_name):
    window, app, errors = custom_window
    spec = window.job.spec
    spec.axis_tilt_deg = 0.123456789123
    spec.axis_azimuth_deg = 31.123456789123
    spec.origin_lat2 = 0.0123456789123
    window.job.model.invalidate()
    window.refresh_all()
    getattr(getattr(window, panel_name), row_name).spin.setValue(0.025)
    app.processEvents()
    assert not errors, errors
    assert spec.origin_lat1 == 0.025
    assert spec.axis_tilt_deg == 0.123456789123
    assert spec.axis_azimuth_deg == 31.123456789123
    assert spec.origin_lat2 == 0.0123456789123


def test_metad_schedule_edit_preserves_precise_height_and_width(custom_window):
    window, app, errors = custom_window
    spec = window.job.spec
    spec.h0 = 0.23456789123
    spec.sigma_z = 0.5123456789123
    window.metad.refresh()
    window.metad.interval.spin.setValue(3.)
    app.processEvents()
    assert not errors, errors
    assert spec.meta_interval == 3.
    assert spec.h0 == 0.23456789123
    assert spec.sigma_z == 0.5123456789123


def test_term_force_and_sideways_edits_preserve_size_placement_and_profile():
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    holder = SimpleNamespace(job=SimpleNamespace(spec=FunnelSpec(), model=None))
    panel = ShapesPanel(holder)
    term = Term(kind="lathe", var="testwall", profile="6.123456789123",
                z_lo=1.123456789123, z_hi=12.987654321987,
                tilt_deg=0.123456789123, azimuth_deg=31.123456789123,
                offset_e2=0.0123456789123, radius=4.123456789123)
    panel._current = term
    panel._load_current_inner(term)
    panel._loading = False
    panel.ensure_frame_ref = lambda reason: True
    before = term.to_dict()
    panel.k.spin.setValue(31.)
    panel.pos_e1.spin.setValue(0.025)
    expected = dict(before, k=31., offset_e1=0.025)
    assert term.to_dict() == expected
    # Programmatic profile editing remains supported by the existing public
    # panel workflow and its profile presets.
    panel.profile.setText("7.0")
    panel._push()
    assert term.profile == "7.0"
    panel.preset.combo.setCurrentText("Cylinder")
    assert term.profile == "6.0"
    panel.close()
    app.processEvents()
