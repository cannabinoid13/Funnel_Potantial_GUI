"""Source-adapter physics must survive names, aliases and custom wall laws."""
from pathlib import Path
import re

import numpy as np
import pytest

from funnelforge.core.cms import Structure
from funnelforge.core.lang import cst, sema
from funnelforge.core.mexpr import evaluate_pot
from funnelforge.core.potfile import parse_pot, emit_pot
from funnelforge.core.source_adapter import (source_frame, source_field,
                                            source_radius, source_wall)


@pytest.fixture(scope="module")
def source_system():
    path = (Path(__file__).parent / "corpus/ache/AChE-G2N_WT_Funnel_MetaD_run"
            / "AChE-G2N_WT_funnel_MetaD_run.pot")
    if not path.with_suffix(".cms").exists():
        pytest.skip("production CMS fixture unavailable")
    return path.read_text(), Structure.load(str(path.with_suffix(".cms")))


def rename_all(source):
    names = {name: f"custom_{i}" for i, name in
             enumerate(sema.analyse(cst.parse(source)).symbols)}
    return re.sub(r"\b[A-Za-z_]\w*\b", lambda m: names.get(m.group(), m.group()),
                  source), names


def test_all_names_and_cv_aliases_keep_pose_energy_and_wt_parameter_edits(source_system):
    source, st = source_system
    source = source.replace("v_old = meta", "progress_alias = z;\nv_old = meta")
    source = source.replace("array(z));", "array(progress_alias));")
    renamed, names = rename_all(source)
    spec, report = parse_pot(renamed)
    assert spec.source_adapter and not report.errors
    assert emit_pot(spec) == renamed
    original, _ = parse_pot(source)
    frame, reference = source_frame(spec, st), source_frame(original, st)
    np.testing.assert_allclose(frame.origin, reference.origin)
    np.testing.assert_allclose(frame.axis, reference.axis)
    points = frame.origin + np.array([0., 5., 15.])[:, None] * frame.axis
    points += np.array([18., 20., 12.])[:, None] * frame.e1
    np.testing.assert_allclose(source_field(spec, st, points), source_field(original, st, points))
    spec.h0 = 0.18
    spec.ktemp = 9.5
    changed = emit_pot(spec)
    result = evaluate_pot(changed, st)
    assert result.scalar(names["h0"]) == pytest.approx(0.18)
    assert result.scalar(names["ktemp"]) == pytest.approx(9.5)
    reopened, rep = parse_pot(changed)
    assert reopened.source_adapter and not rep.errors
    assert reopened.h0 == pytest.approx(0.18)


@pytest.mark.parametrize("general_radius", [False, True])
def test_quartic_wall_uses_source_radius_and_matches_independent_formula(source_system, general_radius):
    source, st = source_system
    source = source.replace("0.5*k_rad*rad_excess^2", "0.5*k_rad*rad_excess^4")
    if general_radius:
        source = source.replace(
            "r_allowed = if z_cc-z then r_cyl+(z_cc-z)*cone_slope else r_cyl;",
            "r_allowed = r_cyl+cone_slope*exp(-(z-z_cc)^2/25.0);")
    spec, rep = parse_pot(source)
    assert spec.source_adapter and not rep.errors
    z, rho = np.array([0., 5., 15.]), np.array([18., 20., 12.])
    radius = (spec.r_cyl + spec.cone_slope * np.exp(-(z-spec.z_cc)**2 / 25.)
              if general_radius else spec.r_cyl + spec.cone_slope * np.maximum(spec.z_cc-z, 0.))
    expected = .5 * spec.k_rad * np.maximum(rho-radius, 0.)**4
    np.testing.assert_allclose(source_radius(spec, z), radius)
    np.testing.assert_allclose(source_wall(spec, z, rho), expected)
    frame = source_frame(spec, st)
    points = frame.origin + z[:, None] * frame.axis + rho[:, None] * frame.e1
    np.testing.assert_allclose(source_field(spec, st, points), expected, rtol=1e-10)


def test_unknown_monitoring_function_is_preserved_without_blocking_geometry(source_system):
    source, st = source_system
    extra = '\nfuture_monitor = future_diagnostic(lig);\nprint("future", future_monitor);\n'
    source = source.replace("\nv_total;", extra + "\nv_total;")
    spec, report = parse_pot(source)
    assert spec.source_adapter and not report.errors
    assert emit_pot(spec) == source
    frame = source_frame(spec, st)
    assert np.isfinite(source_field(spec, st, np.array([frame.lig_com]))).all()
