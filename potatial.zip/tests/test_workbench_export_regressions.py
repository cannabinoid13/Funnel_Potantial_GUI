"""The export button must write exactly the revision that was validated."""
import pytest
from PyQt5 import QtWidgets

from funnelforge.core.document import Document
from funnelforge.core import safety
from funnelforge.core.lang import diagnostics as diag
from funnelforge.gui.source_window import SourceWindow, display_text


@pytest.fixture
def workbench():
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    win = SourceWindow()
    yield win
    win._debounce.stop()
    if win._worker is not None:
        win._worker.wait()
    win.close()
    app.processEvents()


def prepare(win, doc):
    win.doc = doc
    win._loading = True
    win.editor.setPlainText(display_text(doc.source))
    win._loading = False
    win.view_doc = Document.from_text(doc.source, doc.path)
    win.view_doc.run_local_layers()
    win.view_doc.report.mark("official", diag.State.PASSED, source_rev=doc.rev)


def test_accepted_export_preserves_line_endings_without_engine_rejected_bom(workbench, tmp_path, monkeypatch):
    raw = b'\xef\xbb\xbfdeclare_output(name="o",first=0.0,interval=1.0);\r\na=1.0;\na;\r\n'
    source = tmp_path / "source.pot"
    source.write_bytes(raw)
    prepare(workbench, Document.open(str(source)))
    target = tmp_path / "export.pot"
    monkeypatch.setattr(QtWidgets.QFileDialog, "getSaveFileName", lambda *a: (str(target), ""))
    workbench._export()
    assert target.read_bytes() == raw[3:]
    assert "exported" in workbench.status.currentMessage()
    assert "without BOM" in workbench.status.currentMessage()
    assert source.read_bytes() == raw


def test_pending_analysis_cannot_export_previously_accepted_text(workbench, tmp_path, monkeypatch):
    prepare(workbench, Document.from_text('declare_output(name="o",first=0.0,interval=1.0); a=1.0; a;'))
    target = tmp_path / "export.pot"
    workbench.editor.setPlainText(workbench.doc.source.replace("a=1.0", "a=2.0"))
    messages = []
    monkeypatch.setattr(QtWidgets.QMessageBox, "warning", lambda *a: messages.append(a[2]))
    monkeypatch.setattr(QtWidgets.QFileDialog, "getSaveFileName", lambda *a: (str(target), ""))
    monkeypatch.setattr(workbench, "_reanalyse", lambda: None)
    workbench._export()
    assert not target.exists()
    assert messages and "analysis" in messages[0]


def test_blocker_appearing_in_file_dialog_is_displayed(workbench, tmp_path, monkeypatch):
    prepare(workbench, Document.from_text('declare_output(name="o",first=0.0,interval=1.0); a=1.0; a;'))
    target = tmp_path / "export.pot"
    messages = []
    def choose(*args):
        workbench.view_doc.report.mark("official", diag.State.STALE,
                                      source_rev=workbench.doc.rev)
        return str(target), ""
    monkeypatch.setattr(QtWidgets.QFileDialog, "getSaveFileName", choose)
    monkeypatch.setattr(QtWidgets.QMessageBox, "warning", lambda *a: messages.append(a[2]))
    workbench._export()
    assert not target.exists()
    assert messages and "OFF008" in messages[0]


def test_local_reanalysis_does_not_renew_official_topology_fingerprint(workbench, tmp_path):
    prepare(workbench, Document.from_text('declare_output(name="o",first=0.0,interval=1.0); a=1.0; a;'))
    topology = tmp_path / "system.cms"
    topology.write_text("validated topology")
    workbench.cms_path = str(topology)
    previous = workbench.view_doc
    previous.topology_path = str(topology)
    previous.topology_digest = safety.file_digest(str(topology))
    topology.write_text("different coordinates")
    new = Document.from_text(previous.source)
    new.run_local_layers()
    new.topology_path = str(topology)
    new.topology_digest = safety.file_digest(str(topology))
    workbench._analysis_ready(new.rev, new)
    assert "OFF009" in {b.code for b in workbench.view_doc.export_blockers()}
    assert previous.report.layers["official"].state is diag.State.PASSED
